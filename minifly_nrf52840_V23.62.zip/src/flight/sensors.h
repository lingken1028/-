/**
 * @file    sensors.h
 * @brief   传感器接口
 *          对应: FLIGHT/interface/sensors.h (逐字对照 + V9 扩展)
 *
 * ══ GY-91 完整传感器组 ══
 *   MPU-9250: 陀螺(±2000°/s) + 加速(±16g) @ 500Hz
 *   AK8963:   磁力计 16-bit 100Hz (bypass 模式 @ 0x0C)
 *   BMP280:   气压计 OSR×8, IIR×16 @ 50Hz
 *
 * ══ 传感器降级策略 (V9) ══
 *   GY-91 检测失败 → 板载 LSM6DS3TR-C (6DOF 纯姿态)
 *   getIsBaroPresent() = false → commander 禁用 mode.z (无定高)
 *   getIsMagPresent()  = false → UP_SENSER 磁力计字段为零
 *
 * ══ 速率常量 (对应 sensors.h) ══
 *   SENSOR9_UPDATE_RATE = 500Hz (sensorsTask 2ms 周期)
 *   lpf2pInit(gyroLpf, 500, GYRO_LPF_CUTOFF_FREQ=80)
 *   lpf2pInit(accLpf,  500, ACCEL_LPF_CUTOFF_FREQ=30)
 */
#pragma once
#include "stabilizer_types.h"
#include "../config.h"
#include <stdbool.h>

/* 传感器速率 */
#define SENSOR9_UPDATE_RATE    500    /* Hz — sensorsAcquire 调用频率 */
#define SENSOR9_UPDATE_DT      (1.0f/500.0f)
#define BARO_UPDATE_RATE_HZ    50     /* Hz — BMP280 读取频率 */

/* 陀螺低通截止频率 (对应 sensors.c, 单位 Hz) */
#define GYRO_LPF_CUTOFF_FREQ   80.0f
#define ACCEL_LPF_CUTOFF_FREQ  30.0f
/* V22.86: LSM6 单用(无GY-91)专用更低陀螺软低通。LSM6 无硬件陀螺DLPF(MPU有98Hz), 只靠软低通 →
 * 天生更吵、易抖。给它单独更低的截止(42Hz, 不影响用GY-91时的80Hz)压噪。配合LSM 416Hz ODR(防混叠)。
 * 若仍抖可降到30; 若觉得LSM响应发钝可升到55。仅LSM单用时生效。 */
#define LSM_GYRO_LPF_HZ        30.0f  /* V23.00: 42→30 — 恢复VBAT_COMP后(你电池下垂大, 补偿常年~1.3x)
                                       * LSM残余噪声被放大→偶发左沉一抖。按预案降低通压噪, 补偿保留(关它=低压前飘)。 */

/* 校准参数 */
#define SENSORS_NBR_OF_BIAS_SAMPLES  1024
#define GYRO_VARIANCE_BASE           4000
#define SENSORS_ACC_SCALE_SAMPLES    200

/* ── 核心接口 ── */
void sensorsTask(void* param);
void sensorsInit(void);
bool sensorsTest(void);
bool sensorsAreCalibrated(void);
void sensorsAcquire(sensorData_t* sensors, uint32_t tick);

/* ── 传感器存在性检测 (V9: 供 commander/stabilizer 条件判断) ── */
bool getIsMPU9250Present(void);   /* GY-91 主 IMU 是否检测到 */
bool getIsBaroPresent(void);      /* BMP280 气压计是否可用 → 控制定高使能 */
uint32_t sensorsGetBaroReadOK(void);   /* V22.45 诊断: 有效气压读取计数 */
uint32_t sensorsGetBaroReadTrue(void); /* V22.46 诊断: I2C读成功计数(不管范围) */
float    sensorsGetBaroLastPa(void);   /* V22.46 诊断: 最近原始气压 hPa */
float    sensorsGetBaroAsl(void);     /* V22.45 诊断: 原始气压海拔 cm (估测器之前) */
float    sensorsGetBaroTemp(void);    /* V22.64 诊断: 气压计温度 °C (查温漂) */
float    sensorsGetGyroVib(void);     /* V22.69 诊断: 陀螺振动指标 |Δgyro| deg/s/样本 (调陷波用) */
bool getIsMagPresent(void);       /* AK8963 磁力计是否可用 → 控制 mag 数据 */
bool sensorsUsingOnboardIMU(void); /* V22.88: 是否在用板载LSM6(无GY-91降级)。供power_control判断是否关VBAT_COMP/AIRMODE */
uint32_t sensorsBaroAgeMs(void);   /* V22.95: 最近一次有效气压距今ms(飞行中气压失效检测用) */
void sensorsStartMagCal(void);    /* V22.24: 地面站罗盘校准 → 水平转圈采min/max定硬磁偏置 */
int  getMagCalPercent(void);      /* V22.29/49: -1=从未校准, 0..99=校准中(应转圈), 100=完成 */
bool sensorsIsMagCalibrated(void);/* V22.49: 是否完成磁校准 → 磁偏航融合仅在此后生效 */
void sensorsGetMagCal(float bias[3], float scale[3]);  /* V23.45: 读出校准值 → 抄进config.h的MAG_*预设, 免每次上电重校 */
const char* sensorsGetDiagString(void);  /* V22: S4 阶段诊断字符串 */

/* ── 单轴读取接口 (对应 sensors.h 声明) ── */
bool sensorsReadGyro(Axis3f* gyro);
bool sensorsReadAcc(Axis3f* acc);
bool sensorsReadMag(Axis3f* mag);
bool sensorsReadBaro(baro_t* baro);
void sensorsRecalibrateGyro(void);    /* V22.16: 地面站陀螺仪校准 → 重新静止采样零偏 */
#if DUAL_IMU_GYRO
void sensorsGetDualGyroDbg(float mpu[3], float lsm[3], bool* lsmBiasReady);  /* V22.60: 双IMU轴向验证 */
#endif