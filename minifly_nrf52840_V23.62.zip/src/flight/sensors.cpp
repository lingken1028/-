/**
 * @file    sensors.cpp — V22 (架构回归原版 sensors.c)
 *
 * ══ V22 核心修复 ══
 *   1. 架构: sensorsTask 是唯一访问 I2C 硬件的任务 (与原版一致)。
 *      sensorsAcquire() 现在只从队列 Peek (原版语义), stabilizerTask
 *      调用它不再触碰总线 → 彻底消除 V21 "两个任务同时读 I2C"
 *      导致的总线/缓冲竞争 (S5 启动 stabilizer 即复位的根因之一)。
 *   2. 队列在任何探测动作之前创建并填入零值 → stabilizer 提前跑也
 *      不会 Peek 到 NULL 队列 (NULL 队列解引用 → HardFault → 复位环)。
 *   3. GY-91 经真实 TWIM0 探测 (旧版 "TWIM2"=PWM2, 永远探不到)。
 *   4. 降级路径: lsm6ds3.cpp 自带 P1.08 供电 + TWIM1 直驱, 不再依赖
 *      Wire1/Adafruit 库 → 拔掉 GY-91 用板载 IMU 照常飞 (纯姿态)。
 *   5. baro.asl 单位改为 cm (对照原版 *100.f), 定高/估测链路才正确。
 *   6. 陀螺零偏方差统计改 int64 (原版同), 修复 int32 溢出。
 *   7. 安装方向映射移到 config.h (GY91_AXIS_MAP / LSM6_AXIS_MAP)。
 *
 * ══ 探测顺序 ══
 *   GY-91 MPU9250@0x68/0x69 → 成功: +AK8963(bypass) +BMP280
 *   失败 → 板载 LSM6DS3TR-C (无磁力计; BMP280 仍单独探测一次,
 *           万一 GY-91 只有气压计部分还活着也能用)
 *   都失败 → IMU_NONE: 系统照常运行, 队列输出零值, 不复位不卡死
 */
#include "sensors.h"
#include "stabilizer_types.h"
#include "../hardware/i2cdev.h"
#include "../hardware/mpu6500_reg.h"
#include "../hardware/bmp280.h"
#include "../hardware/ak8963.h"
#include "../hardware/lsm6ds3.h"
#include "../common/filter.h"
#include "../config.h"
#include "../communicate/commander.h"   /* V22.35: getCommanderKeyFlight/keyland(气压重探避开飞行) + commanderGetThrust(动态陷波) — 改无条件包含 */
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <math.h>
#include <string.h>
#include <stdio.h>

/* ── 量程转换 (MPU9250) ── */
#define SENSORS_DEG_PER_LSB_MPU  MPU6500_DEG_PER_LSB_2000
#define SENSORS_G_PER_LSB_MPU    MPU6500_G_PER_LSB_16

/* ── IMU 类型 ── */
typedef enum { IMU_NONE = 0, IMU_MPU9250, IMU_LSM6DS3 } imuType_e;

static imuType_e s_imuType   = IMU_NONE;
static uint8_t   s_mpuAddr   = MPU9250_I2C_ADDR;
static uint8_t   s_mpuWho    = 0;
#if DUAL_IMU_GYRO
static bool      s_dualLsmOk = false;   /* V22.27 #5: 双陀螺时板载 LSM6 是否就绪 */
#endif

/* ── 状态标志 ── */
static bool s_isInit        = false;
static bool s_isMPUPresent  = false;   /* "有可用 IMU" (含板载降级) */
static bool s_isBaroPresent = false;
static uint32_t s_baroReadOK = 0;   /* V22.45 诊断: BMP280 成功读到有效气压的累计次数 */
static uint32_t s_baroReadTrue = 0; /* V22.46 诊断: bmp280Read 返回 true 的次数(I2C读成功, 不管范围) */
static float    s_baroLastPa = 0;   /* V22.46 诊断: 最近一次原始气压 hPa(范围检查之前) */
static uint32_t s_baroOkMs   = 0;
static uint32_t s_baroFailStreak = 0; /* V22.46: 连续无有效气压计数 → 超阈值标记离线+重init */
static bool s_isMagPresent  = false;
static char s_diag[96]      = "S4 not run";

/* ── lpf2p 二阶低通滤波器 ── */
static lpf2pData s_gyroLpf[3];
static lpf2pData s_accLpf[3];
/* V23.22: 陀螺陷波已删除 — 文献(Betaflight): 好陀螺(LSM6/ICM级)+软低通已足够, 静态陷波需黑盒FFT对准实际噪声峰盲设有害, 且其相移尾巴加重桨洗/削定高。本机用 LSM 416Hz + LSM_GYRO_LPF_HZ 软低通足矣。 */
/* V22.69: 陀螺振动诊断 — 累计逐样本|Δgyro|(高频量指标), 心跳报 vib=(deg/s/样本)。
 * 在陷波后/软低通前取值: 陷波关→看原始振动(调频率范围); 陷波开→看残余(验证是否压低)。 */
static float    s_vibPrev[3] = {0, 0, 0};
static double   s_vibAcc     = 0.0;
static uint32_t s_vibCnt     = 0;
#if BARO_ALT_LPF_ENABLE
static lpf2pData s_baroAltLpf;     /* V22.27 #4: 气压海拔低通 */
static bool      s_baroAltLpfInit = false;
#endif

/* ── 陀螺偏置校准 (单位: 原始 LSB; int64 防溢出, 对照原版) ── */
static float   s_gyroBias[3]  = {0};
static int64_t s_biasSum[3]   = {0};
static int64_t s_biasSumSq[3] = {0};
static int     s_biasCnt      = 0;
static bool    s_biasFound    = false;

#if DUAL_IMU_GYRO
/* 轴向验证调试: 混合前的 MPU / LSM 陀螺(均为 MPU当量 LSB), 给遥测对比。
 * 注: LSM 零偏不再单独维护 —— 混合后由 processAccGyro 的主陀螺零偏校准统一去掉(避免重复减→残漂)。 */
static float   s_dbgGyrMpu[3]   = {0};
static float   s_dbgGyrLsm[3]   = {0};
#endif

/* ── 加速度量程校准 ── */
static float s_accScale     = 1.0f;
static float s_accScaleSum  = 0.0f;
static int   s_accScaleCnt  = 0;
static bool  s_accScaleDone = false;

/* ── 磁力计硬/软磁校准 (V22.24): 水平转几圈采各轴 min/max → 偏置=(min+max)/2, 软磁按范围归一 ── */
#if MAG_CAL_PRESET
static float s_magBias[3]   = {MAG_BIAS_X,  MAG_BIAS_Y,  MAG_BIAS_Z};
static float s_magScale[3]  = {MAG_SCALE_X, MAG_SCALE_Y, MAG_SCALE_Z};
#else
static float s_magBias[3]   = {0, 0, 0};
static float s_magScale[3]  = {1, 1, 1};
#endif
static bool  s_magCalActive = false;
/* V22.49: 是否完成过磁校准 → 决定磁偏航融合是否生效(未校准时硬磁偏置会锁死yaw)
 * V23.45: MAG_CAL_PRESET=1 时开机即视为已校准(值来自config.h), 免去每次上位机重校 */
static bool  s_magCalDone   = (MAG_CAL_PRESET != 0);
static int   s_magCalCnt    = 0;
static float s_magMin[3], s_magMax[3];
#define MAG_CAL_SAMPLES 600   /* ~50Hz × 12s */

/* ── 数据队列 (深度1, Overwrite/Peek 语义) ── */
static QueueHandle_t s_accQ  = NULL;
static QueueHandle_t s_gyroQ = NULL;
static QueueHandle_t s_magQ  = NULL;
static QueueHandle_t s_baroQ = NULL;

/* ── 安装方向映射 (config.h 可调) ── */
static const int8_t MPU_MAP[3]  = GY91_AXIS_MAP;
static const int8_t MPU_SIGN[3] = GY91_AXIS_SIGN;
static const int8_t LSM_MAP[3]  = LSM6_AXIS_MAP;
static const int8_t LSM_SIGN[3] = LSM6_AXIS_SIGN;

static inline void remap3(int16_t v[3], const int8_t* map, const int8_t* sgn) {
    int16_t t0 = (int16_t)(v[map[0]] * sgn[0]);
    int16_t t1 = (int16_t)(v[map[1]] * sgn[1]);
    int16_t t2 = (int16_t)(v[map[2]] * sgn[2]);
    v[0] = t0; v[1] = t1; v[2] = t2;
}

/*──────────────────────────────────────────────────────────────
  陀螺偏置: 连续 1024 个样本, 方差小于阈值才认定零偏 (对照原版)
──────────────────────────────────────────────────────────────*/
uint16_t powerGetLastThrust(void);   /* V23.03: 真实电机油门 — 摇杆在定高档中位≠0, 会永久堵死落地重学 */

/* ══════════════════════════════════════════════════════════════
 * 【段落】updateGyroBias — 陀螺零偏的"守门滚动校准"
 *   这段做了什么: 累计 1024 样本(~2s)算均值与方差, 方差够小(真静止)
 *   才把均值收为零偏。三道门防污染: ①电机在转绝不刷新(V23.02: 平稳悬停
 *   也可能过方差门→把稳态角速度学进零偏→侧翻); ②磁校期间不采(V22.68:
 *   稳速旋转方差低会被误判静止); ③落地静置~2s自动重学温漂(V22.92)。
 * ══════════════════════════════════════════════════════════════ */
static void updateGyroBias(int16_t rx, int16_t ry, int16_t rz) {
    /* V23.02: 修"GY-91手动/定高都会突然侧翻失控" — V22.92的持续重估在【飞行中】被污染:
     * 平稳悬停/匀速转动的~2s窗口方差也可能过门(GY-91经98Hz DLPF信号越干净越容易) →
     * 把稳态角速度学进零偏 → 零偏突跳 → 速率环把假偏差当真、持续滚转 → 侧翻。
     * (和V22.68磁校同型漏洞, 是我重新打开的。) 修: 电机在转(油门≠0)时绝不刷新零偏 —
     * 保留"落地静置~2s自动重学温漂"的收益, 飞行中零偏回到开机锁定。 */
    if (s_biasFound && powerGetLastThrust() != 0) return;   /* V23.03: 真实油门(定高档遥控器开着也能落地重学) */
    /* V22.92: 去掉"找到一次就永久停"(原 if(s_biasFound)return) — 改持续滚动重估:
     * 每1024样本(~2s)判一次方差, 只有真静止(地面)才通过并刷新零偏; 飞行中电机振动
     * 方差大→永不误更新。→ 陀螺【温漂】在落地静置~2s时被自动重学(治"越飞越前飘"的根源之一)。
     * s_biasFound 一旦true保持true(canFly/校准状态不受影响)。 */
    if (s_magCalActive) return;   /* V22.68: 磁校期间正在转飞机, 别让转动角速度污染陀螺零偏!
                                   * 稳速旋转方差低→会被误判成"静止"→把转速学进零偏→静止后yaw按错零偏飘。
                                   * (这就是"先校陀螺再校罗盘yaw就飘"的根因。) */

    s_biasSum[0]   += rx;             s_biasSum[1]   += ry;             s_biasSum[2]   += rz;
    s_biasSumSq[0] += (int64_t)rx*rx; s_biasSumSq[1] += (int64_t)ry*ry; s_biasSumSq[2] += (int64_t)rz*rz;

    if (++s_biasCnt >= SENSORS_NBR_OF_BIAS_SAMPLES) {
        bool ok = true;
        float mean[3];
        for (int i = 0; i < 3; i++) {
            mean[i] = (float)s_biasSum[i] / SENSORS_NBR_OF_BIAS_SAMPLES;
            int64_t var = s_biasSumSq[i]
                        - (s_biasSum[i] * s_biasSum[i]) / SENSORS_NBR_OF_BIAS_SAMPLES;
            if (var / SENSORS_NBR_OF_BIAS_SAMPLES >= GYRO_VARIANCE_BASE)
                ok = false;
        }
        if (ok) {
            for (int i = 0; i < 3; i++) s_gyroBias[i] = mean[i];   /* 单位: LSB */
            s_biasFound = true;
        }
        memset(s_biasSum,   0, sizeof(s_biasSum));
        memset(s_biasSumSq, 0, sizeof(s_biasSumSq));
        s_biasCnt = 0;
    }
}

/* V22.16: 地面站"陀螺仪校准" → 重置零偏, 让 updateGyroBias 重新静止采样计算 */
void sensorsRecalibrateGyro(void) {
    memset(s_biasSum,   0, sizeof(s_biasSum));
    memset(s_biasSumSq, 0, sizeof(s_biasSumSq));
    s_biasCnt   = 0;
    s_biasFound = false;
}

/* V22.24: 地面站"罗盘/磁力计校准" → 开始采 min/max。校准期间【水平转动飞机几圈】(各方向都转到),
 * 约 12 秒后自动完成, 算出硬磁偏置(去掉固定磁偏)和软磁缩放(各轴量程归一)。 */
void sensorsStartMagCal(void) {
    if (getCommanderKeyFlight() || getCommanderKeyland()) return;   /* V23.35 D38 */
    for (int i = 0; i < 3; i++) { s_magMin[i] = 1e9f; s_magMax[i] = -1e9f; }
    s_magCalCnt    = 0;
    s_magCalActive = true;
}
static void processAccGyro(const int16_t acc[3], const int16_t gyr[3],
                           float gPerLsb, float degPerLsb) {
    updateGyroBias(gyr[0], gyr[1], gyr[2]);

    float gx = ((float)gyr[0] - s_gyroBias[0]) * degPerLsb;
    float gy = ((float)gyr[1] - s_gyroBias[1]) * degPerLsb;
    float gz = ((float)gyr[2] - s_gyroBias[2]) * degPerLsb;

    float ax = (float)acc[0] * gPerLsb;
    float ay = (float)acc[1] * gPerLsb;
    float az = (float)acc[2] * gPerLsb;

    /* 重力缩放因子: 零偏找到后采 200 个样本 (对照原版 processAccScale) */
    if (s_biasFound && !s_accScaleDone) {
        s_accScaleSum += sqrtf(ax*ax + ay*ay + az*az);
        if (++s_accScaleCnt >= SENSORS_ACC_SCALE_SAMPLES) {
            s_accScale     = s_accScaleSum / SENSORS_ACC_SCALE_SAMPLES;
            s_accScaleDone = true;
        }
    }
    if (s_accScaleDone && s_accScale > 0.5f) {
        ax /= s_accScale; ay /= s_accScale; az /= s_accScale;
    }

    /* V23.22: gyro陷波apply已删(见文件顶说明) */

    /* V22.69: 陀螺振动诊断累加(此处=陷波后/软低通前)。逐样本|Δgyro|, 心跳取均值报 vib=。 */
    s_vibAcc += fabsf(gx - s_vibPrev[0]) + fabsf(gy - s_vibPrev[1]) + fabsf(gz - s_vibPrev[2]);
    s_vibPrev[0] = gx; s_vibPrev[1] = gy; s_vibPrev[2] = gz;
    s_vibCnt++;

    Axis3f a, g;
    a.x = lpf2pApply(&s_accLpf[0],  ax);
    a.y = lpf2pApply(&s_accLpf[1],  ay);
    a.z = lpf2pApply(&s_accLpf[2],  az);
    g.x = lpf2pApply(&s_gyroLpf[0], gx);
    g.y = lpf2pApply(&s_gyroLpf[1], gy);
    g.z = lpf2pApply(&s_gyroLpf[2], gz);

    if (s_accQ)  xQueueOverwrite(s_accQ,  &a);
    if (s_gyroQ) xQueueOverwrite(s_gyroQ, &g);
}

/*──────────────────────────────────────────────────────────────
  GY-91: MPU9250 探测 + 初始化 (真实 TWIM0)
──────────────────────────────────────────────────────────────*/
static bool mpuProbeAndInit(void) {
    /* SAO/SDO (D9) 拉低 → MPU=0x68, BMP280=0x76 */
    pinMode(GY91_AD0, OUTPUT);
    digitalWrite(GY91_AD0, LOW);
    vTaskDelay(pdMS_TO_TICKS(10));

    static const uint8_t addrs[2] = { 0x68, 0x69 };
    for (int a = 0; a < 2; a++) {
        uint8_t addr = addrs[a], who = 0;

        i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_PWR_MGMT_1, 0x80);  /* 复位 */
        vTaskDelay(pdMS_TO_TICKS(50));
        if (!i2cdevReadByte(I2C1_DEV, addr, MPU6500_RA_WHO_AM_I, &who))
            continue;

        /* 0x71=MPU9250 0x73=MPU9255 0x70=MPU6500 0x68=MPU6050
         * 0x38/0x39=部分国产替代片 (原厂固件也接受) */
        if (who == 0x71 || who == 0x73 || who == 0x70 ||
            who == 0x68 || who == 0x38 || who == 0x39) {
            s_mpuAddr = addr;
            s_mpuWho  = who;

            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_PWR_MGMT_1, 0x01);  /* 唤醒, PLL X陀螺时钟 */
            vTaskDelay(pdMS_TO_TICKS(10));
            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_GYRO_CONFIG,
                            (uint8_t)(MPU6500_GYRO_FS_2000 << 3));
            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_ACCEL_CONFIG,
                            (uint8_t)(MPU6500_ACCEL_FS_16 << 3));
            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_ACCEL_CONFIG_2,
                            MPU6500_ACCEL_DLPF_BW_41);
            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_CONFIG,
                            MPU_GYRO_DLPF);                              /* V22.19: 可调陀螺DLPF(默认42Hz, 滤转接板振动) */
            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_SMPLRT_DIV, 0x00); /* 1kHz */
            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_INT_ENABLE,  0x00); /* 轮询, 不用INT */
            i2cdevWriteByte(I2C1_DEV, addr, MPU6500_RA_INT_PIN_CFG, 0x02); /* bypass → AK8963 */
            vTaskDelay(pdMS_TO_TICKS(5));
            return true;
        }
    }
    return false;
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】sensorsDeviceInit — 感测子系统的"开机总装"(顺序即安全)
 *   这段做了什么(顺序不可换): ① 四条深度1队列先创建并填零/NAN —
 *   任何任务提前 Peek 都安全(V22: NULL队列解引用=HardFault复位环的根修);
 *   ② 双二阶低通初始化; ③ GY-91 电源循环(V22.38: 等价手动拔插, 解
 *   BMP280 冷启动不应答, 断电期间 SCL/SDA 拉低防寄生供电); ④ TWIM0 →
 *   MPU 双地址探测 → AK8963(bypass) → 双IMU时并启板载 LSM;
 *   ⑤ 失败则降级板载 LSM(TWIM1 独立总线); ⑥ BMP280 无论如何探一次;
 *   ⑦ 生成诊断串(开机 SENSORS: 那一行)。
 * ══════════════════════════════════════════════════════════════ */
/*──────────────────────────────────────────────────────────────
  sensorsDeviceInit — 队列先建, 再探测
──────────────────────────────────────────────────────────────*/
static void sensorsDeviceInit(void) {
    /* 1) 队列必须最先创建并填零 → 任何任务提前 Peek 都安全 */
    s_accQ  = xQueueCreate(1, sizeof(Axis3f));
    s_gyroQ = xQueueCreate(1, sizeof(Axis3f));
    s_magQ  = xQueueCreate(1, sizeof(Axis3f));
    s_baroQ = xQueueCreate(1, sizeof(baro_t));
    {
        Axis3f z = {{0, 0, 0}};
        baro_t bz; bz.pressure = 0; bz.temperature = 0; bz.asl = NAN;   /* V22.38: 初值无效, 估测器跳过直到首个有效读数 */
        if (s_accQ)  xQueueOverwrite(s_accQ,  &z);
        if (s_gyroQ) xQueueOverwrite(s_gyroQ, &z);
        if (s_magQ)  xQueueOverwrite(s_magQ,  &z);
        if (s_baroQ) xQueueOverwrite(s_baroQ, &bz);
    }

    /* 2) 低通滤波器 (500Hz 采样) */
    for (int i = 0; i < 3; i++) {
        lpf2pInit(&s_gyroLpf[i], SENSOR9_UPDATE_RATE, GYRO_LPF_CUTOFF_FREQ);
        lpf2pInit(&s_accLpf[i],  SENSOR9_UPDATE_RATE, ACCEL_LPF_CUTOFF_FREQ);
        /* V23.22: 陀螺陷波init已删 */
    }

    /* 3) GY-91 外部总线 (TWIM0, 内部上拉; 模块不在也不会卡死) */
#if GY91_PWR_CYCLE_ENABLE
    /* V22.38: 开机给 GY-91 一次干净的断电重上电(等价手动拔插), 解决 BMP280 冷启动不应答。
     * 断电期间把 SCL/SDA 也拉低, 避免经内部上拉寄生供电导致断不干净。*/
    {
        const int onL  = GY91_PWR_ON_LEVEL;
        const int offL = (GY91_PWR_ON_LEVEL == HIGH) ? LOW : HIGH;
        pinMode(GY91_PWR_PIN, OUTPUT);
        pinMode(GY91_SCL, OUTPUT); digitalWrite(GY91_SCL, LOW);
        pinMode(GY91_SDA, OUTPUT); digitalWrite(GY91_SDA, LOW);
        digitalWrite(GY91_PWR_PIN, offL);  delay(GY91_PWR_OFF_MS);   /* 断电 */
        digitalWrite(GY91_PWR_PIN, onL);                            /* 上电 */
        pinMode(GY91_SCL, INPUT);   /* 释放, 交回 i2cdevInit/上拉 */
        pinMode(GY91_SDA, INPUT);
        delay(GY91_PWR_SETTLE_MS);  /* 等 BMP280 POR 完成 */
    }
#endif
    i2cdevInit(I2C1_DEV);

    if (mpuProbeAndInit()) {
        s_imuType      = IMU_MPU9250;
        s_isMPUPresent = true;

        /* AK8963 磁力计 (bypass 后直接挂在外部总线 0x0C) */
        ak8963Init(I2C1_DEV);
        if (ak8963TestConnection()) {
            s_isMagPresent = true;
            ak8963SetMode(AK8963_MODE_16BIT | AK8963_MODE_CONT2);   /* 16bit 100Hz */
        }
#if DUAL_IMU_GYRO
        /* V22.27 #5: 同时初始化板载 LSM6(独立 TWIM1 总线), 双陀螺融合 */
        s_dualLsmOk = lsm6ds3Init();
#endif
    } else {
        /* GY-91 没有 → 板载 LSM6DS3TR-C 降级 (上电+TWIM1, 见 lsm6ds3.cpp) */
        if (lsm6ds3Init()) {
            s_imuType      = IMU_LSM6DS3;
            s_isMPUPresent = true;          /* "有可用IMU", 供遥控器ACK使用 */
        } else {
            s_imuType = IMU_NONE;
        }
    }

#ifdef LSM_GYRO_LPF_HZ
    /* V22.86: LSM6 单用无硬件陀螺DLPF → 用单独更低的软陀螺LPF压噪防抖(MPU路径保持80Hz不变)。
     * 上面LPF已按80Hz初始化过, 这里在确定是LSM6后重初始化到 LSM_GYRO_LPF_HZ。 */
    if (s_imuType == IMU_LSM6DS3) {
        for (int i = 0; i < 3; i++)
            lpf2pInit(&s_gyroLpf[i], SENSOR9_UPDATE_RATE, LSM_GYRO_LPF_HZ);
    }
#endif

    /* 4) BMP280: 无论哪种 IMU 都探测一次 (在 GY-91 外部总线上) */
    bmp280Init(I2C1_DEV);
    if (bmp280IsPresent())
        s_isBaroPresent = true;

    /* 5) 诊断字符串 (S4 阶段打印) */
    if (s_imuType == IMU_MPU9250) {
        snprintf(s_diag, sizeof(s_diag),
                 "IMU=MPU9250@0x%02X who=0x%02X MAG=%s BARO=%s",
                 s_mpuAddr, s_mpuWho,
                 s_isMagPresent  ? "AK8963" : "none",
                 s_isBaroPresent ? "BMP280" : "none");
    } else if (s_imuType == IMU_LSM6DS3) {
        snprintf(s_diag, sizeof(s_diag),
                 "IMU=LSM6DS3@0x%02X who=0x%02X (onboard) MAG=none BARO=%s",
                 lsm6ds3GetAddr(), lsm6ds3GetWhoAmI(),
                 s_isBaroPresent ? "BMP280" : "none");
    } else {
        snprintf(s_diag, sizeof(s_diag),
                 "IMU=NONE!! check wiring  BARO=%s",
                 s_isBaroPresent ? "BMP280" : "none");
    }
}

void sensorsInit(void) {
    if (s_isInit) return;
    sensorsDeviceInit();
    s_isInit = true;
}

bool sensorsTest(void)              { return s_isInit && (s_imuType != IMU_NONE); }
bool sensorsAreCalibrated(void)     { return s_biasFound; }

#if DUAL_IMU_GYRO
/* V22.60: 取混合前 MPU / LSM 陀螺(deg/s)供遥测验证轴向。
 * 转动飞机某一轴, 两组对应轴应【同号同步】; 若某轴反号/串到别轴 → 改 config.h 的 LSM6_AXIS_MAP/SIGN。
 * lsmBiasReady=LSM零偏是否已确定。 */
void sensorsGetDualGyroDbg(float mpu[3], float lsm[3], bool* lsmBiasReady) {
    for (int i = 0; i < 3; i++) {
        mpu[i] = s_dbgGyrMpu[i] * SENSORS_DEG_PER_LSB_MPU;
        lsm[i] = s_dbgGyrLsm[i] * SENSORS_DEG_PER_LSB_MPU;
    }
    if (lsmBiasReady) *lsmBiasReady = s_biasFound;   /* 主陀螺零偏(混合后统一去偏)是否已确定 */
}
#endif
/* V22.29: 磁校准进度 — 心跳显示, 让\"罗盘校准\"可见。
 *   -1 = 未在校准(空闲/已完成);  0..100 = 校准中的百分比(此时应水平转圈飞机)。
 *   若点了校准却一直停在 0 → 磁力计没在出数据(AK8963 未检测到/不通)。 */
int getMagCalPercent(void) {
    if (s_magCalActive) return (int)((long)s_magCalCnt * 100 / MAG_CAL_SAMPLES);
    return s_magCalDone ? 100 : -1;   /* V22.49: 校准中=进度0~99; 完成=100; 从未校准=-1 */
}
bool sensorsIsMagCalibrated(void) { return s_magCalDone; }   /* V22.49: 磁偏航融合是否该生效 */
void sensorsGetMagCal(float bias[3], float scale[3]) {
    for (int i = 0; i < 3; i++) { bias[i] = s_magBias[i]; scale[i] = s_magScale[i]; }
}
bool getIsMPU9250Present(void)      { return s_isMPUPresent; }
bool getIsBaroPresent(void)         { return s_isBaroPresent; }
/* V22.45/46 诊断 getter */
uint32_t sensorsGetBaroReadOK(void)   { return s_baroReadOK; }
uint32_t sensorsGetBaroReadTrue(void) { return s_baroReadTrue; }
float    sensorsGetBaroLastPa(void)   { return s_baroLastPa; }
uint32_t sensorsBaroAgeMs(void)       { return s_baroOkMs ? (millis() - s_baroOkMs) : 0xFFFFFFFFu; }  /* V22.95: 有效气压距今 ms */
float    sensorsGetBaroAsl(void)    { baro_t b; b.asl = 0; if (s_baroQ) xQueuePeek(s_baroQ, &b, 0); return b.asl; }
float    sensorsGetBaroTemp(void)   { baro_t b; b.temperature = 0; if (s_baroQ) xQueuePeek(s_baroQ, &b, 0); return b.temperature; }  /* V22.64: 诊断温漂 */
/* V22.69: 取陀螺振动指标(均值 |Δgyro| deg/s/样本)并清零, 由心跳每2s调用一次。值越大=高频振动越强。
 * 注意: 当前 MPU_GYRO_DLPF=20Hz 会把高频砍掉 → 此值通常很小; 调高 DLPF 后才真正反映振动。 */
float    sensorsGetGyroVib(void)    { if (s_vibCnt == 0) return 0.0f; float v = (float)(s_vibAcc / s_vibCnt / 3.0); s_vibAcc = 0.0; s_vibCnt = 0; return v; }
bool getIsMagPresent(void)          { return s_isMagPresent; }
bool sensorsUsingOnboardIMU(void)   { return s_imuType == IMU_LSM6DS3; }  /* V22.88: 是否在用板载LSM6(=无GY-91降级) */
const char* sensorsGetDiagString(void) { return s_diag; }

/*──────────────────────────────────────────────────────────────
  sensorsAcquire — V22: 只读队列 (对照原版), 不触碰任何硬件!
  由 stabilizerTask 500Hz 调用
──────────────────────────────────────────────────────────────*/
void sensorsAcquire(sensorData_t* out, uint32_t tick) {
    (void)tick;
    if (s_accQ)  xQueuePeek(s_accQ,  &out->acc,  0);
    if (s_gyroQ) xQueuePeek(s_gyroQ, &out->gyro, 0);
    if (s_magQ)  xQueuePeek(s_magQ,  &out->mag,  0);
    if (s_baroQ) xQueuePeek(s_baroQ, &out->baro, 0);
}

/*──────────────────────────────────────────────────────────────
  硬件采样 (仅 sensorsTask 调用)
──────────────────────────────────────────────────────────────*/
/* V22.3: GY-91 运行中掉线 → 切到板载 LSM6DS3 (热失效转移)
 * 热拔 GY-91 时 MPU 读取持续失败, 旧版会让姿态数据冻结/漂移 →
 * 几秒后翻倒检测误触发停桨(USB), 或电机受错误姿态驱动电流尖峰 → 电池欠压重启。
 * 这里检测到连续失败就切到板载 6 轴, 姿态保持有效, 不停桨不重启。*/
static uint16_t s_mpuFailCnt = 0;
#define IMU_RUNTIME_FAIL_LIMIT  100   /* 100×2ms ≈ 200ms: 飞行中快速降级(保命) */
#define IMU_GROUND_FAIL_LIMIT   1000  /* V22.39: 1000×2ms ≈ 2s: 地面降级阈值。
                                       * 短抖动(<2s, 连接不稳会自恢复)不误切, 保住 GY-91 磁力计/气压;
                                       * 真拔掉持续失败>2s → 自动切板载 LSM。想要旧的"立即切"可改回 100。*/

static void switchToOnboardIMU(void) {
    if (lsm6ds3Init()) {
        s_imuType      = IMU_LSM6DS3;
        s_isMagPresent = false;   /* AK8963 随 GY-91 一起没了 */
        s_isBaroPresent= false;   /* BMP280 也在 GY-91 上, 定高自动降级为纯姿态 */
        /* 新传感器需要重新标定零偏/重力(量程不同) */
        s_biasFound    = false; s_biasCnt = 0;
        memset(s_biasSum,   0, sizeof(s_biasSum));
        memset(s_biasSumSq, 0, sizeof(s_biasSumSq));
        s_accScaleDone = false; s_accScaleCnt = 0; s_accScaleSum = 0.0f;
#ifdef LSM_GYRO_LPF_HZ
        /* V22.86: 飞行中失效转移到LSM6 → 也切到LSM专用更低陀螺LPF压噪防抖 */
        for (int i = 0; i < 3; i++)
            lpf2pInit(&s_gyroLpf[i], SENSOR9_UPDATE_RATE, LSM_GYRO_LPF_HZ);
#endif
        snprintf(s_diag, sizeof(s_diag),
                 "IMU=LSM6DS3@0x%02X (failover from GY-91) MAG=none BARO=none",
                 lsm6ds3GetAddr());
    }
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】sensorsReadHardware — 每2ms一拍的"总采样调度"(唯一碰I2C的地方)
 *   这段做了什么(按tick错拍, 互不相撞):
 *   · 每拍: MPU 14字节突发读 → 轴映射 → [双IMU软分歧加权融合 V22.60:
 *     LSM换算MPU当量, 分歧越大LSM权重平滑降到0, 无硬切换跳变] → processAccGyro
 *   · 读失败: 双阈值热失效转移 — 飞行200ms快速降级保命 / 地面2s防抖动误切
 *   · tick%10==0: AK8963 磁力计 50Hz + 磁校 min/max 采样(完成时触发陀螺重校)
 *   · tick%500==250: BMP280 保活重写模式(V22.45: 防掉电回sleep数据冻结)
 *   · tick%10==5: BMP280 50Hz 读 → 物理范围检查(300~1100hPa) →
 *     【冻结检测 V23.07/10】连续40个一模一样的原始气压=物理不可能(真传感器
 *     有±1.3Pa噪声)=冻结→停止刷新鲜度→触发baroLoss保护; 电机停时豁免
 *     (地面静止气压本就不变) → asl 换cm → 低通 → 入队
 *   · 连续150次无效(~3s): 标记气压离线 → 地面时每3s完整重探(重init+重读校准)
 * ══════════════════════════════════════════════════════════════ */
static void sensorsReadHardware(uint32_t tick) {
    if (s_imuType == IMU_MPU9250) {
        uint8_t buf[14];
        if (i2cdevRead(I2C1_DEV, s_mpuAddr, MPU6500_RA_ACCEL_XOUT_H, 14, buf)) {
            s_mpuFailCnt = 0;
            /* MPU: 大端; 顺序 加速XYZ + 温度 + 陀螺XYZ */
            int16_t acc[3] = {
                (int16_t)((buf[0]  << 8) | buf[1]),
                (int16_t)((buf[2]  << 8) | buf[3]),
                (int16_t)((buf[4]  << 8) | buf[5]) };
            int16_t gyr[3] = {
                (int16_t)((buf[8]  << 8) | buf[9]),
                (int16_t)((buf[10] << 8) | buf[11]),
                (int16_t)((buf[12] << 8) | buf[13]) };
            remap3(acc, MPU_MAP, MPU_SIGN);
            remap3(gyr, MPU_MAP, MPU_SIGN);
#if DUAL_IMU_GYRO
            /* ════ V22.60 双IMU陀螺融合(彻底版) ════
             * 解决旧版三缺点: (1)降速读陈旧值阶跃→颤抖; (2)硬分歧切换跳变→颤抖; (3)LSM零偏未单独校准→单向漂移。
             * 新做法: 提高LSM读率(默认DIV=2)减阶跃; LSM减自身零偏消漂移; 软分歧加权(权重随分歧平滑降)消跳变。
             * 仍只混陀螺, 加速度用MPU(避免两IMU杆臂误差)。 */
            if (s_dualLsmOk) {
                static int16_t s_lsmGyr[3] = {0, 0, 0};   /* 最近一次 LSM 陀螺(已remap, 原始LSB) */
                static uint8_t s_lsmDiv = 0;
                if (++s_lsmDiv >= DUAL_IMU_LSM_DIV) {      /* 默认2=250Hz, 陈旧阶跃很小; 见config注释 */
                    s_lsmDiv = 0;
                    int16_t lacc[3], lgyr[3];
                    if (lsm6ds3Read(lacc, lgyr)) {
                        remap3(lgyr, LSM_MAP, LSM_SIGN);
                        s_lsmGyr[0] = lgyr[0]; s_lsmGyr[1] = lgyr[1]; s_lsmGyr[2] = lgyr[2];
                    }
                }

                const float w     = DUAL_IMU_MPU_WEIGHT;
                const float ratio = (float)LSM6DS3_DEG_PER_LSB_2000 /
                                    (float)MPU6500_DEG_PER_LSB_2000;   /* LSM_LSB → MPU当量 LSB, ≈1.147 */
#if DUAL_IMU_FUSE_YAW
                const int nAxis = 3;       /* 编译期强制融合 X/Y/Z(含yaw) */
#else
                /* V22.64: yaw(Z)是否融合 = 磁是否已校准。磁校准后磁力计在修正yaw漂→融LSM的Z降噪才安全;
                 * 未校准时yaw无绝对参考, 只用MPU(避免LSM的Z零偏带歪)。X/Y(roll/pit)始终融合。 */
                const int nAxis = s_magCalDone ? 3 : 2;
#endif
                for (int i = 0; i < 3; i++) {
                    /* LSM 换算成 MPU 当量。【不在这里单独减LSM零偏】——零偏由 processAccGyro 内的
                     * 主校准对【混合后】信号统一去掉(否则会和主校准重复减→残留→yaw漂)。 */
                    float lsmConv = (float)s_lsmGyr[i] * ratio;
                    s_dbgGyrMpu[i] = (float)gyr[i];   /* 调试: 混合前 MPU(MPU LSB) */
                    s_dbgGyrLsm[i] = lsmConv;          /* 调试: LSM(MPU当量 LSB) → 轴向应与 MPU 同号同轴 */
                    if (i >= nAxis) continue;          /* yaw 轴不融合时跳过(仍保留上面的调试值) */
                    /* 软分歧加权: 分歧 diff 在 [0, DISAGREE_LSB] 内, LSM权重从标称(1-w)平滑降到0。
                     * 一致→满额混合降噪; 某颗尖峰→平滑退回纯MPU, 无硬切换跳变。 */
                    float diff = (float)gyr[i] - lsmConv;
                    if (diff < 0.0f) diff = -diff;
                    float wl = 1.0f - w;
                    if (DUAL_IMU_DISAGREE_LSB > 0) {
                        float f = 1.0f - diff / (float)DUAL_IMU_DISAGREE_LSB;
                        if (f < 0.0f) f = 0.0f;
                        wl *= f;
                    }
                    gyr[i] = (int16_t)((1.0f - wl) * (float)gyr[i] + wl * lsmConv);
                }
            }
#endif
            processAccGyro(acc, gyr, SENSORS_G_PER_LSB_MPU, SENSORS_DEG_PER_LSB_MPU);
        } else {
            /* V22.39: GY-91 读失败。区分"短暂抖动(连接不稳会自恢复)"和"真拔掉(持续失败)":
             *   飞行中用短超时(200ms)快速降级保命; 地面用长超时(2s)再降级 ——
             *   短抖动 <2s 不误切(保住磁力计/气压), 真拔掉 >2s 自动切板载 LSM(恢复可用)。
             * 修正 V22.37 "只有飞行中才降级" 的副作用: 地面真拔掉 GY-91 也能自动用 LSM。*/
            s_mpuFailCnt++;
            bool airborne = (powerGetLastThrust() > 5000)
                          || getCommanderKeyFlight() || getCommanderKeyland();
            uint16_t failLimit = airborne ? IMU_RUNTIME_FAIL_LIMIT : IMU_GROUND_FAIL_LIMIT;
            if (s_mpuFailCnt > failLimit) {
                switchToOnboardIMU();   /* 持续掉线 → 板载 LSM 接管 */
                s_mpuFailCnt = 0;
            }
            return;   /* 本周期无新数据; 未超时则保持 GY-91 持续重试 */
        }

        /* AK8963 磁力计 50Hz */
        if (s_isMagPresent && (tick % 10 == 0)) {
            if (ak8963GetDataReady()) {
                int16_t mx, my, mz;
                ak8963GetHeading(&mx, &my, &mz);
                if (!ak8963GetOverflowStatus()) {
                    Axis3f m;
                    /* AK8963 轴 → MPU9250 机体轴 (MPU内置磁力计标准关系):
                     *   机体X = AK_Y, 机体Y = AK_X, 机体Z = -AK_Z
                     * GY-91 的 MPU 是 identity remap(GY91_AXIS_SIGN={1,1,1}), 故这即机体系。*/
                    float bx =  (float)my;
                    float by =  (float)mx;
                    float bz = -(float)mz;
                    if (s_magCalActive) {
                        if (bx < s_magMin[0]) s_magMin[0] = bx;
                        if (bx > s_magMax[0]) s_magMax[0] = bx;
                        if (by < s_magMin[1]) s_magMin[1] = by;
                        if (by > s_magMax[1]) s_magMax[1] = by;
                        if (bz < s_magMin[2]) s_magMin[2] = bz;
                        if (bz > s_magMax[2]) s_magMax[2] = bz;
                        if (++s_magCalCnt >= MAG_CAL_SAMPLES) {
                            float avg = 0.0f, rng[3];
                            for (int i = 0; i < 3; i++) {
                                s_magBias[i] = (s_magMin[i] + s_magMax[i]) * 0.5f;
                                rng[i] = (s_magMax[i] - s_magMin[i]) * 0.5f;
                                avg += rng[i];
                            }
                            avg /= 3.0f;
                            for (int i = 0; i < 3; i++)
                                s_magScale[i] = (rng[i] > 1.0f) ? (avg / rng[i]) : 1.0f;
                            s_magCalActive = false;
                            s_magCalDone   = true;   /* V22.49: 校准完成 → 磁偏航融合从此生效 */
                            /* V22.68: 磁校完成→yaw融合纳入LSM的Z(nAxis 2→3), Z零偏基准变了 → 触发陀螺零偏重校
                             * (在nAxis=3下), 飞机静止后~2s自动完成。配合上面"磁校期间不采零偏",
                             * 彻底消除"先校陀螺再校罗盘"时转动污染零偏→yaw飘。期间cal=NO属正常(在重校)。 */
                            s_biasFound = false;
                            memset(s_biasSum,   0, sizeof(s_biasSum));
                            memset(s_biasSumSq, 0, sizeof(s_biasSumSq));
                            s_biasCnt = 0;
                        }
                    }
                    /* 单位无所谓(航向只看比值); 除 MAG_GAUSS_PER_LSB 仅为量级一致 */
                    m.x = (bx - s_magBias[0]) * s_magScale[0] / MAG_GAUSS_PER_LSB;
                    m.y = (by - s_magBias[1]) * s_magScale[1] / MAG_GAUSS_PER_LSB;
                    m.z = (bz - s_magBias[2]) * s_magScale[2] / MAG_GAUSS_PER_LSB;
                    if (s_magQ) xQueueOverwrite(s_magQ, &m);
                }
            }
        }
    } else if (s_imuType == IMU_LSM6DS3) {
        int16_t acc[3], gyr[3];
        if (lsm6ds3Read(acc, gyr)) {
            remap3(acc, LSM_MAP, LSM_SIGN);
            remap3(gyr, LSM_MAP, LSM_SIGN);
            processAccGyro(acc, gyr, LSM6DS3_G_PER_LSB_16, LSM6DS3_DEG_PER_LSB_2000);
        }
    }

    /* V22.45: 气压计保活 — ~1s 重写一次模式寄存器。GY-91 热插拔/电源毛刺会让 BMP280 掉电
     * 复位回 sleep(默认态, 不转换)→ 数据冻结, 而原来只在"未认到"时才重探(本块下面 else),
     * "已认到"状态下没人救它。重写 CTRL_MEAS 让它恢复 Normal。tick%500==250 单独占一拍, 不和读取撞。*/
    if (s_isBaroPresent && (tick % 500 == 250)) bmp280EnsureMode();

    /* BMP280 50Hz — asl 单位 cm (对照原版 *100.f) */
    if (s_isBaroPresent && (tick % 10 == 5)) {
        float press_hPa = 0, temp_C = 0;
        bool readOK = bmp280Read(&press_hPa, &temp_C);
        if (readOK) { s_baroReadTrue++; s_baroLastPa = press_hPa; }  /* V22.46 诊断: I2C读成功次数 + 原始气压 */
        /* V22.38: 只接受物理有效气压(300~1100 hPa), 挡掉 BMP280 刚上电/未就绪/sleep 的垃圾读数 */
        if (readOK && press_hPa >= 300.0f && press_hPa <= 1100.0f) {
            s_baroReadOK++;                                         /* 成功读到有效气压计数 */
            /* V23.07: 【冻结检测】— BMP280 会在供电毛刺后进入"读得到但值卡死"状态: I2C成功、
             * 数值在合理范围, 但每次返回完全相同的原始气压 → V22.95的"读不到才算失效"抓不住它 →
             * 定高瞎飞: 目标误差永远在 → VZ积分顶满 → 【一直往上飞】(你实测: 电机5-6万爬升而
             * alt只动6cm、bpa一位不变)。真传感器有±1.3Pa噪声, 连续40个(≈0.8s)完全相同=物理不可能
             * = 冻结 → 停止刷新鲜度 → 触发 V22.95 保护(关Z控制器+开环缓收, fs=B); 值一动自动恢复。 */
            {
                static float    s_frzPa  = 0.0f;
                static uint16_t s_frzCnt = 0;
                if (s_baroLastPa == s_frzPa) { if (s_frzCnt < 1000) s_frzCnt++; }
                else { s_frzCnt = 0; s_frzPa = s_baroLastPa; }
                /* V23.10 关键修复: 冻结门只在【电机转着】时生效。地面静止空气气压值本就长期不变
                 * → 原来 s_frzCnt 攒满后停止刷新新鲜度 → baroStale 恒真 → 保护常驻、每次起飞清 keyFlight
                 * = 你实测"第二次点击起飞不动"的根因。电机停时无条件刷新, 地面永远健康。
                 * (顺带修 -Wmisleading-indentation: 原 if 无大括号, 下面的块跑在 if 之外。) */
                if (powerGetLastThrust() == 0) s_frzCnt = 0;
                if (s_frzCnt < 40) {
                    s_baroOkMs = millis();                          /* 飞行中真冻结>~400ms才停止刷新 */
                }
                /* V23.19: 已删气压"值年龄"getter(无消费者且地面静置=值不动会误判失效, 埋雷)。
                 * 冻结防护由上面 s_frzCnt(电机门控)完成, 足够。 */
            }
            s_baroFailStreak = 0;                                   /* V22.46: 有效→清失败streak */
            baro_t b;
            b.pressure    = press_hPa;
            b.temperature = temp_C;
            b.asl         = bmp280GetAltitude(press_hPa) * 100.0f;   /* m → cm */
            if (isfinite(b.asl)) {                                   /* V22.46: -fno-finite-math-only 后此护栏真正生效 */
#if BARO_ALT_LPF_ENABLE
                /* V22.27 #4: 气压海拔低通(50Hz采样), 首次用当前值初始化避免上电跳变 */
                if (!s_baroAltLpfInit) {
                    lpf2pInit(&s_baroAltLpf, 50.0f, BARO_ALT_LPF_HZ);
                    lpf2pReset(&s_baroAltLpf, b.asl);
                    s_baroAltLpfInit = true;
                }
                b.asl = lpf2pApply(&s_baroAltLpf, b.asl);
#endif
                if (s_baroQ) xQueueOverwrite(s_baroQ, &b);
            }
        } else {
            /* V22.46: 连续读不到有效气压(读失败或超范围)→ 累计; 超 ~3s(150×20ms)标记气压计离线。
             * 这会让估测器把高度清零(避免 alt 卡死/脏值), 并触发下面的 3s 重探 = 完整
             * soft-reset + 重读校准 + 重配 Normal。解决: 热插拔后停 sleep / 校准被读坏 → 永远 brd=0。
             * 保活(重写CTRL_MEAS)救不了"校准读坏"这种, 必须完整重 init。 */
            if (++s_baroFailStreak >= 150) {
                s_isBaroPresent  = false;
                s_baroAltLpfInit = false;
                s_baroFailStreak = 0;
            }
        }
    }
    /* V22.35: 气压计没认到时, 不在飞行中就周期(~3s)重探一次 —— BMP280 上电慢/边缘
     * 连接导致开机没探到时能自动认回来。仅地面(未起飞/降落)做, 避免 init 延时影响飞行。 */
    else if (!s_isBaroPresent && (tick % 1500 == 750)
             && !getCommanderKeyFlight() && !getCommanderKeyland()) {
        bmp280Init(I2C1_DEV);
        if (bmp280IsPresent()) { s_isBaroPresent = true; s_baroAltLpfInit = false; }  /* V22.38: 重新上线 → LPF 重置, 用首个有效值初始化 */
    }
}

/* sensorsTask: 500Hz, 唯一的 I2C 使用者 */
void sensorsTask(void* param) {
    (void)param;
    sensorsInit();
    vTaskDelay(pdMS_TO_TICKS(150));

    TickType_t xLast = xTaskGetTickCount();
    uint32_t tick = 0;
    while (1) {
        vTaskDelayUntil(&xLast, pdMS_TO_TICKS(2));
        sensorsReadHardware(tick++);
    }
}

bool sensorsReadGyro(Axis3f* g)  { return s_gyroQ && xQueuePeek(s_gyroQ, g, 0) == pdTRUE; }
bool sensorsReadAcc(Axis3f* a)   { return s_accQ  && xQueuePeek(s_accQ,  a, 0) == pdTRUE; }
bool sensorsReadMag(Axis3f* m)   { return s_magQ  && xQueuePeek(s_magQ,  m, 0) == pdTRUE; }
bool sensorsReadBaro(baro_t* b)  { return s_baroQ && xQueuePeek(s_baroQ, b, 0) == pdTRUE; }
