#pragma once
// ═══════════════════════════════════════════════════════════════
//  Anchor 配置 — XIAO ESP32S3
//  ⚠ 以下「系統共用參數」必須與 fw-gateway/src/config.h 完全一致
// ═══════════════════════════════════════════════════════════════

// ── 建置開關 ────────────────────────────────────────────────────
// NO_BLE=1 → 不編譯 NimBLE，只發 ESP-NOW 心跳（二分定位用）。
// 必須有預設值：`#if !NO_BLE` 對未定義的宏是安全的（當 0），
// 但把 NO_BLE 當成一般 C++ 運算式使用時，未定義就是編譯錯誤。
#ifndef NO_BLE
#define NO_BLE 0
#endif

// ── 本機 ────────────────────────────────────────────────────────
#ifndef ANCHOR_ID
#define ANCHOR_ID            1        // 1..4，建議用 platformio.ini 的 -DANCHOR_ID=n 覆蓋
#endif

// ── 系統共用參數（與 Gateway 保持一致）──────────────────────────
#define SYS_WIFI_CHANNEL     7        // ESP-NOW 頻道。必須 = ESPFC rclink 接收端頻道
                                      // (espnow-rclink 預設 7)。整個系統統一一個頻道。
#define GWM_MAGIC0           0xA5     // 自訂 ESP-NOW 幀魔數（避開 rclink 的 0x01/0x10/0x11/0xFE/0xFF）
#define GWM_MAGIC1           'A'      // 'A' = Anchor 報文
#define GWM_VER              1
#define GWM_CRC_INIT         0x66

// ── BLE 信標格式（飛控端之後照這個發）────────────────────────────
// Manufacturer Data: [FF FF] ['M'] ['F'] [droneId u8] [seq u8]
//   前兩字節是 Company ID 佔位 (0xFFFF = 測試用)
#define BEACON_KEY0          'M'
#define BEACON_KEY1          'F'

// ── 掃描與上報 ──────────────────────────────────────────────────
#define SCAN_INTERVAL_MS     80       // BLE 掃描 interval
#define SCAN_WINDOW_MS       40       // BLE 掃描 window（50% duty，給 ESP-NOW 留空口）
#define REPORT_PERIOD_MS     100      // 10Hz 批次上報
#define MAX_DRONES           8        // 單幀最多攜帶的無人機條目

#define PIN_LED              LED_BUILTIN   // XIAO ESP32S3 板載 LED（低電平亮）
