// ═══════════════════════════════════════════════════════════════
//  Anchor — XIAO ESP32S3   v1.5
//  BLE 被動掃描無人機信標 → 統計 RSSI → 10Hz 批次經 ESP-NOW 廣播給 Gateway
//
//  版本沿革：
//   v1.5 修真正的開機 abort 根因 = WiFi+BT 共存禁用 WIFI_PS_NONE（見下方 S05）。
//        Anchor 有 BLE → 共存強制 modem sleep，用 WIFI_PS_MIN_MODEM。
//   v1.3 針對開機 abort() 的三項變更（分階段標記 + NimBLE 前置 + NO_BLE 二分）：
//   1. 分階段 [Sxx] 標記 + 堆積探針。Arduino release 編譯定義 NDEBUG，
//      此時 NimBLEDevice::init() 內的 ESP_ERROR_CHECK 會退化成「不打印訊息的
//      裸 abort()」—— 所以必須靠標記定位是哪一步倒下的。
//   2. NimBLE 初始化移到 WiFi 之前：esp_bt_controller_init() 需要一大塊
//      internal + DMA-capable 記憶體，WiFi 先啟動會把它吃掉導致靜默 abort。
//   3. -DNO_BLE=1 可編出「只發心跳、不碰 BLE」的版本，用來二分定位。
// ═══════════════════════════════════════════════════════════════
#include <Arduino.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <esp_now.h>
#include <esp_heap_caps.h>
#if !NO_BLE
#include <NimBLEDevice.h>
#endif
#include "config.h"

// ── 分階段標記：每步先印、再做，abort 時最後一行就是兇手的前一步 ──
static void mark(int n, const char* what) {
  // 全 ASCII：避免終端 codepage 不是 UTF-8 時變成亂碼
  Serial.printf("[S%02d] %-24s heap=%6u largest_dma_blk=%6u\n",
                n, what,
                (unsigned)ESP.getFreeHeap(),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL));
  Serial.flush();
  delay(10);
}

// ── RSSI 累加器（BLE 回調在 NimBLE 任務執行，需要臨界區保護）─────
struct Acc {
  uint8_t droneId = 0;
  int32_t rssiSum = 0;
  uint8_t count   = 0;
  bool    used    = false;
};
static Acc s_acc[MAX_DRONES];
static portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
static volatile uint32_t s_beaconTotal = 0;

static uint8_t  s_seq = 0;
static uint32_t s_txOk = 0, s_txFail = 0;
static esp_err_t s_lastSendErr = ESP_OK;
static const uint8_t BCAST[6] = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};

static uint8_t curChannel() {
  uint8_t pri = 0;
  wifi_second_chan_t sec;
  if (esp_wifi_get_channel(&pri, &sec) != ESP_OK) return 0;
  return pri;
}

// ── ESP-NOW Anchor 報文 ─────────────────────────────────────────
// [0xA5]['A'][ver][anchorId][seq][n] { [droneId][rssiAvg i8][cnt u8] } ×n [crc]
static uint8_t frameCrc(const uint8_t* d, size_t n) {
  uint8_t c = GWM_CRC_INIT;
  for (size_t i = 0; i < n; i++) c ^= d[i];
  return c;
}

#if !NO_BLE
static NimBLEScan* s_scan = nullptr;

class ScanCB : public NimBLEAdvertisedDeviceCallbacks {
  void onResult(NimBLEAdvertisedDevice* dev) override {
    if (!dev->haveManufacturerData()) return;
    std::string md = dev->getManufacturerData();
    // [FF FF]['M']['F'][droneId][seq]
    if (md.size() < 5) return;
    if ((uint8_t)md[2] != BEACON_KEY0 || (uint8_t)md[3] != BEACON_KEY1) return;
    uint8_t id   = (uint8_t)md[4];
    int     rssi = dev->getRSSI();

    portENTER_CRITICAL(&s_mux);
    s_beaconTotal = s_beaconTotal + 1;
    int slot = -1;
    for (int i = 0; i < MAX_DRONES; i++) {
      if (s_acc[i].used && s_acc[i].droneId == id) { slot = i; break; }
    }
    if (slot < 0) {
      for (int i = 0; i < MAX_DRONES; i++)
        if (!s_acc[i].used) { slot = i; s_acc[i].used = true; s_acc[i].droneId = id;
                              s_acc[i].rssiSum = 0; s_acc[i].count = 0; break; }
    }
    if (slot >= 0 && s_acc[slot].count < 250) {
      s_acc[slot].rssiSum += rssi;
      s_acc[slot].count++;
    }
    portEXIT_CRITICAL(&s_mux);
  }
};
static ScanCB s_scanCb;
#endif  // !NO_BLE

static void espnowSendCb(const uint8_t*, esp_now_send_status_t st) {
  if (st == ESP_NOW_SEND_SUCCESS) s_txOk++; else s_txFail++;
}

void setup() {
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, HIGH);          // 熄滅（板載 LED 低電平亮）
  Serial.begin(115200);
  delay(500);                            // 等 USB CDC 列舉，否則前幾行標記會丟
  Serial.printf("\n[ANCHOR %d] v1.5 boot, want ch=%d%s\n",
                ANCHOR_ID, SYS_WIFI_CHANNEL, NO_BLE ? "  (NO_BLE 二分模式)" : "");
  mark(1, "serial up");

#if !NO_BLE
  // ⚠ 順序關鍵：BT controller 需要大塊 internal+DMA 記憶體，必須在 WiFi 之前拿。
  //   若下一行之後沒有 [S03]，就是 esp_bt_controller_init/enable 靜默 abort（記憶體不足）。
  NimBLEDevice::init("");
  mark(2, "NimBLEDevice::init");

  s_scan = NimBLEDevice::getScan();
  s_scan->setAdvertisedDeviceCallbacks(&s_scanCb, /*wantDuplicates=*/true);
  s_scan->setActiveScan(false);          // 被動掃描：不發 scan req，省空口
  s_scan->setInterval(SCAN_INTERVAL_MS);
  s_scan->setWindow(SCAN_WINDOW_MS);
  s_scan->setDuplicateFilter(false);
  s_scan->setMaxResults(0);              // 純回調、不存結果表 → 長時運行不吃 RAM
  mark(3, "scan configured");
#endif

  WiFi.mode(WIFI_STA);
  // ⚠ NVS 裡若殘留 AP 憑證，STA 會自動重連並把射頻拖去 AP 的頻道 → ESP-NOW 全聾
  WiFi.setAutoReconnect(false);
  WiFi.disconnect(false, true);          // (wifioff=false, eraseap=true)
  mark(4, "wifi STA");

  esp_wifi_set_channel(SYS_WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
#if NO_BLE
  esp_wifi_set_ps(WIFI_PS_NONE);         // 無 BT，射頻獨佔，可全速不睡
#else
  // ⚠ 致命陷阱：WiFi 與 BT 共用一顆射頻，共存時 WiFi driver 強制要求 modem sleep。
  //   設 WIFI_PS_NONE 會讓 wifi task 直接 abort：
  //     "Should enable WiFi modem sleep when both WiFi and Bluetooth are enabled"
  //   Anchor 只「發」ESP-NOW、不收，modem sleep 不影響廣播發送，因此完全無害。
  //   （Gateway 沒有 BT，那邊才可以用 WIFI_PS_NONE。）
  esp_wifi_set_ps(WIFI_PS_MIN_MODEM);
#endif
  mark(5, "channel+ps");

  esp_err_t rc = esp_now_init();
  if (rc != ESP_OK) Serial.printf("[ANCHOR] esp_now_init FAIL rc=0x%x\n", rc);
  esp_now_register_send_cb(espnowSendCb);
  mark(6, "esp_now_init");

  esp_now_peer_info_t peer = {};
  memcpy(peer.peer_addr, BCAST, 6);
  peer.channel = 0;                      // 0 = 跟隨當前頻道
  peer.ifidx   = WIFI_IF_STA;
  peer.encrypt = false;
  rc = esp_now_add_peer(&peer);
  if (rc != ESP_OK) Serial.printf("[ANCHOR] add_peer FAIL rc=0x%x\n", rc);
  mark(7, "broadcast peer");

  Serial.printf("[ANCHOR] MAC=%s  ch=%u\n", WiFi.macAddress().c_str(), curChannel());

#if !NO_BLE
  s_scan->start(0, nullptr, false);      // 0 = 永久掃描
  if (curChannel() != SYS_WIFI_CHANNEL)  // BLE controller 起來後再確認頻道
    esp_wifi_set_channel(SYS_WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
  mark(8, "scan started");
#endif

  mark(9, "RUNNING");
}

void loop() {
  static uint32_t nextReport = 0;
  static uint32_t nextDiag   = 0;
  uint32_t now = millis();

  if (now >= nextReport) {
    nextReport = now + REPORT_PERIOD_MS;

    Acc snap[MAX_DRONES];
    portENTER_CRITICAL(&s_mux);
    memcpy(snap, (const void*)s_acc, sizeof(snap));
    for (int i = 0; i < MAX_DRONES; i++) { s_acc[i].used = false; s_acc[i].rssiSum = 0; s_acc[i].count = 0; }
    portEXIT_CRITICAL(&s_mux);

    uint8_t buf[6 + MAX_DRONES * 3 + 1];
    uint8_t n = 0;
    uint8_t* p = buf + 6;
    for (int i = 0; i < MAX_DRONES; i++) {
      if (!snap[i].used || snap[i].count == 0) continue;
      int avg = snap[i].rssiSum / (int)snap[i].count;
      if (avg < -127) avg = -127;
      if (avg > 0) avg = 0;
      *p++ = snap[i].droneId;
      *p++ = (uint8_t)(int8_t)avg;
      *p++ = snap[i].count;
      n++;
    }
    buf[0] = GWM_MAGIC0; buf[1] = GWM_MAGIC1; buf[2] = GWM_VER;
    buf[3] = ANCHOR_ID;  buf[4] = s_seq++;    buf[5] = n;
    size_t len = 6 + n * 3;
    buf[len] = frameCrc(buf, len);
    len++;

    // n==0 也發（心跳）→ Gateway/上位機據此判定 Anchor 在線
    esp_err_t er = esp_now_send(BCAST, buf, len);
    if (er != ESP_OK) s_lastSendErr = er;
    digitalWrite(PIN_LED, n > 0 ? LOW : HIGH);
  }

  if (now >= nextDiag) {
    nextDiag = now + 2000;
    portENTER_CRITICAL(&s_mux);
    uint32_t total = s_beaconTotal;
    portEXIT_CRITICAL(&s_mux);
    uint8_t ch = curChannel();
    // 注意：廣播無 ACK，send callback 恆回 SUCCESS —— txOk 只證明「發出去了」，不證明有人收到
    Serial.printf("[ANCHOR %d] ch=%u%s beacons=%lu txOk=%lu txFail=%lu%s err=0x%x heap=%u\n",
                  ANCHOR_ID, ch, (ch != SYS_WIFI_CHANNEL ? "  <CH-DRIFT>" : ""),
                  (unsigned long)total, (unsigned long)s_txOk, (unsigned long)s_txFail,
                  s_lastSendErr != ESP_OK ? " SEND-ERR" : "", s_lastSendErr,
                  (unsigned)ESP.getFreeHeap());
    if (ch != SYS_WIFI_CHANNEL)
      esp_wifi_set_channel(SYS_WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
#if !NO_BLE
    if (s_scan && !s_scan->isScanning()) {   // 看門狗：掃描意外停止就重啟
      Serial.println("[ANCHOR] scan stopped, restarting");
      s_scan->start(0, nullptr, false);
    }
#endif
  }

  delay(2);
}
