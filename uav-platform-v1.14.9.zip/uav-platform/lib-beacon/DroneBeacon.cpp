// ═══════════════════════════════════════════════════════════════
//  DroneBeacon 實作 — NimBLE-Arduino 1.4.x
//  單一低佔空比廣播任務；與 WiFi/ESP-NOW 共存友好。
//
//  API 事實（已核對 NimBLE-Arduino 1.4.2 源碼）：
//   · 初始化查詢是 NimBLEDevice::getInitialized()（非 isInitialized）。
//   · NimBLEAdvertising::start() 若已在廣播會直接返回（"already active"），
//     故刷新 payload 必須 stop() → setAdvertisementData() → start()。
//   · 無 setConnectableMode()；用 setAdvertisementType(uint8_t) + 原始常量。
//     BLE_GAP_CONN_MODE_NON = 0（不可連接、無定向）→ 純信標最省。
//   · setScanResponse(false)：不回掃描請求，省一半空口、也讓被動掃描夠用。
// ═══════════════════════════════════════════════════════════════
#include "DroneBeacon.h"
#include <Arduino.h>
#include <NimBLEDevice.h>

#ifndef BLE_GAP_CONN_MODE_NON
#define BLE_GAP_CONN_MODE_NON 0
#endif

namespace DroneBeacon {

static NimBLEAdvertising* s_adv = nullptr;
static TaskHandle_t       s_task = nullptr;
static volatile uint8_t   s_id = 0;
static volatile uint8_t   s_hz = 10;
static volatile int       s_txDbm = 3;
static volatile bool      s_enabled = true;
static volatile uint32_t  s_sent = 0;

// 組並套用廣播內容：Manufacturer Data = FF FF 'M' 'F' id seq
static void applyAdv(uint8_t id, uint8_t seq) {
  NimBLEAdvertisementData ad;
  std::string md;
  md.reserve(6);
  md.push_back((char)0xFF);          // Company ID LSB（0xFFFF = 測試/未註冊）
  md.push_back((char)0xFF);          // Company ID MSB
  md.push_back('M');
  md.push_back('F');
  md.push_back((char)id);
  md.push_back((char)seq);
  ad.setManufacturerData(md);
  s_adv->setAdvertisementData(ad);
}

static void applyTxPower() {
#if defined(ESP_PWR_LVL_P9)
  esp_power_level_t lvl;
  int d = s_txDbm;
  if (d >= 9)      lvl = ESP_PWR_LVL_P9;
  else if (d >= 6) lvl = ESP_PWR_LVL_P6;
  else if (d >= 3) lvl = ESP_PWR_LVL_P3;
  else if (d >= 0) lvl = ESP_PWR_LVL_N0;
  else             lvl = ESP_PWR_LVL_N3;
  NimBLEDevice::setPower(lvl, ESP_BLE_PWR_TYPE_ADV);
#endif
}

static void beaconTask(void*) {
  // NimBLE 尚未初始化則由本庫負責（standalone）。若外部已 init（未來 ESPFC
  // 集成），getInitialized() 為真 → 跳過，直接取用既有 advertising 實例。
  if (!NimBLEDevice::getInitialized()) {
    NimBLEDevice::init("");
  }
  applyTxPower();
  s_adv = NimBLEDevice::getAdvertising();
  s_adv->setAdvertisementType(BLE_GAP_CONN_MODE_NON);  // 不可連接信標
  s_adv->setScanResponse(false);
  s_adv->setMinInterval(0x20);
  s_adv->setMaxInterval(0x40);

  uint8_t seq = 0;
  bool advertising = false;

  for (;;) {
    uint8_t hz = s_hz; if (hz < 1) hz = 1; if (hz > 50) hz = 50;
    const TickType_t period = pdMS_TO_TICKS(1000 / hz);

    if (s_enabled) {
      // 每拍刷新 seq：先停再改再啟（start 對運行中廣播不生效，故必須 stop）
      if (advertising) s_adv->stop();
      applyAdv(s_id, seq);
      s_adv->start();
      advertising = true;
      seq++;
      s_sent++;
    } else if (advertising) {
      s_adv->stop();
      advertising = false;
    }
    vTaskDelay(period);
  }
}

bool begin(uint8_t droneId, uint8_t hz, int txPowerDbm) {
  s_id = droneId;
  s_hz = hz;
  s_txDbm = txPowerDbm;
  s_enabled = true;
  if (s_task) { applyTxPower(); return true; }   // 已在跑，僅更新參數
  BaseType_t ok = xTaskCreatePinnedToCore(
      beaconTask, "beacon", 4096, nullptr,
      1,       // 低優先級：不與 ESPFC gyro/pid（高優先級）搶
      &s_task,
      0);      // 釘 core 0（協議棧核），core 1 讓給飛控實時任務
  return ok == pdPASS;
}

void setDroneId(uint8_t droneId) { s_id = droneId; }
void setEnabled(bool en) { s_enabled = en; }
uint32_t sentCount() { return s_sent; }

}  // namespace DroneBeacon
