#pragma once
#include <stdint.h>

// ═══════════════════════════════════════════════════════════════
//  DroneBeacon —— XIAO ESP32S3 定位信標（共用庫）
//
//  廣播格式（與 fw-anchor 的掃描解析逐字節一致）：
//    Manufacturer Data = [FF FF] ['M'] ['F'] [droneId u8] [seq u8]
//    (前兩字節 = Company ID 佔位 0xFFFF；'M''F' = MiniFly 系列魔數)
//
//  設計約束：
//   · 自成一個 FreeRTOS 任務，永不阻塞呼叫方（ESPFC 的 gyro/pid 任務不受影響）。
//   · 只「廣播」不掃描、不連接 → 對 WiFi(ESP-NOW rclink) 共存友好：
//     BLE adv 與 WiFi 分時，adv 佔空比極低（預設 10Hz、adv 窗 ~個位數 ms）。
//   · 不自行呼叫 esp_wifi_set_ps —— ESPFC/rclink 已處於 MIN_MODEM，
//     符合「WiFi+BT 共存必須 modem sleep」規則（見 fw-anchor 那次的 abort 教訓）。
//   · 不碰射頻頻道：BLE 用固定廣播頻道(37/38/39)，與 WiFi 頻道正交。
//
//  用法（兩種構建通用）：
//    DroneBeacon::begin(3);      // droneId=3 (ESP-FC)；一次即可，內部起任務
//    // 之後無需再呼叫任何東西；如需改 ID：DroneBeacon::setDroneId(n)
// ═══════════════════════════════════════════════════════════════

namespace DroneBeacon {

// 啟動信標任務。droneId 為本機在定位系統中的編號（1=ATK,2=nRF,3=ESP-FC）。
// hz: 廣播頻率（預設 10Hz；範圍 1..50）。txPower: NimBLE 發射功率等級 (ESP_PWR_LVL)。
// 回傳 true 表示任務已建立。重複呼叫僅更新參數、不重建任務。
bool begin(uint8_t droneId, uint8_t hz = 10, int txPowerDbm = 3);

// 動態改 ID / 開關（執行緒安全，供上位機切換或地面測試用）。
void setDroneId(uint8_t droneId);
void setEnabled(bool en);

// 診斷：已廣播的封包數（供 standalone 固件串口打印）。
uint32_t sentCount();

}  // namespace DroneBeacon
