# DroneBeacon — 集成說明

同一份 `DroneBeacon.{h,cpp}` 兩用：先 standalone 燒閒置板打通定位鏈，再原樣進 ESPFC。

## 廣播格式（與 fw-anchor 掃描端逐字節對齊，已用測試證明）

```
Manufacturer Data (6 bytes):
  [0] 0xFF   Company ID LSB  ┐ 0xFFFF = 未註冊/測試用
  [1] 0xFF   Company ID MSB  ┘
  [2] 'M'    魔數0  ← anchor 查 md[2]
  [3] 'F'    魔數1  ← anchor 查 md[3]
  [4] id     droneId(1=ATK 2=nRF 3=ESP-FC) ← anchor 取 md[4]
  [5] seq    每拍 +1（僅診斷，anchor 不校驗）
```
⚠ 前兩字節的 Company ID 是 BLE 廠商數據的**強制前綴**，anchor 的偏移
（魔數在 md[2]/md[3]、id 在 md[4]）正是據此計算。改格式必須兩邊同步。

## A. Standalone（現在做）

```
cd fw-beacon-standalone
pio run -e beacon3 -t upload      # 3 = ESP-FC 位；beacon1/beacon2 同理
pio device monitor -e beacon3     # 應見 [BEACON] id=3 sent=…遞增
```

構建機制：`platformio.ini` 用 `lib_extra_dirs = ${PROJECT_DIR}/..` 把上層目錄
當函式庫搜索路徑，PlatformIO 掃到帶 `library.json` 的 `lib-beacon/` 即自動
編譯其源碼並加入 include 路徑。**不要用 `build_src_filter` + `-I../../` 拼相對
路徑**——那個相對基準依 CLI/IDE 而異且易錯（v1.12 初版即因此 `fatal error:
DroneBeacon.h: No such file`）。`${PROJECT_DIR}` 錨定與工作目錄無關，可移植。
上位機預期：對應錨的光暈亮起、標籤變 `A?·1`、選中該機後四個測距圓出現。
這一步把 v1.6–v1.11 做的可視化與標定工具全部「通上電」。

## B. 集成進 ESP-FC（打通後做）

ESPFC 是 FreeRTOS 多核（gyro/pid 任務釘 core 0/1）。信標自成一個 core 0、
優先級 1 的低佔空比任務，不搶飛控實時性；純廣播不掃描、不碰射頻頻道，
與 rclink 的 ESP-NOW 天然分時。rclink Receiver 未動 `esp_wifi_set_ps`，
默認 MIN_MODEM，滿足 WiFi+BT 共存規則（見 fw-anchor 那次 abort 教訓）。

集成兩步：
1. `platformio.ini` 的 `[env:esp32s3]` 加 `lib_deps = h2zero/NimBLE-Arduino@^1.4.2`，
   並把 `lib-beacon/` 納入源（copy 進 ESPFC 的 lib/，或加 build_src_filter）。
2. `esp-fc/src/main.cpp` 的 `setup()` 末尾一行：
   ```cpp
   #include "DroneBeacon.h"
   // ... espfc.begin(); 之後：
   DroneBeacon::begin(3, 10, 3);   // ESP-FC = droneId 3, 10Hz, +3dBm
   ```
   `DroneBeacon` 內部 `getInitialized()` 冪等——若 ESPFC 已初始化 NimBLE 不會重複 init。

注意：ESPFC 默認未編 BLE。若其 WiFi 配置介面（Betaflight Configurator 走 WiFi）
與信標同時需要，確認二者共存（都在 core0 協議棧，NimBLE 廣播佔空比極低，實測無礙）；
若只跑 ESP-NOW 遙控、不用 WiFi 配置，最省心。
