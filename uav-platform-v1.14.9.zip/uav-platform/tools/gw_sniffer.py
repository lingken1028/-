#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gateway 串口嗅探器 —— 不要用 `pio device monitor` 開 Gateway！

Gateway 的 USB CDC 跑的是二進位協議，文字監視器只會顯示亂碼。
本工具解幀後印成人類可讀的行；同時把「不屬於任何幀」的原始位元組
（例如 ESP-ROM 開機訊息、panic/backtrace）原樣以文字印出，
所以它同時也能拿來看崩潰現場。

    python tools/gw_sniffer.py                # 自動挑第一個串口
    python tools/gw_sniffer.py COM7
    python tools/gw_sniffer.py /dev/ttyACM0 --raw    # 額外印十六進制
"""
import sys
import os
import time
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "gs"))

import serial
import serial.tools.list_ports
from gs import gwlink


class Sniffer:
    """在 gwlink.Parser 之外再包一層：把「幀外位元組」收集起來當文字印。"""

    def __init__(self, show_raw=False):
        self.p = gwlink.Parser()
        self.show_raw = show_raw
        self.spill = bytearray()

    def _flush_spill(self):
        if not self.spill:
            return
        txt = bytes(self.spill).decode("utf-8", "replace")
        for line in txt.splitlines():
            if line.strip():
                print(f"  \033[90m│ {line}\033[0m")   # 灰色：非協議文字
        self.spill.clear()

    def feed(self, data: bytes):
        for b in data:
            before = self.p._st
            evs = self.p.feed(bytes([b]))
            # 狀態機停在 S_SOF 且此位元組不是 SOF → 屬於幀外資料
            if before == 0 and self.p._st == 0 and b != gwlink.SOF:
                self.spill.append(b)
                if len(self.spill) > 512:
                    self._flush_spill()
                continue
            if evs:
                self._flush_spill()
                for kind, d in evs:
                    self.render(kind, d)

    @staticmethod
    def render(kind, d):
        t = time.strftime("%H:%M:%S")
        if kind == "log":
            print(f"[{t}] \033[36mLOG\033[0m    {d['text']}")
        elif kind == "status":
            ch = d["channel"]
            ch_s = f"\033[31mch{ch}!\033[0m" if ch != 7 else f"ch{ch}"
            extra = ""
            if "espnow_all" in d:
                rx = d["espnow_all"]
                col = "\033[32m" if rx else "\033[31m"
                extra = (f"  ESP-NOW收={col}{rx}\033[0m 轉發={d['anchor_fwd']}"
                         f" CRC壞={d['crc_bad']} 丟={d['drop']}")
            else:
                extra = "  \033[33m(舊韌體，無診斷計數器)\033[0m"
            print(f"[{t}] STATUS {ch_s} paired={int(d['paired'])} "
                  f"rc_age={d['rc_age_ms']}ms{extra}")
        elif kind == "anchor":
            e = d["entries"]
            body = "心跳(無信標)" if not e else \
                   " ".join(f"機{i}:{r}dBm×{c}" for i, r, c in e)
            print(f"[{t}] \033[32mANCHOR\033[0m A{d['anchor_id']} seq={d['seq']}  {body}")


def pick_port():
    ports = list(serial.tools.list_ports.comports())
    if not ports:
        sys.exit("找不到任何串口")
    for p in ports:
        print(f"  {p.device}  {p.description}")
    return ports[0].device


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("port", nargs="?", help="串口，例如 COM7 或 /dev/ttyACM0")
    ap.add_argument("--raw", action="store_true", help="額外印每個位元組的十六進制")
    a = ap.parse_args()

    port = a.port or pick_port()
    print(f"開啟 {port} …  Ctrl-C 結束（埠消失會自動重試——板子復位也不用重開本工具）\n")
    sn = Sniffer(a.raw)
    try:
        while True:
            try:
                with serial.Serial(port, 115200, timeout=0.1) as ser:
                    print(f"\033[32m── 已連接 {port} ──\033[0m")
                    while True:
                        data = ser.read(256)
                        if not data:
                            continue
                        if a.raw:
                            print("\033[90m" + data.hex(" ") + "\033[0m")
                        sn.feed(data)
            except (serial.SerialException, OSError):
                sn._flush_spill()
                print("\033[33m── 埠消失（板子復位？），1s 後重試 ──\033[0m")
                time.sleep(1.0)
    except KeyboardInterrupt:
        sn._flush_spill()
        print("\n結束")


if __name__ == "__main__":
    main()
