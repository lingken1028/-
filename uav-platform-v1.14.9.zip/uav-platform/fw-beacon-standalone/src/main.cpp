// ═══════════════════════════════════════════════════════════════
//  Standalone 信標固件 — XIAO ESP32S3
//
//  用途：在任一閒置 XIAO ESP32S3 上單獨燒錄，即可讓整條定位鏈活起來——
//        Anchor 掃到它 → RSSI → Gateway → 上位機的錨光暈亮、測距圓出現、
//        RSSI 標定有活可幹。等 ESPFC 集成時，同一份 lib-beacon 原樣搬過去。
//
//  燒錄：pio run -e beacon3 -t upload   （beacon3 = droneId 3 = ESP-FC 位）
//        另有 beacon1 / beacon2 對應 ATK / nRF 位，方便先各測各的。
// ═══════════════════════════════════════════════════════════════
#include <Arduino.h>
#include "DroneBeacon.h"

#ifndef DRONE_ID
#define DRONE_ID 3          // 預設 ESP-FC 位；用 -DDRONE_ID=n 覆蓋
#endif
#ifndef BEACON_HZ
#define BEACON_HZ 10
#endif

void setup() {
  Serial.begin(115200);
  delay(400);               // 等 USB CDC 列舉
  Serial.printf("\n[BEACON] standalone id=%d hz=%d  MF FF FF 'M' 'F' %d seq\n",
                DRONE_ID, BEACON_HZ, DRONE_ID);
  bool ok = DroneBeacon::begin(DRONE_ID, BEACON_HZ, /*txPowerDbm=*/3);
  Serial.printf("[BEACON] task %s\n", ok ? "started" : "FAILED");
}

void loop() {
  static uint32_t next = 0;
  if (millis() >= next) {
    next = millis() + 2000;
    Serial.printf("[BEACON] id=%d sent=%lu\n",
                  DRONE_ID, (unsigned long)DroneBeacon::sentCount());
  }
  delay(50);
}
