#pragma once

// Vendored from rtlopez/espnow-rclink (MIT). Local changes marked [GW-PATCH].

#include <queue>
#include "Common.h"
#include "Protocol.h"

namespace EspNowRcLink {

class Transmitter {
public:
  enum State {
    DISCOVERING,
    TRANSMITTING,
  };

  Transmitter();
  int begin(bool enSoftAp = false);
  void end();
  int update();
  void setChannel(size_t c, unsigned int value);
  int getSensor(size_t sensorId) const;
  void commit();

  // [GW-PATCH] 鎖定 WiFi 頻道：不做跳頻探索，停在指定頻道等 PAIR_REQ。
  // Gateway 同時要在固定頻道收 Anchor 報文，不能讓庫每 200ms 換台。
  void setFixedChannel(uint8_t ch);

  // [GW-PATCH] 外部注入接收幀：Gateway 自己接管 WifiEspNow.onReceive，
  // 過濾掉自訂幀後把其餘幀轉交給本庫原本的處理流程。
  void injectRx(const uint8_t* mac, const uint8_t* buf, size_t count);

  // [GW-PATCH] 是否已與接收端（ESPFC）配對成功
  bool isPaired() const { return _state == TRANSMITTING; }

private:
  void _handleDiscovery();
  void _handleTransmit();
  void _handleReceived();
  bool _allowed(const uint8_t *mac) const;

  static void _handleRx(const uint8_t* mac, const uint8_t *buf, size_t count, void *arg) IRAM_ATTR;
  static const uint8_t BCAST_PEER[WIFIESPNOW_ALEN];

  MessageRc _channels;
  MessageFc _sensors;
  size_t _channel = WIFI_CHANNEL_MIN;
  uint8_t _peer[WIFIESPNOW_ALEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
  uint32_t _next_discovery = 0;
  State _state = DISCOVERING;
  std::queue<Message> _queue;
  bool _ready = false;
  bool _softap = false;
  bool _fixedCh = false;   // [GW-PATCH]
};

}
