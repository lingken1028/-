// ═══════════════════════════════════════════════════════════════
//  Gateway（定位主機 / Cross-MCU Hub）— XIAO ESP32S3
//
//  三件事：
//   1. 收 Anchor 的 ESP-NOW RSSI 報文 → 打包經 USB 轉給上位機
//   2. 收上位機 RC8 幀 → 經 espnow-rclink 發控制給 ESPFC（含斷鏈 failsafe）
//   3. 轉發 rclink 遙測（getSensor 0..3）與配對狀態給上位機
//
//  執行緒模型（v1.1 修正）：
//   ESP-NOW 接收回調跑在 WiFi task（core 0），Arduino loop 跑在 core 1。
//   回調內【只做入隊】：自訂幀（0xA5）→ Anchor 環形佇列；其餘 → rclink 環形佇列。
//   兩個佇列都由 portMUX 保護；loop 統一出隊後才呼叫 tx.injectRx()，
//   保證 rclink 內部的 std::queue 只被單一任務觸碰（v1.0 曾跨任務直呼，屬資料競態）。
// ═══════════════════════════════════════════════════════════════
#include <Arduino.h>
#include <stdarg.h>
#include <esp_system.h>
#include <WiFi.h>
#include <esp_wifi.h>
#include <WifiEspNow.h>
#include "EspNowRcLink/Transmitter.h"
#include "config.h"
#include "gw_protocol.h"

static EspNowRcLink::Transmitter tx;

// ── ESP-NOW 回調 → loop 的兩條環形佇列（portMUX 保護）────────────
struct RxMsg { uint8_t mac[6]; uint8_t len; uint8_t data[64]; };
static const int AQ_N = 16;   // Anchor 幀
static const int RQ_N = 8;    // rclink 幀（PAIR_REQ / FC_DATA / FC_ALIVE）
static RxMsg s_aq[AQ_N];
static RxMsg s_rq[RQ_N];
static volatile int s_aqH = 0, s_aqT = 0;
static volatile int s_rqH = 0, s_rqT = 0;
static portMUX_TYPE s_rxMux = portMUX_INITIALIZER_UNLOCKED;

static volatile uint32_t s_lastRcMs = 0;
static bool s_rcActive = false;
static uint32_t s_anchorRx = 0, s_rcRx = 0;
static uint32_t s_serialDrop = 0;              // USB 主機沒在收 → 丟幀（絕不阻塞 loop）
static esp_reset_reason_t s_resetReason;
RTC_NOINIT_ATTR static uint32_t s_bootCount;   // 跨軟復位保留，掉電才歸零

static const char* resetReasonStr(esp_reset_reason_t r) {
  switch (r) {
    case ESP_RST_POWERON:   return "POWERON";    // 正常上電
    case ESP_RST_EXT:       return "EXT";        // 外部 reset 腳
    case ESP_RST_SW:        return "SW";         // esp_restart()
    case ESP_RST_PANIC:     return "PANIC";      // 崩潰 → 看 backtrace
    case ESP_RST_INT_WDT:   return "INT_WDT";    // 中斷看門狗（臨界區太久）
    case ESP_RST_TASK_WDT:  return "TASK_WDT";   // 任務看門狗（loop 卡住）
    case ESP_RST_WDT:       return "WDT";
    case ESP_RST_BROWNOUT:  return "BROWNOUT";   // 供電不足 ← USB 埠/線材/天線 TX 峰值
    case ESP_RST_DEEPSLEEP: return "DEEPSLEEP";
    default:                return "UNKNOWN";
  }
}
static volatile uint32_t s_dropRx = 0;
static volatile uint32_t s_espnowAll = 0;   // 回調被呼叫的總次數（不管幀型）
static volatile uint32_t s_crcBad = 0;      // 魔數對上但 CRC 錯（多半是新舊韌體混燒）
static uint32_t s_lastAnchorMs = 0;

// 讀「射頻實際所在頻道」，不是編譯期常量 —— v1.1 的狀態幀回報的是後者，
// 一旦 STA 自動重連把頻道拉走，上位機仍顯示 ch7，掩蓋了真正的故障。
static uint8_t curChannel() {
  uint8_t pri = 0;
  wifi_second_chan_t sec;
  if (esp_wifi_get_channel(&pri, &sec) != ESP_OK) return 0;
  return pri;
}

static uint8_t frameCrc(const uint8_t* d, size_t n) {
  uint8_t c = GWM_CRC_INIT;
  for (size_t i = 0; i < n; i++) c ^= d[i];
  return c;
}

static void enqueue(RxMsg* q, int qn, volatile int& h, volatile int& t,
                    const uint8_t* mac, const uint8_t* buf, size_t count) {
  if (count > sizeof(q[0].data)) { s_dropRx++; return; }
  portENTER_CRITICAL(&s_rxMux);
  int nh = (h + 1) % qn;
  if (nh == t) { portEXIT_CRITICAL(&s_rxMux); s_dropRx++; return; }   // 滿，丟幀
  RxMsg& m = q[h];
  memcpy(m.mac, mac, 6);
  m.len = (uint8_t)count;
  memcpy(m.data, buf, count);
  h = nh;
  portEXIT_CRITICAL(&s_rxMux);
}

static bool dequeue(RxMsg* q, int qn, volatile int& h, volatile int& t, RxMsg& out) {
  portENTER_CRITICAL(&s_rxMux);
  if (t == h) { portEXIT_CRITICAL(&s_rxMux); return false; }
  out = q[t];
  t = (t + 1) % qn;
  portEXIT_CRITICAL(&s_rxMux);
  return true;
}

// ── 統一 ESP-NOW 接收分流（WiFi task 上下文，只入隊）─────────────
static void onEspNowRx(const uint8_t mac[6], const uint8_t* buf, size_t count, void*) {
  s_espnowAll = s_espnowAll + 1;
  if (count >= 7 && buf[0] == GWM_MAGIC0 && buf[1] == GWM_MAGIC1 && buf[2] == GWM_VER) {
    if (frameCrc(buf, count - 1) != buf[count - 1]) { s_crcBad = s_crcBad + 1; return; }
    enqueue(s_aq, AQ_N, s_aqH, s_aqT, mac, buf, count);
    return;
  }
  enqueue(s_rq, RQ_N, s_rqH, s_rqT, mac, buf, count);         // 交給 loop 再 injectRx
}

// ── 串口發幀 ────────────────────────────────────────────────────
static void gwlSend(uint8_t type, const uint8_t* payload, uint8_t len) {
  // ⚠ USB CDC 在主機不讀時會阻塞到逾時。若在此卡住，tx.update() 就停了，
  //   ESP-FC 會誤入 failsafe。寧可丟遙測，也不能拖慢 RC 供流。
  const int need = 4 + (int)len;
  if (Serial.availableForWrite() < need) { s_serialDrop++; return; }
  uint8_t hdr[3] = { GWL_SOF, type, len };
  Serial.write(hdr, 3);
  if (len) Serial.write(payload, len);
  Serial.write(gwlCrc(type, len, payload));
}

// 除錯文字必須封進 LOG 幀 —— 本埠不容許裸文字（見 gw_protocol.h 說明）
static void gwlLog(const char* fmt, ...) {
  char buf[GWL_MAX_PAYLOAD];
  va_list ap;
  va_start(ap, fmt);
  int n = vsnprintf(buf, sizeof(buf), fmt, ap);
  va_end(ap);
  if (n < 0) return;
  if (n > (int)sizeof(buf) - 1) n = sizeof(buf) - 1;
  gwlSend(GWL_T_LOG, (const uint8_t*)buf, (uint8_t)n);
}

void setup() {
  s_resetReason = esp_reset_reason();
  if (s_resetReason == ESP_RST_POWERON || s_resetReason == ESP_RST_UNKNOWN) s_bootCount = 0;
  s_bootCount++;

  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, HIGH);
  Serial.begin(GW_SERIAL_BAUD);
  delay(300);

  WiFi.mode(WIFI_STA);
  // ⚠ NVS 裡若殘留 AP 憑證，STA 會自動重連並把射頻拖去 AP 的頻道 → ESP-NOW 全聾。
  //   必須關自動重連並清除已存 AP，這是「Anchor 一直離線」的頭號成因。
  WiFi.setAutoReconnect(false);
  WiFi.disconnect(false, true);          // (wifioff=false, eraseap=true)
  // Gateway 不啟用 BT，射頻獨佔 → 可以關省電全速收 ESP-NOW。
  // （Anchor 那邊開了 BLE，共存強制 modem sleep，切勿照抄這行。）
  esp_wifi_set_ps(WIFI_PS_NONE);

  tx.begin(false);                       // 不開 SoftAP，WiFi 由本檔管理
  tx.setFixedChannel(SYS_WIFI_CHANNEL);  // [GW-PATCH] 鎖頻道，等 ESPFC 上電來配對
  // 接管接收回調（覆蓋 begin() 內註冊的庫回調），統一分流
  WifiEspNow.onReceive(onEspNowRx, nullptr);

  // 中性通道初值（油門最低、其餘居中、AUX 低位）
  tx.setChannel(0, 1500); tx.setChannel(1, 1500);
  tx.setChannel(2,  885); tx.setChannel(3, 1500);
  for (int c = 4; c < 8; c++) tx.setChannel(c, 1000);

  gwlLog("GW boot #%u rst=%s ch=%u", (unsigned)s_bootCount,
         resetReasonStr(s_resetReason), curChannel());
}

void loop() {
  uint32_t now = millis();
  RxMsg m;

  // 1) 讀上位機串口
  static GwlParser parser;
  while (Serial.available()) {
    if (!parser.feed((uint8_t)Serial.read())) continue;
    switch (parser.type) {
      case GWL_T_RC8:
        if (parser.len == 16) {
          for (int c = 0; c < 8; c++) {
            uint16_t v = parser.payload[c*2] | ((uint16_t)parser.payload[c*2+1] << 8);
            tx.setChannel(c, v);
          }
          tx.commit();
          s_lastRcMs = now;
          s_rcActive = true;
          s_rcRx++;
        }
        break;
      case GWL_T_RCSTOP:
        s_rcActive = false;              // 立即停發 → ESPFC 進自身 failsafe
        break;
      default: break;
    }
  }

  // 2) rclink 幀出隊 → 在 loop 任務內交回庫（單一任務觸碰 _queue）
  while (dequeue(s_rq, RQ_N, s_rqH, s_rqT, m)) {
    tx.injectRx(m.mac, m.data, m.len);
  }

  // 3) RC 超時保護：上位機斷流就停發（不要替它續命）
  if (s_rcActive && (now - s_lastRcMs) > RC_TIMEOUT_MS) {
    s_rcActive = false;
  }
  // rclink 內部：commit 過才會真的發；未 commit 時 update() 只處理配對/遙測
  tx.update();

  // 4) 轉發 Anchor 幀（去掉魔數/版本/CRC，留 anchorId 起的內容）
  while (dequeue(s_aq, AQ_N, s_aqH, s_aqT, m)) {
    // m.data = [A5]['A'][ver][anchorId][seq][n][entries...][crc]
    uint8_t innerLen = m.len - 4;        // 去頭 3 字節 + 尾 CRC
    gwlSend(GWL_T_ANCHOR, m.data + 3, innerLen);
    s_anchorRx++;
    s_lastAnchorMs = now;
  }

  // 5) 5Hz 狀態回報
  static uint32_t nextStatus = 0;
  if (now >= nextStatus) {
    nextStatus = now + STATUS_PERIOD_MS;
    uint8_t p[18];
    uint32_t ageRaw = now - s_lastRcMs;
    uint16_t age = (uint16_t)(ageRaw > 65535 ? 65535 : ageRaw);
    uint8_t ch = curChannel();
    if (ch != SYS_WIFI_CHANNEL) {        // 頻道被拖走 → 拉回來
      esp_wifi_set_channel(SYS_WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE);
      ch = curChannel();
    }
    p[0] = tx.isPaired() ? 1 : 0;
    p[1] = ch;                            // 回報實際頻道
    p[2] = age & 0xFF; p[3] = age >> 8;
    for (int i = 0; i < 4; i++) {
      int16_t s = (int16_t)tx.getSensor(i);
      p[4 + i*2] = s & 0xFF; p[5 + i*2] = (s >> 8) & 0xFF;
    }
    // v1.2 診斷：ESP-NOW 總收/Anchor 轉發（u16 迴繞）＋ CRC 壞/佇列丟（u8 迴繞）
    uint16_t all16 = (uint16_t)s_espnowAll, fwd16 = (uint16_t)s_anchorRx;
    p[12] = all16 & 0xFF; p[13] = all16 >> 8;
    p[14] = fwd16 & 0xFF; p[15] = fwd16 >> 8;
    p[16] = (uint8_t)s_crcBad;
    p[17] = (uint8_t)s_dropRx;
    gwlSend(GWL_T_STATUS, p, sizeof(p));
  }

  // 6) LED 三態（獨立於 5Hz 狀態幀更新，否則 200ms 取樣 128ms 方波會混疊）
  //    rclink 配對＝常亮｜有 Anchor 流量＝閃｜全無＝滅
  if (tx.isPaired())                    digitalWrite(PIN_LED, LOW);
  else if (now - s_lastAnchorMs < 400)  digitalWrite(PIN_LED, ((now >> 7) & 1) ? LOW : HIGH);
  else                                  digitalWrite(PIN_LED, HIGH);

  // 7) 週期健康日誌。預設只在【開機頭 15 秒】播報（讓上位機接上能看到復位原因），
  //    之後靜默——避免刷屏。要持續播報：編譯時加 -DGW_HEALTH_ALWAYS=1。
  static uint32_t nextHealth = 0;
  if (now >= nextHealth) {
    nextHealth = now + 5000;
#if defined(GW_HEALTH_ALWAYS) && GW_HEALTH_ALWAYS
    bool emit = true;
#else
    bool emit = (now < 15000);
#endif
    if (emit)
      gwlLog("up=%lus boot#%u rst=%s heap=%u drop=%lu rx=%lu",
             (unsigned long)(now / 1000), (unsigned)s_bootCount,
             resetReasonStr(s_resetReason), (unsigned)ESP.getFreeHeap(),
             (unsigned long)s_serialDrop, (unsigned long)s_espnowAll);
  }

  delay(1);
}
