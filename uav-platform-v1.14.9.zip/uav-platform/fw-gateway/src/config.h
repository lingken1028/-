#pragma once
// ═══════════════════════════════════════════════════════════════
//  Gateway 配置 — XIAO ESP32S3
//  ⚠ 「系統共用參數」必須與 fw-anchor/src/config.h 完全一致
// ═══════════════════════════════════════════════════════════════

// ── 系統共用參數 ────────────────────────────────────────────────
#define SYS_WIFI_CHANNEL     7        // = ESPFC rclink 接收端頻道（rclink 預設 7）
#define GWM_MAGIC0           0xA5
#define GWM_MAGIC1           'A'
#define GWM_VER              1
#define GWM_CRC_INIT         0x66

// ── PC 串口鏈路 ─────────────────────────────────────────────────
#define GW_SERIAL_BAUD       115200   // USB CDC 實際不看波特率，佔位
#define RC_TIMEOUT_MS        400      // 上位機 RC 幀超時 → 停發，讓 ESPFC 進 failsafe
#define STATUS_PERIOD_MS     200      // 5Hz 回報 Gateway 狀態

#define PIN_LED              LED_BUILTIN
