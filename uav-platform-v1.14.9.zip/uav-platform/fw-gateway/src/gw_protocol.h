#pragma once
#include <stdint.h>
#include <stddef.h>
// ═══════════════════════════════════════════════════════════════
//  PC ↔ Gateway 串口幀協議（gs/gs/gwlink.py 必須逐字節一致）
//
//  幀： [0xFE][type][len][payload ×len][crc]
//  crc：XOR(type, len, payload...)，初值 0x66
//
//  GW → PC
//    0x10 ANCHOR   payload = [anchorId][seq][n] { [droneId][rssi i8][cnt u8] }×n
//    0x11 STATUS   payload = [paired u8][ch u8][rcAge_ms u16][s0..s3 i16×4]
//                  (+v1.2) [espnowAll u16][anchorFwd u16][crcBad u8][drop u8]
//    0x12 LOG      payload = UTF-8 文字（不含結尾 NUL），≤63 bytes
//
//  ⚠ 本埠是純二進位協議：除錯文字一律走 0x12，絕不裸 Serial.print，
//    否則文字裡若出現 0xFE 就會把後續幀吃掉。
//  PC → GW
//    0x20 RC8      payload = ch1..ch8 uint16 LE（μs，880–2120）→ rclink 發往 ESPFC
//    0x21 RC_STOP  payload 空 → 立即停發 RC（ESPFC 進 failsafe）
// ═══════════════════════════════════════════════════════════════

#define GWL_SOF        0xFE
#define GWL_CRC_INIT   0x66

#define GWL_T_ANCHOR   0x10
#define GWL_T_STATUS   0x11
#define GWL_T_LOG      0x12
#define GWL_T_RC8      0x20
#define GWL_T_RCSTOP   0x21

#define GWL_MAX_PAYLOAD 64

inline uint8_t gwlCrc(uint8_t type, uint8_t len, const uint8_t* p) {
  uint8_t c = GWL_CRC_INIT ^ type ^ len;
  for (uint8_t i = 0; i < len; i++) c ^= p[i];
  return c;
}

// 簡單接收狀態機
struct GwlParser {
  enum { S_SOF, S_TYPE, S_LEN, S_PAYLOAD, S_CRC } st = S_SOF;
  uint8_t type = 0, len = 0, idx = 0;
  uint8_t payload[GWL_MAX_PAYLOAD];

  // 回傳 true 表示解出一幀（type/len/payload 有效）
  bool feed(uint8_t b) {
    switch (st) {
      case S_SOF:  if (b == GWL_SOF) st = S_TYPE; break;
      case S_TYPE: type = b; st = S_LEN; break;
      case S_LEN:
        len = b; idx = 0;
        if (len > GWL_MAX_PAYLOAD) { st = S_SOF; break; }
        st = (len == 0) ? S_CRC : S_PAYLOAD;
        break;
      case S_PAYLOAD:
        payload[idx++] = b;
        if (idx >= len) st = S_CRC;
        break;
      case S_CRC:
        st = S_SOF;
        return b == gwlCrc(type, len, payload);
    }
    return false;
  }
};
