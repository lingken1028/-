# -*- coding: utf-8 -*-
"""PC ↔ Gateway 串口協議（與 fw-gateway/src/gw_protocol.h 逐字節一致）。

幀：[0xFE][type][len][payload][crc]，crc = XOR(type,len,payload...) 初值 0x66
GW→PC  0x10 ANCHOR: [anchorId][seq][n]{[droneId][rssi i8][cnt u8]}×n
       0x11 STATUS: [paired][ch][rcAge u16LE][s0..s3 i16LE]
       0x12 LOG:    UTF-8 文字
PC→GW  0x20 RC8:    ch1..ch8 uint16LE（μs）
       0x21 RC_STOP
"""
import struct

SOF = 0xFE
CRC_INIT = 0x66
T_ANCHOR, T_STATUS, T_LOG, T_RC8, T_RCSTOP = 0x10, 0x11, 0x12, 0x20, 0x21


def _crc(t: int, payload: bytes) -> int:
    c = CRC_INIT ^ t ^ len(payload)
    for b in payload:
        c ^= b
    return c


def _frame(t: int, payload: bytes = b"") -> bytes:
    return bytes([SOF, t, len(payload)]) + payload + bytes([_crc(t, payload)])


def encode_rc8(ch_us) -> bytes:
    """ch_us: 8 個 μs 值（ch1..ch8）。"""
    return _frame(T_RC8, struct.pack("<8H", *[int(v) for v in ch_us]))


def encode_rcstop() -> bytes:
    return _frame(T_RCSTOP)


class Parser:
    def __init__(self):
        self._st = 0
        self._t = 0
        self._len = 0
        self._pl = bytearray()

    def feed(self, data: bytes):
        """回傳事件列表：('anchor', dict) / ('status', dict)"""
        out = []
        for b in data:
            if self._st == 0:
                if b == SOF:
                    self._st = 1
            elif self._st == 1:
                self._t = b
                self._st = 2
            elif self._st == 2:
                self._len = b
                self._pl = bytearray()
                self._st = 4 if b == 0 else 3
                if b > 64:
                    self._st = 0
            elif self._st == 3:
                self._pl.append(b)
                if len(self._pl) >= self._len:
                    self._st = 4
            elif self._st == 4:
                self._st = 0
                if b != _crc(self._t, bytes(self._pl)):
                    continue
                ev = self._decode(self._t, bytes(self._pl))
                if ev:
                    out.append(ev)
        return out

    def _decode(self, t, p):
        if t == T_LOG:
            return ("log", {"text": p.decode("utf-8", "replace")})
        if t == T_ANCHOR and len(p) >= 3:
            aid, seq, n = p[0], p[1], p[2]
            if len(p) < 3 + n * 3:
                return None
            entries = []
            for i in range(n):
                off = 3 + i * 3
                did = p[off]
                rssi = struct.unpack_from("<b", p, off + 1)[0]
                cnt = p[off + 2]
                entries.append((did, rssi, cnt))
            return ("anchor", {"anchor_id": aid, "seq": seq, "entries": entries})
        if t == T_STATUS and len(p) >= 12:
            paired, ch = p[0], p[1]
            rc_age = struct.unpack_from("<H", p, 2)[0]
            sensors = struct.unpack_from("<4h", p, 4)
            d = {"paired": bool(paired), "channel": ch,
                 "rc_age_ms": rc_age, "sensors": list(sensors)}
            if len(p) >= 18:   # v1.2 診斷計數器
                d["espnow_all"], d["anchor_fwd"] = struct.unpack_from("<HH", p, 12)
                d["crc_bad"], d["drop"] = p[16], p[17]
            return ("status", d)
        return None
