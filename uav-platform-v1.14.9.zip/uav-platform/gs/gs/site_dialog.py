# -*- coding: utf-8 -*-
"""場地設置：房間尺寸、錨座標；或直接用卷尺量的「錨間距離」推算座標。

卷尺推算的座標系約定：A1 為原點、A2 在 +X 軸上。
  A1=(0,0)  A2=(d12,0)
  A3: x=(d12²+d13²−d23²)/(2·d12),  y=+√(d13²−x²)
  A4: x=(d12²+d14²−d24²)/(2·d12),  y=+√(d14²−x²)
A3/A4 取 y>0（即都在 A1–A2 連線同一側——常規四角佈置天然滿足）。
d34 若填了，會用推算結果反算並顯示殘差——這是卷尺量測與錨共面性的體檢。
"""
import math
from PySide6.QtCore import QLocale
from PySide6.QtWidgets import (QDialog, QGridLayout, QGroupBox, QLabel, QDoubleSpinBox,
                               QPushButton, QDialogButtonBox, QVBoxLayout, QMessageBox)
from . import config as C


def solve_from_distances(d12, d13, d23, d14, d24, pad=0.5):
    """由 5 個錨間距離推算座標。回傳 (anchors dict, room_w, room_h, d34_est)。"""
    for name, v in (("d12", d12), ("d13", d13), ("d23", d23), ("d14", d14), ("d24", d24)):
        if v <= 0:
            raise ValueError(f"{name} 必須 > 0")
    x3 = (d12 * d12 + d13 * d13 - d23 * d23) / (2.0 * d12)
    y3sq = d13 * d13 - x3 * x3
    x4 = (d12 * d12 + d14 * d14 - d24 * d24) / (2.0 * d12)
    y4sq = d14 * d14 - x4 * x4
    if y3sq < -1e-6 or y4sq < -1e-6:
        raise ValueError("距離組合違反三角不等式——量測有誤（常見：把對角線與邊記反）")
    y3 = math.sqrt(max(y3sq, 0.0))
    y4 = math.sqrt(max(y4sq, 0.0))
    pts = {1: (0.0, 0.0), 2: (d12, 0.0), 3: (x3, y3), 4: (x4, y4)}
    d34_est = math.hypot(x3 - x4, y3 - y4)
    # 平移到非負 + 外擴 pad，房間 = 錨包絡 + 兩側 pad
    minx = min(p[0] for p in pts.values())
    miny = min(p[1] for p in pts.values())
    pts = {k: (round(x - minx + pad, 2), round(y - miny + pad, 2)) for k, (x, y) in pts.items()}
    room_w = round(max(p[0] for p in pts.values()) + pad, 2)
    room_h = round(max(p[1] for p in pts.values()) + pad, 2)
    return pts, room_w, room_h, d34_est


class SiteDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("場地設置")
        lay = QVBoxLayout(self)

        # ── 房間與錨座標（直接編輯）──
        g = QGroupBox("房間與錨座標（米）"); gl = QGridLayout(g)
        self.sp_w = self._spin(C.ROOM_W, 1.0, 50.0)
        self.sp_h = self._spin(C.ROOM_H, 1.0, 50.0)
        gl.addWidget(QLabel("房間 寬 ×  高"), 0, 0)
        gl.addWidget(self.sp_w, 0, 1); gl.addWidget(self.sp_h, 0, 2)
        self.sp_xy = {}
        for i, aid in enumerate(sorted(C.ANCHORS)):
            ax, ay = C.ANCHORS[aid]
            sx, sy = self._spin(ax, 0.0, 50.0), self._spin(ay, 0.0, 50.0)
            self.sp_xy[aid] = (sx, sy)
            gl.addWidget(QLabel(f"A{aid}  x / y"), 1 + i, 0)
            gl.addWidget(sx, 1 + i, 1); gl.addWidget(sy, 1 + i, 2)
        lay.addWidget(g)

        # ── 卷尺推算 ──
        g = QGroupBox("卷尺推算（量錨間距離，自動求座標）"); gl = QGridLayout(g)
        self.sp_d = {}
        for r, (key, label) in enumerate((("d12", "A1–A2"), ("d13", "A1–A3"),
                                          ("d23", "A2–A3"), ("d14", "A1–A4"),
                                          ("d24", "A2–A4"), ("d34", "A3–A4（校驗，可 0）"))):
            sp = self._spin(0.0, 0.0, 60.0)
            self.sp_d[key] = sp
            gl.addWidget(QLabel(label), r // 2, (r % 2) * 2)
            gl.addWidget(sp, r // 2, (r % 2) * 2 + 1)
        self.sp_pad = self._spin(0.5, 0.0, 5.0)
        gl.addWidget(QLabel("場地外擴 pad"), 3, 0); gl.addWidget(self.sp_pad, 3, 1)
        bt = QPushButton("推算並填入上方座標")
        bt.clicked.connect(self._solve)
        gl.addWidget(bt, 3, 2, 1, 2)
        self.lb_resid = QLabel("")
        gl.addWidget(self.lb_resid, 4, 0, 1, 4)
        lay.addWidget(g)

        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._apply)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    @staticmethod
    def _spin(v, lo, hi):
        sp = QDoubleSpinBox(minimum=lo, maximum=hi, singleStep=0.1, decimals=2)
        sp.setLocale(QLocale.c())          # 防系統「本地數字」（蘇州碼子）
        sp.setValue(v)
        sp.setSuffix(" m")
        return sp

    def _solve(self):
        try:
            pts, w, h, d34_est = solve_from_distances(
                self.sp_d["d12"].value(), self.sp_d["d13"].value(),
                self.sp_d["d23"].value(), self.sp_d["d14"].value(),
                self.sp_d["d24"].value(), self.sp_pad.value())
        except ValueError as e:
            QMessageBox.warning(self, "推算失敗", str(e))
            return
        for aid, (x, y) in pts.items():
            self.sp_xy[aid][0].setValue(x)
            self.sp_xy[aid][1].setValue(y)
        self.sp_w.setValue(w); self.sp_h.setValue(h)
        d34_in = self.sp_d["d34"].value()
        if d34_in > 0:
            resid = abs(d34_est - d34_in)
            tone = "✔" if resid < 0.10 else "⚠"
            self.lb_resid.setText(
                f"{tone} A3–A4 推算 {d34_est:.2f} m，實測 {d34_in:.2f} m，殘差 {resid:.2f} m"
                + ("" if resid < 0.10 else " —— 卷尺量測或錨不共面，建議重量"))
        else:
            self.lb_resid.setText(f"A3–A4 推算值 {d34_est:.2f} m（可實測一次填入校驗）")

    def _apply(self):
        w, h = self.sp_w.value(), self.sp_h.value()
        pts = {aid: (sx.value(), sy.value()) for aid, (sx, sy) in self.sp_xy.items()}
        bad = [a for a, (x, y) in pts.items() if x > w or y > h]
        if bad:
            QMessageBox.warning(self, "座標越界",
                                f"錨 {bad} 落在房間外——擴大房間或修正座標")
            return
        C.ROOM_W, C.ROOM_H = w, h
        C.ANCHORS.clear(); C.ANCHORS.update(pts)
        C.save_site()
        self.accept()
