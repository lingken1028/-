# -*- coding: utf-8 -*-
"""上位機全域配置。所有跟「你的韌體字節層」相關的假設都集中在本檔，標 [VERIFY]。"""

# ── 場地（米）。原點在左下角，X 向右，Y 向上 ─────────────────────
ROOM_W = 6.0
ROOM_H = 5.0

# Anchor 座標（實測後填準，這是定位精度的根基）
ANCHORS = {
    1: (0.30, 0.30),
    2: (ROOM_W - 0.30, 0.30),
    3: (ROOM_W - 0.30, ROOM_H - 0.30),
    4: (0.30, ROOM_H - 0.30),
}

# ── RSSI → 距離 模型：d = 10^((P0 - rssi)/(10n)) ────────────────
# P0 = 該 Anchor 量到的 1 米參考 RSSI（用界面上「標定 1m」按鈕現場標）
RSSI_P0 = {1: -59.0, 2: -59.0, 3: -59.0, 4: -59.0}
# 機型發射偏移（dB）：P0 是「鏈路對」的屬性 = 錨的接收端 × 機的發射端。
# 三台機射頻各異（NRF51822/nRF52840/ESP32S3），拆成 P0[錨]+偏移[機]，
# 標定量 4+3 而非 4×3。參考機（用來標錨的那台）偏移保持 0。
DRONE_TX_OFFSET = {did: 0.0 for did in (1, 2, 3)}
PATHLOSS_N = 2.2          # 全域預設 n（室內典型 2.0~2.5），可在界面調
# 自適應路徑損耗指數（論文核心）：每個錨一個專屬 n，反映該方向的真實衰減。
# 空 dict → 全部回退到 PATHLOSS_N。標定「錨間 n」或「逐錨 n」後填入這裡。
PATHLOSS_N_PER_ANCHOR = {}   # anchor_id -> n
USE_WEIGHTED_LS = True       # 加權最小二乘：近錨(強RSSI)權重高，抑制遠錨大誤差
WLS_MIN_WEIGHT = 0.05        # 權重下限，避免某錨被完全忽略
# ── RSSI 域 Kalman（論文核心：把 RSSI 當理應恆定的量強力壓噪，滤完再轉距離）──
# 論文 Fig 3.5 / 3.7 用 Q=1e-5, R=0.01：模型權重遠大於量測 → 強平滑。
RSSI_KF_Q = 1e-3          # 過程噪聲：越小越平滑（機不動時 RSSI 該恆定）。
                          #   會飄→調小(1e-4)；跟不上移動→調大(1e-2)
RSSI_KF_R = 4.0           # 量測噪聲(dBm²)：室內 RSSI 抖動 ±2~3dBm，取其方差量級
RSSI_KF_Q_MOVE = 2.0      # 偵測到移動時的過程噪聲(放大→快速跟手)
RSSI_KF_MOVE_DB = 5.0     # 同向創新累積超過此(dB)判定為真實移動,切到 Q_MOVE
RSSI_FRESH_MS = 1200      # RSSI 新鮮窗（放寬，讓慢速累積的樣本仍有效）
CAL_FRESH_MS = 4000       # 標定專用新鮮窗（更寬，機靜止搬動後仍可加樣本）
EMA_ALPHA = 0.25          # (保留給舊路徑相容，實際走 RSSI_KF)
KF_Q = 1.2                # 位置 KF 過程噪聲(調大→更跟手,治滯後)
KF_R = 0.45               # 位置 KF 量測噪聲 σ（米）
# ── 運動約束（論文引用的 movement constraint：擋「跳出房間」的無效解）──
MAX_STEP_M = 1.5          # 單次解算位置跳變上限（米）；超過視為野點，暫拒
JUMP_RESEED_COUNT = 4     # 連續幾次大跳變就判定「真的移動了」→ 重播種KF(治圖標卡住)
SOLVE_MIN_UPDATES = 3     # 每個(機,錨)累積到幾個 RSSI 樣本才納入解算
POS_STALE_MS = 1000       # 位置超時 → 任務保護

# ── 無人機註冊表：droneId 即 BLE 信標裡的 ID ─────────────────────
DRONES = {
    1: {"name": "ATK-F411", "link": "atkp",  "color": "#e05252"},
    2: {"name": "nRF52840", "link": "atkp",  "color": "#4a7fd4"},
    3: {"name": "ESP-FC",   "link": "espfc", "color": "#3fa060"},
}

# ── goto 位置外環（保守起步；室內 RSSI 定位是米級/半米級精度）────
GOTO_KP = 0.8             # err(m) → v_des(m/s)
GOTO_VMAX = 0.35          # 期望速度上限
GOTO_KV = 1.4             # v 誤差 → 加速度指令
GOTO_AMAX = 1.0           # m/s²
ANGLE_MAX_DEG = 8.0       # 姿態指令限幅
ARRIVE_R = 0.30           # 到達半徑（米）
ARRIVE_HOLD_S = 1.5
CTRL_HZ = 50              # RC 指令流頻率（兩條鏈路皆是）

# ── ESPFC（rclink 通道 μs 映射）─────────────────────────────────
ESPFC_ANGLE_FULLSCALE_DEG = 30.0   # [VERIFY] 對齊 Configurator 裡 ANGLE 模式最大角
ESPFC_CH_MIN, ESPFC_CH_MID, ESPFC_CH_MAX = 885, 1500, 2115
ESPFC_ARM_ON, ESPFC_ARM_OFF = 1800, 1000   # AUX1 = ch5
ESPFC_THROTTLE_DEFAULT = 885

# ── ATKP（經遙控器透明轉發）──────────────────────────────────────
# [VERIFY] 全部對照你的 atkp.cpp / remotectrl：
ATKP_MSG_RC = 0x50            # 下行遙控幀 msgID
ATKP_MSG_CMD = 0x01           # 下行指令幀 msgID
ATKP_MSG_STATUS_UP = 0x01     # 上行姿態/狀態幀 msgID（ANO v4 風格）
# remoterData_t 字段順序（pack 用），目前按 4×float32 LE：roll,pitch,yaw,thrust
ATKP_RC_STRUCT = "<ffff"      # [VERIFY] 若有 trim/按鍵字節，改 gs/atkp.py::pack_rc
ATKP_THRUST_HOLD = 50.0       # [VERIFY] 定高模式下「懸停」對應的 thrust 值（你韌體的量綱）
ATKP_THRUST_ZERO = 0.0
# 指令幀內容不確定的先留空；急停預設用 thrust=0 的 RC 幀連發實現
ATKP_CMD_EMER_STOP = None     # [VERIFY] 例如 b"\x??\x??"；填了就會隨急停一起發
ATKP_ACTIVE_DRONE = 2         # 上行 0x01 狀態幀歸屬的機號（ESB 單機橋接期間）

# ── ESP-NOW 頻道（必須 = 兩份韌體 config.h 的 SYS_WIFI_CHANNEL）────
EXPECTED_WIFI_CHANNEL = 7

# ── 串口 ────────────────────────────────────────────────────────
BAUD_REMOTE = 115200
BAUD_GATEWAY = 115200

# ── 地圖繪製 ────────────────────────────────────────────────────
PX_PER_M = 110
MAP_MARGIN = 30
CLICK_PICK_RADIUS_M = 0.35

# ── P0 標定持久化：界面標定寫入 gs/p0.json，啟動時載入覆蓋上面的預設 ──
import os as _os, json as _json
P0_FILE = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "p0.json")
try:
    with open(P0_FILE, "r", encoding="utf-8") as _f:
        _d = _json.load(_f)
    if isinstance(_d, dict) and "p0" in _d:      # v1.8 格式
        RSSI_P0.update({int(_k): float(_v) for _k, _v in _d.get("p0", {}).items()})
        # 機型偏移機制已退役(單信標無意義,殘留壞值會污染P0)。載入時強制清零。
        for _k in DRONE_TX_OFFSET: DRONE_TX_OFFSET[_k] = 0.0
        if "n" in _d:
            PATHLOSS_N = float(_d["n"])
        if "n_per_anchor" in _d:
            PATHLOSS_N_PER_ANCHOR.update(
                {int(_k): float(_v) for _k, _v in _d.get("n_per_anchor", {}).items()})
    elif isinstance(_d, dict):                    # 舊扁平格式 {aid: p0}
        RSSI_P0.update({int(_k): float(_v) for _k, _v in _d.items()})
except FileNotFoundError:
    pass
except Exception as _e:
    print(f"[config] p0.json 載入失敗（忽略）：{_e!r}")

# ── 場地持久化：界面「場地設置」寫入 gs/site.json，啟動時載入 ──
SITE_FILE = _os.path.join(_os.path.dirname(P0_FILE), "site.json")
try:
    with open(SITE_FILE, "r", encoding="utf-8") as _f:
        _sd = _json.load(_f)
    _rw, _rh = _sd.get("room", [ROOM_W, ROOM_H])
    ROOM_W, ROOM_H = float(_rw), float(_rh)
    ANCHORS.update({int(_k): (float(_v[0]), float(_v[1]))
                    for _k, _v in _sd.get("anchors", {}).items()})
except FileNotFoundError:
    pass
except Exception as _e:
    print(f"[config] site.json 載入失敗（忽略）：{_e!r}")


def save_site():
    with open(SITE_FILE, "w", encoding="utf-8") as _f:
        _json.dump({"room": [ROOM_W, ROOM_H],
                    "anchors": {str(_k): list(_v) for _k, _v in ANCHORS.items()}},
                   _f, indent=1)
