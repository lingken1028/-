# -*- coding: utf-8 -*-
"""上位機主窗體。左：地圖；右：連線 / 狀態 / 任務 / ESP-FC / 標定 / 日誌。"""
import queue
import time
import math
from PySide6.QtCore import Qt, QTimer, QObject, Signal, QLocale
from PySide6.QtGui import QKeySequence, QShortcut
from PySide6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QGridLayout,
                               QGroupBox, QComboBox, QPushButton, QLabel, QSlider, QCheckBox,
                               QTableWidget, QTableWidgetItem, QPlainTextEdit, QHeaderView,
                               QDoubleSpinBox)

from . import config as C
from . import atkp, gwlink, serial_hub
from .position_engine import PositionEngine, now_ms
from .flight_manager import FlightManager
from .map_view import MapView
from .control_loop import ControlLoop
from .site_dialog import SiteDialog


class _LogBridge(QObject):
    sig = Signal(str)


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("多 MCU 無人機統一控制與室內定位平台 — 上位機")

        self.events = queue.Queue()
        self.engine = PositionEngine()
        self._atkp_parser = atkp.Parser()
        self._gw_parser = gwlink.Parser()
        self.link_remote = serial_hub.SerialLink("remote", self._atkp_parser.feed, self.events)
        self.link_gw = serial_hub.SerialLink("gw", self._gw_parser.feed, self.events)

        self._bridge = _LogBridge()
        self.log = self._bridge.sig.emit          # 任何線程可呼叫
        self.fm = FlightManager(self.engine, self.link_remote, self.link_gw, self.log)

        self.selected = None
        self._cal_hinted = False

        self._build_ui()
        self._bridge.sig.connect(self._log_ui)

        # v1.1：控制迴路獨立線程，不再受 Qt 事件循環卡頓（拖窗/彈窗）影響
        self.ctrl = ControlLoop(self.events, self.engine, self.fm, self.log)
        self.ctrl.start()

        self.t_ui = QTimer(self, interval=100, timeout=self._tick_ui)
        self.t_ui.start()

        QShortcut(QKeySequence(Qt.Key_Space), self, activated=self._emergency)
        QShortcut(QKeySequence(Qt.Key_Escape), self, activated=self._cancel_selected)
        self.log("就緒。先連 Gateway 串口 → 擺好 Anchor → 標定 P0 → 點機 → 點目標。")

    # ══ UI ══════════════════════════════════════════════════════
    def _build_ui(self):
        root = QWidget(); self.setCentralWidget(root)
        lay = QHBoxLayout(root)

        self.map = MapView()
        self.map.droneClicked.connect(self._on_drone_clicked)
        self.map.pointClicked.connect(self._on_point_clicked)
        lay.addWidget(self.map, 1)

        side = QVBoxLayout(); lay.addLayout(side, 0)

        # 連線
        g = QGroupBox("連線"); gl = QGridLayout(g)
        self.cb_remote = QComboBox(); self.cb_gw = QComboBox()
        self.bt_remote = QPushButton("連接"); self.bt_gw = QPushButton("連接")
        bt_refresh = QPushButton("刷新")
        gl.addWidget(QLabel("遙控器"), 0, 0); gl.addWidget(self.cb_remote, 0, 1); gl.addWidget(self.bt_remote, 0, 2)
        gl.addWidget(QLabel("Gateway"), 1, 0); gl.addWidget(self.cb_gw, 1, 1); gl.addWidget(self.bt_gw, 1, 2)
        bt_site = QPushButton("場地設置…")
        bt_site.clicked.connect(self._open_site)
        gl.addWidget(bt_site, 2, 0, 1, 2)
        gl.addWidget(bt_refresh, 2, 2)
        bt_refresh.clicked.connect(self._refresh_ports)
        self.bt_remote.clicked.connect(lambda: self._toggle(self.link_remote, self.cb_remote, self.bt_remote, C.BAUD_REMOTE))
        self.bt_gw.clicked.connect(lambda: self._toggle(self.link_gw, self.cb_gw, self.bt_gw, C.BAUD_GATEWAY))
        side.addWidget(g)

        # 系統狀態
        g = QGroupBox("系統狀態"); gl = QGridLayout(g)
        self.lb_pair = QLabel("ESPFC 配對：—")
        self.lb_sensors = QLabel("rclink 遙測：—")
        gl.addWidget(self.lb_pair, 0, 0, 1, 2)
        gl.addWidget(self.lb_sensors, 1, 0, 1, 2)
        self.ck_gwlog = QCheckBox("顯示 Gateway 週期診斷日誌")
        self.ck_gwlog.setChecked(False)
        self.ck_gwlog.toggled.connect(lambda v: setattr(self.ctrl, 'show_gw_log', v))
        gl.addWidget(self.ck_gwlog, 2, 0, 1, 2)
        self.lb_anchor = {}
        for i, aid in enumerate(sorted(C.ANCHORS)):
            lb = QLabel(f"A{aid}: 離線"); self.lb_anchor[aid] = lb
            gl.addWidget(lb, 3 + i // 2, i % 2)
        self.ck_ranges = QCheckBox("顯示選中機測距圓")
        self.ck_ranges.setChecked(True)
        self.ck_ranges.setToolTip("到各錨的估計距離畫成虛線圓；三圓交點應落在圖標上，"
                                  "不重合＝標定或 n 有偏")
        gl.addWidget(self.ck_ranges, 5, 0, 1, 2)
        side.addWidget(g)

        # 無人機表
        self.tbl = QTableWidget(len(C.DRONES), 5)
        self.tbl.setHorizontalHeaderLabels(["ID", "名稱", "x", "y", "狀態"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl.setEditTriggers(QTableWidget.NoEditTriggers)
        self.tbl.setSelectionBehavior(QTableWidget.SelectRows)
        self.tbl.cellClicked.connect(lambda r, _c: self._select(sorted(C.DRONES)[r]))
        self.tbl.setFixedHeight(30 + 30 * len(C.DRONES))
        side.addWidget(self.tbl)

        # 任務
        g = QGroupBox("任務"); gl = QGridLayout(g)
        self.lb_sel = QLabel("選中：—")
        gl.addWidget(self.lb_sel, 0, 0, 1, 2)
        bt_cancel = QPushButton("取消任務 (Esc)")
        bt_emer = QPushButton("急停 (Space)")
        bt_emer.setStyleSheet("background:#c62828;color:white;font-weight:bold;")
        bt_cancel.clicked.connect(self._cancel_selected)
        bt_emer.clicked.connect(self._emergency)
        gl.addWidget(bt_cancel, 1, 0); gl.addWidget(bt_emer, 1, 1)
        side.addWidget(g)

        # ESP-FC
        g = QGroupBox("ESP-FC（高度人管，goto 只接管橫側向）"); gl = QGridLayout(g)
        self.ck_arm = QCheckBox("ARM（AUX1）")
        self.ck_arm.toggled.connect(self._on_arm)
        self.sl_thr = QSlider(Qt.Horizontal, minimum=C.ESPFC_CH_MIN, maximum=C.ESPFC_CH_MAX,
                              value=C.ESPFC_THROTTLE_DEFAULT)
        self.lb_thr = QLabel(str(C.ESPFC_THROTTLE_DEFAULT))
        self.sl_thr.valueChanged.connect(self._on_thr)
        gl.addWidget(self.ck_arm, 0, 0, 1, 2)
        gl.addWidget(QLabel("油門"), 1, 0); gl.addWidget(self.lb_thr, 1, 1)
        gl.addWidget(self.sl_thr, 2, 0, 1, 2)
        side.addWidget(g)

        # 標定（多點擬合，穩健）：把機放到某錨的幾個已知距離，逐點「加樣本」，
        # 再「擬合」→ 同時解出 P0 與該錨專屬 n。比單點標定對距離誤差穩健得多。
        g = QGroupBox("RSSI 標定（多點擬合）")
        g.setCheckable(True)        # 可摺疊:點標題收起,不標定時省空間
        g.setChecked(False)         # 預設收起
        gl = QGridLayout(g)
        gl.setContentsMargins(6, 4, 6, 4)
        gl.setSpacing(4)
        self._cal_group = g
        self.sp_dist = QDoubleSpinBox(minimum=0.3, maximum=8.0, singleStep=0.1,
                                      value=2.0, suffix=" m", decimals=1)
        self.sp_dist.setLocale(QLocale.c())
        self.cb_anchor = QComboBox()
        for aid in sorted(C.ANCHORS):
            self.cb_anchor.addItem(f"Anchor {aid}", aid)
        self.cb_anchor.currentIndexChanged.connect(self._update_cal_status)
        gl.addWidget(QLabel("錨"), 0, 0); gl.addWidget(self.cb_anchor, 0, 1)
        gl.addWidget(QLabel("真實距離"), 0, 2); gl.addWidget(self.sp_dist, 0, 3)

        bt_add = QPushButton("① 加樣本")
        bt_add.setToolTip("把機放到離該錨『真實距離』處(捲尺量準)，穩定後按此。\n"
                          "換 2~3 個不同距離各加一次(建議 2m、3.5m、5m,避開1m近場)。")
        bt_add.clicked.connect(self._cal_add)
        bt_fit = QPushButton("② 擬合 P0+n")
        bt_fit.setToolTip("採集≥2個不同距離後按此，最小二乘同時解出 P0 和該錨專屬 n。")
        bt_fit.clicked.connect(self._cal_fit)
        gl.addWidget(bt_add, 1, 0, 1, 2); gl.addWidget(bt_fit, 1, 2, 1, 2)

        # 採樣點列表(可逐點刪除)
        from PySide6.QtWidgets import QListWidget
        self.lst_calpts = QListWidget()
        self.lst_calpts.setMaximumHeight(64)
        self.lst_calpts.setToolTip("選中一點按『刪除選中點』移除。重標同距離直接覆蓋。")
        gl.addWidget(self.lst_calpts, 2, 0, 1, 4)

        bt_delpt = QPushButton("刪除選中點")
        bt_delpt.clicked.connect(self._cal_del_point)
        bt_clr = QPushButton("清除此錨")
        bt_clr.clicked.connect(self._cal_clear)
        bt_nreset = QPushButton("重置全部")
        bt_nreset.setToolTip("P0回預設、清除所有自適應n")
        bt_nreset.clicked.connect(self._reset_n)
        gl.addWidget(bt_delpt, 3, 0, 1, 2)
        gl.addWidget(bt_clr, 3, 2, 1, 1)
        gl.addWidget(bt_nreset, 3, 3, 1, 1)

        self.lb_calstatus = QLabel("")
        self.lb_calstatus.setStyleSheet("color:#3c7fd6; font-size:11px;")
        self.lb_calstatus.setWordWrap(True)
        gl.addWidget(self.lb_calstatus, 4, 0, 1, 4)
        self._cal_status_init = True
        self.lb_p0 = QLabel(self._p0_text())
        self.lb_p0.setWordWrap(True)
        self.lb_p0.setStyleSheet("font-size:11px;")
        gl.addWidget(self.lb_p0, 5, 0, 1, 4)
        side.addWidget(g)
        # 摺疊行為:未勾選時隱藏內容真正省空間(Qt原生只禁用不隱藏)
        g.toggled.connect(self._toggle_cal_group)
        self._toggle_cal_group(False)
        self.txt = QPlainTextEdit(readOnly=True, maximumBlockCount=400)
        self.txt.setFixedWidth(360)
        side.addWidget(self.txt, 1)

        self._refresh_ports()
        self._update_cal_status()

    # ══ 定時循環（UI 渲染；控制迴路在 ControlLoop 線程）══════════
    def _tick_ui(self):
        # 串口狀態 → 按鈕文字（自動重連在 serial_hub 內完成，UI 只反映）
        for link, bt in ((self.link_remote, self.bt_remote), (self.link_gw, self.bt_gw)):
            want = {"disconnected": "連接", "connected": "斷開",
                    "reconnecting": "重連中…"}[link.state]
            if bt.text() != want:
                bt.setText(want)
        # ARM 勾選跟隨 fm（斷線時 control_loop 會強制解除）
        if self.ck_arm.isChecked() != self.fm.espfc_armed:
            self.ck_arm.setChecked(self.fm.espfc_armed)
        # 任務結束/中止 → 清掉地圖目標標記
        for did in self.map.targets():
            if did not in self.fm.missions:
                self.map.set_target(did, None)
        # 地圖 + 表
        for r, did in enumerate(sorted(C.DRONES)):
            tr = self.engine.tracks.get(did)
            fresh = tr.fresh if tr else False
            # 只在 fresh 時顯示圖標：信標斷開→過期→隱藏（不再顯示凍結的殘影/飄移）
            xy = tr.xy if (tr and fresh) else None
            self.map.update_drone(did, xy, tr.yaw_deg if tr else None,
                                  did == self.selected, fresh,
                                  tr.raw_xy if (tr and fresh) else None)
            show_xy = tr.xy if (tr and fresh) else None
            vals = [str(did), C.DRONES[did]["name"],
                    f"{show_xy[0]:.2f}" if show_xy else "—",
                    f"{show_xy[1]:.2f}" if show_xy else "—",
                    self._drone_state(did, tr, fresh)]
            for c, v in enumerate(vals):
                it = self.tbl.item(r, c)
                if it is None:
                    it = QTableWidgetItem(); self.tbl.setItem(r, c, it)
                it.setText(v)
        # 錨點在線
        dists = self.engine.distances(self.selected) if self.selected is not None else {}
        self.map.update_ranges(dists if self.ck_ranges.isChecked() else {})
        # 未標定提示：P0 全為預設值時測距圓不可信，提示一次（避免誤解為「定位不准」）
        if not self._cal_hinted and self.selected is not None and dists:
            if all(abs(C.RSSI_P0[a] - (-59.0)) < 1e-6 for a in C.ANCHORS):
                self._cal_hinted = True
                self.log("⚠ P0 尚未標定（全為預設值）→ 測距圓/定位僅供參考。"
                         "把選中機放到某錨已知距離處，用「標定錨 P0」逐錨校準。")
        for aid, lb in self.lb_anchor.items():
            online = self.engine.anchor_online(aid)
            hearing = self.engine.anchor_hearing(aid) if online else 0
            self.map.update_anchor(aid, online, hearing)
            if online:
                txt = f"A{aid}: 在線" + (f"·聽到{hearing}台" if hearing else "")
                if aid in dists:
                    txt += f"  機{self.selected}≈{dists[aid]:.2f}m"
                lb.setText(txt); lb.setStyleSheet("color:#2e7d32;")
            else:
                lb.setText(f"A{aid}: 離線"); lb.setStyleSheet("color:#c62828;")
        # Gateway 狀態
        if self.ctrl.gw_status:
            s = self.ctrl.gw_status
            ch = s["channel"]
            bad = ch != C.EXPECTED_WIFI_CHANNEL
            self.lb_pair.setText(
                f"ESPFC 配對：{'✔' if s['paired'] else '—'}   "
                f"ch{ch}{' ⚠頻道不符!' if bad else ''}   RC齡 {s['rc_age_ms']}ms")
            self.lb_pair.setStyleSheet("color:#c62828;font-weight:bold;" if bad else "")
            if "espnow_all" in s:
                self.lb_sensors.setText(
                    f"ESP-NOW收 {s['espnow_all']}  轉發 {s['anchor_fwd']}  "
                    f"CRC壞 {s['crc_bad']}  丟 {s['drop']}   遙測 {s['sensors']}")
            else:
                self.lb_sensors.setText("Gateway 韌體版本過舊（無診斷計數器），請重燒")

    def _drone_state(self, did, tr, fresh):
        ms = self.fm.missions.get(did)
        if ms:
            return {"GOTO": "前往中", "HOLD": "保持"}.get(ms.state, ms.state)
        if fresh:
            return "定位中"
        if tr and tr.rssi:
            return "信號弱"
        return "無信標"

    # ══ 互動 ════════════════════════════════════════════════════
    def _select(self, did):
        self.selected = did
        self.lb_sel.setText(f"選中：{did} · {C.DRONES[did]['name']}（{C.DRONES[did]['link']}）")

    def _on_drone_clicked(self, did):
        self._select(did)
        self.log(f"選中機 {did}（{C.DRONES[did]['name']}）")

    def _on_point_clicked(self, x, y):
        if self.selected is None:
            self.log("先點選一台無人機，再點目標位置")
            return
        link = C.DRONES[self.selected]["link"]
        if link == "atkp" and not self.link_remote.connected:
            self.log("✗ 遙控器串口未連接"); return
        if link == "espfc" and not self.link_gw.connected:
            self.log("✗ Gateway 串口未連接"); return
        self.fm.goto(self.selected, x, y)
        if self.selected in self.fm.missions:
            self.map.set_target(self.selected, (x, y))

    def _cancel_selected(self):
        if self.selected is not None:
            self.fm.cancel(self.selected)
            self.map.set_target(self.selected, None)

    def _emergency(self):
        for did in list(self.fm.missions):
            self.map.set_target(did, None)
        self.ck_arm.setChecked(False)
        self.fm.emergency_all()

    def _on_arm(self, on):
        self.fm.espfc_armed = bool(on)
        self.log(f"ESP-FC ARM = {'ON' if on else 'OFF'}")

    def _on_thr(self, v):
        self.fm.espfc_throttle = int(v)
        self.lb_thr.setText(str(v))

    def _cal_add(self):
        if self.selected is None:
            self.log("先選中一台正在發信標的無人機"); return
        aid = self.cb_anchor.currentData()
        d = self.sp_dist.value()
        status, val = self.engine.cal_add_point(aid, self.selected, d)
        if status == "ok":
            n = self.engine.cal_point_count(aid)
            self.log(f"✔ A{aid} 加樣本：d={d:.1f}m RSSI={val:.1f}dBm（已 {n} 點）")
            self._check_sample_warn(aid, d, val)
            self._update_cal_status()
        elif status == "replaced":
            self.log(f"✔ A{aid} 覆蓋 {d:.1f}m 點：RSSI={val:.1f}dBm（重標此距離）")
            self._check_sample_warn(aid, d, val)
            self._update_cal_status()
        else:
            # 失敗用彈窗,避免只在日誌一閃而過被忽略
            msg = {
                "no_rssi": f"A{aid} 收不到機{self.selected}的信號。\n"
                           f"檢查：①信標在發嗎(機圖標在不在)？②A{aid}在線嗎？"
                           f"③離A{aid}太遠可能收不到,先靠近點。",
                "stale": f"A{aid}的RSSI太舊({val}ms前)。\n"
                         f"可能搬機時信標丟幀。原地等1~2秒讓信號穩定,再按加樣本。",
                "bad_dist": "距離必須大於0。",
            }.get(status, f"加樣本失敗({status})")
            from PySide6.QtWidgets import QMessageBox
            QMessageBox.warning(self, "加樣本未成功", msg)
            self.log(f"✗ A{aid} 加樣本未成功：{status}")

    def _check_sample_warn(self, aid, d, r):
        """採到明顯異常的RSSI時即時提醒(不等到擬合才發現)。"""
        if r > -20:
            self.log(f"⚠ A{aid} {d:.1f}m 的 RSSI={r:.1f} 太強了！"
                     f"1m內近場效應會失真,建議最近點用 1.5~2m 起,別貼太近。")
        elif r < -85:
            self.log(f"⚠ A{aid} {d:.1f}m 的 RSSI={r:.1f} 太弱,可能太遠或被遮擋。")

    def _cal_fit(self):
        if self.selected is None:
            self.log("先選中無人機"); return
        aid = self.cb_anchor.currentData()
        cnt = self.engine.cal_point_count(aid)
        if cnt < 2:
            self.log(f"⚠ A{aid} 只有 {cnt} 個樣本，需要至少 2 個不同距離。")
            self._update_cal_status()
            return
        status, val = self.engine.cal_fit(aid, self.selected)
        from PySide6.QtWidgets import QMessageBox
        if status == "ok":
            p0, n = val
            self.log(f"✔ A{aid} 擬合完成：P0={p0}dBm n={n}（{cnt}點）")
            # 不再自動清點——保留採樣讓你看到擬合依據,想重標按「清除此錨」。
            self.lb_p0.setText(self._p0_text())
            # n 貼近上限(>3.8)警告:通常是近場點(1m)或多徑把斜率拽陡了
            if n > 3.8:
                QMessageBox.information(self, "標定成功但 n 偏高",
                    f"A{aid} 擬合出 n={n},偏高(正常室內 2.5~3.5)。\n\n"
                    f"多半是最近的標定點在近場(1m內RSSI異常強),把衰減斜率拽陡了。\n"
                    f"建議:刪掉1m點,改用 2m / 4m / 6m 這種遠場大間距重標,\n"
                    f"n 會落到合理範圍,定位更準。當前結果仍可用,但精度打折。")
        elif status == "non_mono":
            d1, r1, d2, r2 = val
            QMessageBox.warning(self, "標定數據不合理",
                f"A{aid} 的數據違反物理:遠處反而更強。\n"
                f"  {d1:.1f}m: {r1:.1f}dBm\n  {d2:.1f}m: {r2:.1f}dBm\n\n"
                f"這是近距離多徑干擾(信號被反射疊加)。解法:\n"
                f"①標定距離拉大(如 1m 和 4m,別用 1m 和 2m)\n"
                f"②每個點按住採集鈕多採幾秒取穩定值\n"
                f"③避開牆角/金屬面,人別站在機和錨之間\n\n"
                f"採樣點已保留,可清除後重採,或加更遠的點再擬合。")
            self.log(f"✗ A{aid} 標定被拒:數據非單調(多徑)，採樣保留")
        elif status in ("bad_p0", "bad_n"):
            what = "P0" if status == "bad_p0" else "n"
            QMessageBox.warning(self, "標定數據不合理",
                f"A{aid} 擬合出的 {what}={val} 不符合物理(數據被多徑污染)。\n\n"
                f"解法:拉大標定距離、多採樣取穩定值、避開反射面。\n"
                f"採樣點已保留,可清除後重採,或加更遠的點再擬合。")
            self.log(f"✗ A{aid} 標定被拒:{what}={val} 出界，採樣保留")
        else:
            self.log(f"✗ A{aid} 擬合失敗({status})")
        # 無論成功或被拒,都刷新狀態標籤(修「被拒後標籤顯示錯亂/尚無採樣」)
        self._update_cal_status()

    def _toggle_cal_group(self, on):
        # 摺疊/展開標定組:隱藏所有子控件(標題列的勾選框仍可見可點)
        g = self._cal_group
        lay = g.layout()
        for i in range(lay.count()):
            w = lay.itemAt(i).widget()
            if w is not None:
                w.setVisible(on)

    def _cal_del_point(self):
        aid = self.cb_anchor.currentData()
        row = self.lst_calpts.currentRow()
        pts = self.engine.cal_list_points(aid)
        if row < 0 or row >= len(pts):
            self.log("先在列表裡選中一個要刪的採樣點"); return
        d, r = pts[row]
        if self.engine.cal_remove_point(aid, d):
            self.log(f"✔ 已刪 A{aid} 的 {d:.1f}m 點(RSSI {r:.1f})，重採此距離即可")
        self._update_cal_status()

    def _cal_clear(self):
        aid = self.cb_anchor.currentData()
        self.engine.cal_clear_points(aid)
        self.log(f"已清除 A{aid} 的採樣")
        self._update_cal_status()

    def _update_cal_status(self):
        if not hasattr(self, 'lb_calstatus'):
            return
        aid = self.cb_anchor.currentData()
        pts = self.engine.cal_list_points(aid)   # 已按距離排序
        # 刷新採樣點列表,標記可疑點:近場過強、過弱、或相鄰段衰減異常
        if hasattr(self, 'lst_calpts'):
            self.lst_calpts.clear()
            for i, (d, r) in enumerate(pts):
                flag = ""
                if d < 1.5 and r > -38:
                    flag = "  ⚠近場(建議刪,改用≥2m)"
                elif r > -20:
                    flag = "  ⚠太強"
                elif r < -85:
                    flag = "  ⚠太弱"
                # 相鄰段衰減檢查:與前一點比,掉太多(>9dB/倍距)或反增
                if i > 0:
                    dp, rp = pts[i-1]
                    if d > dp:
                        drop = rp - r          # 應為正(遠→弱)
                        expect = 10 * 3.0 * math.log10(d / dp)  # n=3上限參考
                        if drop > expect + 3:
                            flag += "  ⚠此段衰減過快"
                        elif drop < -1:
                            flag += "  ⚠反而變強(多徑)"
                self.lst_calpts.addItem(f"{d:.1f} m   {r:.1f} dBm{flag}")
        if pts:
            ndiff = len(set(d for d, _ in pts))
            hint = "　→ 可擬合" if ndiff >= 2 else "　→ 再加一個不同距離"
            # 若有近場點,提示
            if any(d < 1.5 and r > -38 for d, r in pts):
                hint += "（有近場點,建議刪掉改用遠距離）"
            self.lb_calstatus.setText(f"A{aid} 已採樣 {len(pts)} 點" + hint)
        else:
            self.lb_calstatus.setText(f"A{aid}：尚無採樣。建議用 2m/3.5m/5m 起採")

    def _reset_n(self):
        C.PATHLOSS_N_PER_ANCHOR.clear()
        for k in C.RSSI_P0:
            C.RSSI_P0[k] = -59.0
        self.engine.cal_clear_points()
        self.engine._save_cal()
        self.log(f"已重置全部標定：P0回預設、清除自適應n")
        self.lb_p0.setText(self._p0_text())
        self._update_cal_status()

    def _p0_text(self):
        p0 = "P0: " + "  ".join(f"A{a}={C.RSSI_P0[a]:.0f}" for a in sorted(C.RSSI_P0))
        off = "偏移: " + "  ".join(f"機{d}={C.DRONE_TX_OFFSET[d]:+.1f}"
                                   for d in sorted(C.DRONE_TX_OFFSET))
        if C.PATHLOSS_N_PER_ANCHOR:
            nline = "n: " + "  ".join(
                f"A{a}={C.PATHLOSS_N_PER_ANCHOR.get(a, C.PATHLOSS_N):.2f}"
                + ("" if a in C.PATHLOSS_N_PER_ANCHOR else "*")
                for a in sorted(C.ANCHORS))
        else:
            nline = f"n: 全域 {C.PATHLOSS_N:.2f}（未標定自適應 n）"
        return p0 + "\n" + off + "\n" + nline

    # ══ 串口 ════════════════════════════════════════════════════
    def _open_site(self):
        dlg = SiteDialog(self)
        if not dlg.exec():
            return
        self.map.rebuild()
        # 進行中任務的目標標記在重繪後補回
        for did, ms in list(self.fm.missions.items()):
            self.map.set_target(did, ms.target)
        self.log(f"✔ 場地已更新：房間 {C.ROOM_W:.1f}×{C.ROOM_H:.1f} m，"
                 f"錨 {sorted((a, C.ANCHORS[a]) for a in C.ANCHORS)}")

    def _refresh_ports(self):
        ports = serial_hub.list_ports()
        for cb in (self.cb_remote, self.cb_gw):
            cur = cb.currentData()
            cb.clear()
            for dev, desc in ports:
                cb.addItem(f"{dev}  {desc[:24]}", dev)
            if cur:
                i = cb.findData(cur)
                if i >= 0:
                    cb.setCurrentIndex(i)

    def _toggle(self, link, cb, bt, baud):
        if link.state != "disconnected":
            if link is self.link_gw and link.connected:
                link.write(gwlink.encode_rcstop())
            link.close()
            self.log(f"{link.name} 已斷開")
            return
        port = cb.currentData()
        if not port:
            self.log("沒有可用串口"); return
        if link.open(port, baud):
            self.log(f"{link.name} 已連接 {port}")
        else:
            self.log(f"{link.name} 開埠中，背景重試… {port}")

    # ══ 其他 ════════════════════════════════════════════════════
    def _log_ui(self, s):
        self.txt.appendPlainText(time.strftime("[%H:%M:%S] ") + s)

    def closeEvent(self, ev):
        self.ctrl.stop()
        try:
            if self.link_gw.connected:
                self.link_gw.write(gwlink.encode_rcstop())
        except Exception:
            pass
        self.link_remote.close()
        self.link_gw.close()
        super().closeEvent(ev)
