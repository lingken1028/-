# -*- coding: utf-8 -*-
"""地圖視圖（v1.10 淺色精修版）。

視覺語言：淺灰畫布上一塊帶投影的白色場地卡片；0.5 m 次網格極淡、1 m 主網格
清晰；無人機用四旋翼俯視剪影（機架 X + 四槳 + 白色槳轂 + 機頭指針），
名牌是白色圓角資訊片；錨為圓角方塊三態（灰虛線離線 / 綠實線在線 / 光暈=聽到信標）；
測距圓按錨配色。公開 API 與 v1.9 完全一致。
"""
import math
from PySide6.QtCore import Qt, Signal, QPointF, QRectF
from PySide6.QtGui import QBrush, QPen, QColor, QFont, QPainter, QPainterPath
from PySide6.QtWidgets import QGraphicsView, QGraphicsScene

from . import config as C

M = C.MAP_MARGIN
S = C.PX_PER_M

# ── 調色盤（淺色）────────────────────────────────────────────────
COL_CANVAS   = "#f2f3f6"
COL_FLOOR    = "#ffffff"
COL_GRID_MIN = "#f1f3f6"
COL_GRID_MAJ = "#e4e8ee"
COL_BORDER   = "#8a93a3"
COL_TICK     = "#9aa2af"
COL_SCALE    = "#5f6876"
COL_SELECT   = "#ff9f1a"
COL_TARGET   = "#e04545"
COL_CHIP_BG  = QColor(255, 255, 255, 235)
COL_CHIP_PEN = "#d9dee6"
COL_CHIP_TXT = "#39404d"


def w2s(x, y):
    """世界(米，Y向上) → 場景(像素，Y向下)"""
    return QPointF(M + x * S, M + (C.ROOM_H - y) * S)


def s2w(p: QPointF):
    return (p.x() - M) / S, C.ROOM_H - (p.y() - M) / S


class MapView(QGraphicsView):
    droneClicked = Signal(int)
    pointClicked = Signal(float, float)

    ANCHOR_ON_FILL, ANCHOR_ON_PEN, ANCHOR_ON_TXT = "#2fae63", "#177a42", "#177a42"
    ANCHOR_OFF_FILL, ANCHOR_OFF_PEN = "#dfe3e9", "#a7afbc"
    RANGE_COLORS = {1: "#d94f63", 2: "#3c7fd6", 3: "#2f9e5f", 4: "#c78a1f"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.scene_ = QGraphicsScene(self)
        self.setScene(self.scene_)
        self.setRenderHint(QPainter.Antialiasing)
        self.setBackgroundBrush(QColor(COL_CANVAS))
        self.setMouseTracking(True)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self._zoom = 1.0
        # 座標讀出片（視口覆蓋層，不隨場景縮放）
        from PySide6.QtWidgets import QLabel
        self._coord = QLabel(self)
        self._coord.setStyleSheet(
            "QLabel{background:rgba(255,255,255,235);border:1px solid #d9dee6;"
            "border-radius:4px;padding:2px 7px;color:#39404d;"
            "font-size:11px;font-weight:600;}")
        self._coord.hide()
        self._drones = {}   # did -> dict(items)
        self._targets = {}  # did -> dict(items)
        self._anchors = {}  # aid -> dict(items)
        self._ranges = {}   # aid -> 測距圓（僅選中機）
        self._draw_static()

    # ══ 靜態底圖 ════════════════════════════════════════════════
    def _draw_static(self):
        sc = self.scene_
        W, H = C.ROOM_W * S, C.ROOM_H * S

        # 卡片投影：手工疊三層半透明矩形。
        # 不用 QGraphicsDropShadowEffect——offscreen/部分後端下它會把宿主圖元
        # 一起吞掉（像素抽檢實測地板整塊消失），手工陰影行為確定且可測。
        for grow, dy, alpha in ((7, 5, 14), (4, 3, 22), (2, 2, 30)):
            sh = sc.addRect(QRectF(M - grow, M - grow + dy, W + 2 * grow, H + 2 * grow),
                            QPen(Qt.NoPen), QBrush(QColor(40, 50, 70, alpha)))
            sh.setZValue(-0.5)
        floor = sc.addRect(QRectF(M, M, W, H), QPen(Qt.NoPen), QBrush(QColor(COL_FLOOR)))
        floor.setZValue(0)

        minor = QPen(QColor(COL_GRID_MIN), 1)
        major = QPen(QColor(COL_GRID_MAJ), 1)
        k = 0.5
        while k < C.ROOM_W - 1e-9:
            pen = major if abs(k - round(k)) < 1e-9 else minor
            ln = sc.addLine(M + k * S, M, M + k * S, M + H, pen); ln.setZValue(0.5)
            k += 0.5
        k = 0.5
        while k < C.ROOM_H - 1e-9:
            pen = major if abs(k - round(k)) < 1e-9 else minor
            ln = sc.addLine(M, M + k * S, M + W, M + k * S, pen); ln.setZValue(0.5)
            k += 0.5

        border = sc.addRect(QRectF(M, M, W, H), QPen(QColor(COL_BORDER), 1.6),
                            QBrush(Qt.NoBrush))
        border.setZValue(1)

        # 座標刻度（米）：下緣 X、左緣 Y（Y 向上）
        f = QFont(); f.setPointSize(8)
        tick = QColor(COL_TICK)
        for i in range(0, int(C.ROOM_W) + 1):
            t = sc.addSimpleText(str(i), f); t.setBrush(tick)
            br = t.boundingRect()
            t.setPos(M + i * S - br.width() / 2, M + H + 4)
        for j in range(0, int(C.ROOM_H) + 1):
            t = sc.addSimpleText(str(j), f); t.setBrush(tick)
            br = t.boundingRect()
            t.setPos(M - br.width() - 6, M + (C.ROOM_H - j) * S - br.height() / 2)

        # （比例尺已移除：兩軸自帶米制刻度，且房間非整數米時比例尺與網格錯位，
        #   視覺上反而顯得「不準」。精度驗證改用左下角的滑鼠座標實時讀出。）

        for aid in sorted(C.ANCHORS):
            self._ensure_anchor(aid)
        # 必須設「場景」自己的 sceneRect（不是視圖的）：不設的話它自動等於
        # itemsBoundingRect——測距圓一畫出房間外，場景矩形跟著暴漲，
        # 視圖捲軸亂跳、渲染導出的取景框漂移。
        self.scene_.setSceneRect(0, 0, W + 2 * M, H + 2 * M + 10)

    def rebuild(self):
        """場地（房間/錨座標）變更後整體重繪。動態圖元由下一輪 tick 重建。"""
        self.scene_.clear()
        self._drones.clear()
        self._targets.clear()
        self._anchors.clear()
        self._ranges.clear()
        self._draw_static()

    # ══ 測距圓：選中機到各錨的估計距離（P0 的可見形態）═══════════
    def update_ranges(self, dists: dict):
        """dists: {anchor_id: 距離m}。空 dict = 全部隱藏。
        三個圓的公共交點應落在無人機圖標上——不重合即標定/模型有偏。"""
        for aid in C.ANCHORS:
            it = self._ranges.get(aid)
            d = dists.get(aid)
            if d is None or d <= 0:
                if it:
                    it.setVisible(False)
                continue
            ax, ay = C.ANCHORS[aid]
            p = w2s(ax, ay)
            r = d * S
            if it is None:
                col = QColor(self.RANGE_COLORS.get(aid, "#888888"))
                col.setAlpha(150)
                it = self.scene_.addEllipse(0, 0, 0, 0, QPen(col, 1.3, Qt.DashLine),
                                            QBrush(Qt.NoBrush))
                it.setZValue(2.5)
                self._ranges[aid] = it
            it.setRect(p.x() - r, p.y() - r, 2 * r, 2 * r)
            it.setVisible(True)

    # ══ 錨點 ════════════════════════════════════════════════════
    def _ensure_anchor(self, aid):
        if aid in self._anchors:
            return self._anchors[aid]
        sc = self.scene_
        ax, ay = C.ANCHORS[aid]
        p = w2s(ax, ay)
        r = 7
        halo = sc.addEllipse(p.x() - r - 7, p.y() - r - 7, 2 * (r + 7), 2 * (r + 7),
                             QPen(QColor(47, 174, 99, 120), 2.2), QBrush(Qt.NoBrush))
        halo.setZValue(2); halo.setVisible(False)
        path = QPainterPath()
        path.addRoundedRect(QRectF(p.x() - r, p.y() - r, 2 * r, 2 * r), 2.5, 2.5)
        body = sc.addPath(path, QPen(QColor(self.ANCHOR_OFF_PEN), 1.4, Qt.DashLine),
                          QBrush(QColor(self.ANCHOR_OFF_FILL)))
        body.setZValue(3)
        f = QFont(); f.setPointSize(9)
        label = sc.addSimpleText(f"A{aid}", f)
        label.setBrush(QColor(self.ANCHOR_OFF_PEN))
        label.setPos(p.x() + 10, p.y() - 9)
        label.setZValue(3)
        d = {"body": body, "label": label, "halo": halo, "online": None, "hearing": -1}
        self._anchors[aid] = d
        return d

    def update_anchor(self, aid, online: bool, hearing: int = 0):
        d = self._ensure_anchor(aid)
        if d["online"] != online:                       # 只在狀態變化時重繪
            d["online"] = online
            if online:
                d["body"].setBrush(QBrush(QColor(self.ANCHOR_ON_FILL)))
                d["body"].setPen(QPen(QColor(self.ANCHOR_ON_PEN), 1.4, Qt.SolidLine))
                d["label"].setBrush(QColor(self.ANCHOR_ON_TXT))
                d["body"].setOpacity(1.0)
            else:
                d["body"].setBrush(QBrush(QColor(self.ANCHOR_OFF_FILL)))
                d["body"].setPen(QPen(QColor(self.ANCHOR_OFF_PEN), 1.4, Qt.DashLine))
                d["label"].setBrush(QColor(self.ANCHOR_OFF_PEN))
                d["body"].setOpacity(0.9)
        if d["hearing"] != hearing:
            d["hearing"] = hearing
            d["halo"].setVisible(bool(online and hearing > 0))
            d["label"].setText(f"A{aid}" if hearing <= 0 else f"A{aid}·{hearing}")

    # ══ 無人機：四旋翼俯視剪影 ═══════════════════════════════════
    def _ensure_drone(self, did):
        if did in self._drones:
            return self._drones[did]
        sc = self.scene_
        base = QColor(C.DRONES.get(did, {}).get("color", "#888888"))
        arm, rr = 8.5, 4.6

        frame_path = QPainterPath()
        frame_path.moveTo(-arm, -arm); frame_path.lineTo(arm, arm)
        frame_path.moveTo(-arm, arm);  frame_path.lineTo(arm, -arm)
        frame = sc.addPath(frame_path, QPen(base.darker(120), 2.6, Qt.SolidLine,
                                            Qt.RoundCap), QBrush(Qt.NoBrush))

        rotor_path = QPainterPath()
        for dx, dy in ((arm, arm), (arm, -arm), (-arm, arm), (-arm, -arm)):
            rotor_path.addEllipse(QPointF(dx, dy), rr, rr)
        rotors = sc.addPath(rotor_path, QPen(base.darker(140), 1.1),
                            QBrush(QColor(base.red(), base.green(), base.blue(), 235)))

        needle_path = QPainterPath()                      # 機頭指針（局部 +X）
        needle_path.moveTo(arm + 9, 0)
        needle_path.lineTo(arm - 1, -3.6)
        needle_path.lineTo(arm - 1, 3.6)
        needle_path.closeSubpath()
        needle = sc.addPath(needle_path, QPen(QColor("#2b303a"), 1),
                            QBrush(QColor("#2b303a")))

        hub = sc.addEllipse(-3.4, -3.4, 6.8, 6.8, QPen(base.darker(140), 1.2),
                            QBrush(QColor("#ffffff")))

        grp = sc.createItemGroup([frame, rotors, needle, hub])
        grp.setZValue(5)

        ring = sc.addEllipse(-16, -16, 32, 32, QPen(QColor(COL_SELECT), 2.4, Qt.DashLine),
                             QBrush(Qt.NoBrush))
        ring.setZValue(4.5); ring.setVisible(False)
        raw = sc.addEllipse(-3, -3, 6, 6, QPen(Qt.NoPen),
                            QBrush(QColor(base.red(), base.green(), base.blue(), 80)))
        raw.setZValue(3.5); raw.setVisible(False)

        # 名牌資訊片
        f = QFont(); f.setPointSize(8); f.setBold(True)
        name = C.DRONES.get(did, {}).get("name", f"#{did}")
        chiptx = sc.addSimpleText(f"{did}·{name}", f)
        chiptx.setBrush(QColor(COL_CHIP_TXT)); chiptx.setZValue(6.1)
        br = chiptx.boundingRect()
        chip_path = QPainterPath()
        chip_path.addRoundedRect(QRectF(0, 0, br.width() + 10, br.height() + 5), 4, 4)
        chipbg = sc.addPath(chip_path, QPen(QColor(COL_CHIP_PEN), 1), QBrush(COL_CHIP_BG))
        chipbg.setZValue(6)

        d = {"grp": grp, "ring": ring, "raw": raw, "chipbg": chipbg,
             "chiptx": chiptx, "pos": None}
        self._drones[did] = d
        return d

    def update_drone(self, did, xy, yaw_deg, selected, fresh, raw_xy=None):
        d = self._ensure_drone(did)
        vis = xy is not None
        for k in ("grp", "chipbg", "chiptx"):
            d[k].setVisible(vis)
        if not vis:
            d["ring"].setVisible(False)
            d["raw"].setVisible(False)
            return
        p = w2s(*xy)
        d["pos"] = xy
        d["grp"].setPos(p)
        d["grp"].setRotation(-(yaw_deg if yaw_deg is not None else 0.0))  # 世界CCW → 場景
        d["chipbg"].setPos(p.x() + 14, p.y() + 10)
        d["chiptx"].setPos(p.x() + 19, p.y() + 12)
        d["ring"].setVisible(selected)
        d["ring"].setPos(p)
        op = 1.0 if fresh else 0.35
        for k in ("grp", "chipbg", "chiptx"):
            d[k].setOpacity(op)
        if raw_xy:
            d["raw"].setVisible(True)
            d["raw"].setPos(w2s(*raw_xy))
        self._update_target_line(did)

    # ══ 目標標記 ═══════════════════════════════════════════════
    def set_target(self, did, xy):
        old = self._targets.pop(did, None)
        if old:
            for it in old.values():
                if not isinstance(it, tuple):
                    self.scene_.removeItem(it)
        if xy is None:
            return
        sc = self.scene_
        p = w2s(*xy)
        pen = QPen(QColor(COL_TARGET), 2.2, Qt.SolidLine, Qt.RoundCap)
        a = 8
        c1 = sc.addLine(p.x() - a, p.y() - a, p.x() + a, p.y() + a, pen)
        c2 = sc.addLine(p.x() - a, p.y() + a, p.x() + a, p.y() - a, pen)
        rc = QColor(COL_TARGET); rc.setAlpha(150)
        circ = sc.addEllipse(p.x() - C.ARRIVE_R * S, p.y() - C.ARRIVE_R * S,
                             2 * C.ARRIVE_R * S, 2 * C.ARRIVE_R * S,
                             QPen(rc, 1.1, Qt.DotLine), QBrush(Qt.NoBrush))
        lc = QColor(COL_TARGET); lc.setAlpha(160)
        line = sc.addLine(0, 0, 0, 0, QPen(lc, 1.2, Qt.DashLine))
        for it in (c1, c2, circ, line):
            it.setZValue(3.8)
        self._targets[did] = {"c1": c1, "c2": c2, "circ": circ, "line": line, "xy": xy}
        self._update_target_line(did)

    def targets(self):
        return list(self._targets.keys())

    def _update_target_line(self, did):
        t = self._targets.get(did)
        d = self._drones.get(did)
        if not t or not d or d["pos"] is None:
            return
        p1 = w2s(*d["pos"]); p2 = w2s(*t["xy"])
        t["line"].setLine(p1.x(), p1.y(), p2.x(), p2.y())

    # ══ 互動 ═══════════════════════════════════════════════════
    ZOOM_MIN, ZOOM_MAX = 0.4, 3.0

    def _apply_zoom(self, factor):
        z = max(self.ZOOM_MIN, min(self.ZOOM_MAX, self._zoom * factor))
        factor = z / self._zoom
        if abs(factor - 1.0) < 1e-9:
            return
        self._zoom = z
        self.scale(factor, factor)
        self._refresh_coord_label(None)

    def reset_view(self):
        self.resetTransform()
        self._zoom = 1.0
        self._refresh_coord_label(None)

    def wheelEvent(self, ev):
        self._apply_zoom(1.15 if ev.angleDelta().y() > 0 else 1 / 1.15)
        ev.accept()

    def mouseDoubleClickEvent(self, ev):
        self.reset_view()
        super().mouseDoubleClickEvent(ev)

    def _refresh_coord_label(self, wxy):
        if wxy is None:
            self._coord.setText(f"縮放 {self._zoom*100:.0f}%")
        else:
            self._coord.setText(f"x={wxy[0]:.2f}  y={wxy[1]:.2f} m　{self._zoom*100:.0f}%")
        self._coord.adjustSize()
        self._coord.move(8, self.viewport().height() - self._coord.height() - 8)
        self._coord.show()

    def mouseMoveEvent(self, ev):
        wx, wy = s2w(self.mapToScene(ev.position().toPoint()))
        if 0 <= wx <= C.ROOM_W and 0 <= wy <= C.ROOM_H:
            self._refresh_coord_label((wx, wy))
        else:
            self._refresh_coord_label(None)
        super().mouseMoveEvent(ev)

    def leaveEvent(self, ev):
        self._coord.hide()
        super().leaveEvent(ev)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        if self._coord.isVisible():
            self._coord.move(8, self.viewport().height() - self._coord.height() - 8)

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton:
            wx, wy = s2w(self.mapToScene(ev.position().toPoint()))
            hit = None
            best = C.CLICK_PICK_RADIUS_M
            for did, d in self._drones.items():
                if d["pos"] is None:
                    continue
                dist = math.hypot(d["pos"][0] - wx, d["pos"][1] - wy)
                if dist < best:
                    best = dist; hit = did
            if hit is not None:
                self.droneClicked.emit(hit)
            elif 0 <= wx <= C.ROOM_W and 0 <= wy <= C.ROOM_H:
                self.pointClicked.emit(wx, wy)
        super().mousePressEvent(ev)
