# -*- coding: utf-8 -*-
"""控制線程（v1.1）：把「事件消化 + 定位解算 + RC 供流」從 Qt 事件循環裡拿出來。

v1.0 用 QTimer 跑 50Hz —— 拖動窗口 / 彈窗會凍結事件循環，超過 Gateway 的 400ms
RC 超時就是空中 failsafe。本線程自帶節拍，UI 只負責渲染與下指令。
線程安全依據：CPython GIL 下對象級讀寫原子；missions 增刪由 FlightManager 內部鎖保護；
日誌回調由 main_window 傳入 Qt Signal 的 emit（跨線程安全）。
"""
import time
import queue
import threading

from . import config as C
from . import atkp
from .position_engine import now_ms


class ControlLoop(threading.Thread):
    def __init__(self, events: queue.Queue, engine, fm, log):
        super().__init__(daemon=True, name="ctrl-loop")
        self.events = events
        self.engine = engine
        self.fm = fm
        self.log = log
        self.gw_status = None      # UI 直接讀
        self.show_gw_log = False   # 週期健康日誌預設隱藏（UI 勾選可開）
        self._run = True

    def stop(self):
        self._run = False
        self.join(timeout=1.0)

    def run(self):
        period = 1.0 / C.CTRL_HZ
        next_t = time.monotonic()
        while self._run:
            try:
                self._drain()
                self.engine.step()
                self.fm.step()
            except Exception as e:              # 控制迴路絕不因單次異常停轉
                self.log(f"✗ 控制迴路異常：{e!r}")
            next_t += period
            dt = next_t - time.monotonic()
            if dt > 0:
                time.sleep(dt)
            else:
                next_t = time.monotonic()       # 落後就重新對表，不追趕補發

    # ── 事件消化 ────────────────────────────────────────────────
    def _drain(self):
        while True:
            try:
                name, ev = self.events.get_nowait()
            except queue.Empty:
                return
            if name == "gw":
                if ev[0] == "anchor":
                    d = ev[1]
                    self.engine.ingest_report(d["anchor_id"], d["entries"])
                elif ev[0] == "status":
                    self.gw_status = ev[1]
                elif ev[0] == "log":
                    txt = ev[1]['text']
                    # 開機行（含復位原因）永遠顯示；週期健康日誌受 UI 開關控制
                    if txt.startswith("GW boot") or getattr(self, 'show_gw_log', True):
                        self.log(f"[GW] {txt}")
                elif ev[0] == "io_error":
                    # 斷線安全語義：棄 ESP-FC 任務 + 解除 ARM。
                    # 不解除的話，自動重連後會帶著 AUX 高電平恢復供流——
                    # ESPFC 從 failsafe 出來時看到 ARM 仍高，行為不可預期。
                    self.fm.cancel_by_link("espfc")
                    if self.fm.espfc_armed:
                        self.fm.espfc_armed = False
                        self.log("‼ Gateway 斷線：已自動解除 ESP-FC ARM")
                    self.gw_status = None
                    self.log("✗ Gateway 串口斷開，自動重連中…")
                elif ev[0] == "reconnected":
                    self.log(f"✔ Gateway 串口已自動重連（{ev[1]['port']}）")
            elif name == "remote":
                if ev[0] == "io_error":
                    self.fm.cancel_by_link("atkp")
                    self.log("✗ 遙控器串口斷開，自動重連中…")
                elif ev[0] == "reconnected":
                    self.log(f"✔ 遙控器串口已自動重連（{ev[1]['port']}）")
                elif isinstance(ev[0], int):
                    msg_id, payload = ev
                    if msg_id == C.ATKP_MSG_STATUS_UP:
                        st = atkp.parse_status(payload)
                        if st:
                            tr = self.engine.track(C.ATKP_ACTIVE_DRONE)
                            tr.att = st
                            tr.att_ms = now_ms()
