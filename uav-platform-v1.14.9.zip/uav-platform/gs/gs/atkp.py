# -*- coding: utf-8 -*-
"""ATKP 幀構造/解析。

鏈路：上位機 ──USB(本協議原始字節)──▶ XIAO nRF52840 遙控器 ──ESB 透明轉發──▶ ATK / nRF 飛控
遙控器橋接約定：USB 收到的下行幀(AA AF ...)整幀經 ESB 發出；ESB 收到的上行幀(AA AA ...)整幀寫回 USB。

[VERIFY] 校驗和按 ANO/ATKP 慣例：從幀頭第一字節累加到 data 末尾，取低 8 位。
"""
import struct
from . import config as C

HDR_DOWN = b"\xAA\xAF"   # 上位機/遙控器 → 飛控
HDR_UP   = b"\xAA\xAA"   # 飛控 → 上位機


def _sum8(data: bytes) -> int:
    return sum(data) & 0xFF


def build(msg_id: int, payload: bytes) -> bytes:
    frame = HDR_DOWN + bytes([msg_id & 0xFF, len(payload) & 0xFF]) + payload
    return frame + bytes([_sum8(frame)])


def pack_rc(roll_deg: float, pitch_deg: float, yaw: float, thrust: float) -> bytes:
    """下行遙控幀（msgID 0x50）。
    [VERIFY] 字段順序/量綱對照你的 remoterData_t；如含 trim/按鍵字節在此補。"""
    payload = struct.pack(C.ATKP_RC_STRUCT, roll_deg, pitch_deg, yaw, thrust)
    return build(C.ATKP_MSG_RC, payload)


def pack_command(cmd_bytes: bytes) -> bytes:
    """下行指令幀（msgID 0x01），內容由呼叫方給定。"""
    return build(C.ATKP_MSG_CMD, cmd_bytes)


class Parser:
    """上行流解析（AA AA msgID len data sum）。feed() 回傳 [(msg_id, payload), ...]"""

    def __init__(self):
        self._buf = bytearray()

    def feed(self, data: bytes):
        self._buf += data
        out = []
        b = self._buf
        while True:
            # 找幀頭
            i = b.find(HDR_UP)
            if i < 0:
                # 保留最後 1 字節以防 0xAA 斷幀
                if len(b) > 1:
                    del b[:-1]
                break
            if i > 0:
                del b[:i]
            if len(b) < 5:
                break
            length = b[3]
            total = 4 + length + 1
            if len(b) < total:
                break
            frame = bytes(b[:total])
            if _sum8(frame[:-1]) == frame[-1]:
                del b[:total]
                out.append((frame[2], frame[4:-1]))
            else:
                # 假幀頭：只滑動 1 字節重新同步，避免吞掉緊隨其後的真幀
                del b[:1]
        return out


def parse_status(payload: bytes):
    """上行 0x01 狀態幀 → dict。
    [VERIFY] ANO v4 佈局：rol,pit,yaw int16(×100°) + alt int32(cm) + fly_model u8 + armed u8"""
    if len(payload) < 12:
        return None
    rol, pit, yaw, alt = struct.unpack_from("<hhhi", payload, 0)
    d = {
        "roll": rol / 100.0,
        "pitch": pit / 100.0,
        "yaw": yaw / 100.0,
        "alt_cm": alt,
    }
    if len(payload) >= 12:
        d["mode"] = payload[10]
        d["armed"] = payload[11]
    return d
