# -*- coding: utf-8 -*-
"""定位引擎：RSSI(EMA) → 對數距離模型 → 最小二乘三邊解算 → 2D 勻速 Kalman。

精度預期要誠實：室內 BLE RSSI 三邊定位在 0.5~2 m 量級，多徑會讓單點解跳動，
Kalman 只能把它整成連續軌跡，救不回系統性偏差 —— P0 標定與 Anchor 座標實測是根基。
"""
import time
import math
import json
import numpy as np
from . import config as C


def now_ms():
    return time.monotonic() * 1000.0


class _KF1D:
    """純量 Kalman，濾單一 RSSI 通道。靜止時強平滑壓噪，移動時自適應跟隨。

    狀態 = 真實 RSSI。靜止時 Q 小 → 信「它沒動」→ 強平滑；
    但若連續數次量測都往同方向偏離(創新 innovation 同號且大)，說明機真的在動 →
    臨時放大 Q 讓濾波器快速跟上,避免「圖標卡住、raw 爬得很慢」。
    """
    def __init__(self):
        self.x = None      # 濾波後 RSSI
        self.p = 1.0       # 估計方差
        self.n = 0         # 已吸收樣本數
        self._streak = 0.0 # 同向創新累積(偵測真實移動)

    def update(self, z):
        if self.x is None:
            self.x = float(z)
            self.p = C.RSSI_KF_R
            self.n = 1
            self._streak = 0.0
            return self.x
        innov = z - self.x
        # 同向創新累積:連續往同方向偏 → 是移動不是噪聲
        if innov * self._streak > 0:
            self._streak += innov
        else:
            self._streak = innov
        # 自適應 Q:創新持續偏大時放大過程噪聲(跟手);否則用小 Q(平滑)
        q = C.RSSI_KF_Q
        if abs(self._streak) > C.RSSI_KF_MOVE_DB:
            q = C.RSSI_KF_Q_MOVE
        self.p += q
        k = self.p / (self.p + C.RSSI_KF_R)
        self.x += k * innov
        self.p *= (1.0 - k)
        self.n += 1
        return self.x


class _KF2D:
    """狀態 [x y vx vy]，勻速模型。"""

    def __init__(self):
        self.x = None
        self.P = None

    def reset(self, px, py):
        self.x = np.array([px, py, 0.0, 0.0])
        self.P = np.diag([0.5, 0.5, 0.5, 0.5])

    def predict(self, dt):
        if self.x is None:
            return
        F = np.array([[1, 0, dt, 0],
                      [0, 1, 0, dt],
                      [0, 0, 1, 0],
                      [0, 0, 0, 1]], dtype=float)
        q = C.KF_Q
        G = np.array([[0.5 * dt * dt, 0],
                      [0, 0.5 * dt * dt],
                      [dt, 0],
                      [0, dt]], dtype=float)
        Q = G @ G.T * q * q
        self.x = F @ self.x
        self.P = F @ self.P @ F.T + Q

    def update(self, zx, zy):
        if self.x is None:
            self.reset(zx, zy)
            return
        H = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], dtype=float)
        R = np.eye(2) * (C.KF_R ** 2)
        z = np.array([zx, zy])
        y = z - H @ self.x
        S = H @ self.P @ H.T + R
        K = self.P @ H.T @ np.linalg.inv(S)
        self.x = self.x + K @ y
        self.P = (np.eye(4) - K @ H) @ self.P


class DroneTrack:
    def __init__(self, drone_id):
        self.drone_id = drone_id
        # anchor_id -> dict(kf=_KF1D, ema=濾波值, last_ms, raw, updates)
        # 保留鍵名 ema 與 [1]=時間戳 的元組介面，讓下游解算/標定/測距不用改。
        self.rssi = {}
        self._rkf = {}          # anchor_id -> _KF1D
        self.kf = _KF2D()
        self.pos_ms = 0.0
        self.raw_xy = None
        self.att = None
        self.att_ms = 0.0

    def ingest(self, anchor_id, rssi, cnt):
        t = now_ms()
        kf = self._rkf.get(anchor_id)
        if kf is None:
            kf = _KF1D()
            self._rkf[anchor_id] = kf
        # 斷檔重置：太久沒收到，舊狀態已失效，重新起濾
        prev = self.rssi.get(anchor_id)
        if prev is not None and (t - prev[1]) > 3000:
            kf.__init__()
        filt = kf.update(rssi)
        # 元組維持 (濾波RSSI, 時間戳, 原始RSSI, 樣本數) 的舊介面
        self.rssi[anchor_id] = (filt, t, rssi, kf.n)

    @property
    def xy(self):
        if self.kf.x is None:
            return None
        return float(self.kf.x[0]), float(self.kf.x[1])

    @property
    def vxy(self):
        if self.kf.x is None:
            return (0.0, 0.0)
        return float(self.kf.x[2]), float(self.kf.x[3])

    @property
    def fresh(self):
        return self.kf.x is not None and (now_ms() - self.pos_ms) < C.POS_STALE_MS

    @property
    def yaw_deg(self):
        if self.att and (now_ms() - self.att_ms) < 1500:
            return self.att.get("yaw")
        return None


class PositionEngine:
    def __init__(self):
        self.tracks = {}        # drone_id -> DroneTrack
        self.anchor_seen = {}   # anchor_id -> last_ms
        self._last_step = now_ms()
        self._cal_pts = {}      # anchor_id -> [(dist, rssi), ...] 多點標定緩存

    def track(self, drone_id) -> DroneTrack:
        if drone_id not in self.tracks:
            self.tracks[drone_id] = DroneTrack(drone_id)
        return self.tracks[drone_id]

    # ── 輸入 ────────────────────────────────────────────────────
    def ingest_report(self, anchor_id, entries):
        self.anchor_seen[anchor_id] = now_ms()
        for did, rssi, cnt in entries:
            self.track(did).ingest(anchor_id, rssi, cnt)

    # ── RSSI → 距離：d = 10^((P0[錨]+off[機] − rssi)/(10·n[錨])) ─────
    # 自適應 n：每個錨用專屬 n（PATHLOSS_N_PER_ANCHOR），無則回退全域 PATHLOSS_N。
    # 這是論文核心——不同方向衰減率不同，固定 n 是「貼著 A4 卻報最遠」的根因。
    @staticmethod
    def _n_for(anchor_id):
        return C.PATHLOSS_N_PER_ANCHOR.get(anchor_id, C.PATHLOSS_N)

    @staticmethod
    def _dist(anchor_id, drone_id, rssi):
        p0 = C.RSSI_P0.get(anchor_id, -59.0)   # 偏移機制已退役(單信標無意義)
        n = PositionEngine._n_for(anchor_id)
        d = 10.0 ** ((p0 - rssi) / (10.0 * n))
        # 安全鉗位：距離不可能超過場地對角線太多。標定歪了也不會讓解算在錨間亂跳。
        dmax = 1.5 * math.hypot(C.ROOM_W, C.ROOM_H)
        return max(0.1, min(d, dmax))

    # ── 解算（每 100ms 由 UI 定時器呼叫）─────────────────────────
    def step(self):
        t = now_ms()
        dt = max(1e-3, (t - self._last_step) / 1000.0)
        self._last_step = t

        for tr in self.tracks.values():
            # 只取「新鮮且已吸收足夠樣本」的錨 —— 論文用 100 樣本求一次位置，
            # 這裡要求每個(機,錨)的 RSSI KF 至少吸收 SOLVE_MIN_UPDATES 個樣本，
            # 避免單點噪聲直接進解算（你「光圈忽大忽小」的直接來源）。
            pairs = [(aid, e[0]) for aid, e in tr.rssi.items()
                     if (t - e[1]) < C.RSSI_FRESH_MS and aid in C.ANCHORS
                     and e[3] >= C.SOLVE_MIN_UPDATES]
            has_meas = len(pairs) >= 3
            if tr.kf.x is not None and (t - tr.pos_ms) > C.POS_STALE_MS:
                tr.kf.x[2] = 0.0
                tr.kf.x[3] = 0.0
                tr.raw_xy = None
                if not has_meas:
                    continue
            if has_meas or (tr.kf.x is not None and (t - tr.pos_ms) <= C.POS_STALE_MS):
                tr.kf.predict(dt)
            if not has_meas:
                continue
            sol = self._trilaterate(tr.drone_id, pairs)
            if sol is None:
                continue
            x, y = sol
            x = min(max(x, 0.0), C.ROOM_W)
            y = min(max(y, 0.0), C.ROOM_H)
            tr.raw_xy = (x, y)
            # 運動約束：新解相對上一濾波位置跳變過大 → 可能是野點。
            # 但若「連續多次」都跳到同一遠處，說明機是真的移動了(如標定時搬動)，
            # 這時不能一直拒絕(否則圖標卡住、raw 在動 kf 不動)——重新播種 KF 到新位置。
            if tr.kf.x is not None:
                jump = math.hypot(x - tr.kf.x[0], y - tr.kf.x[1])
                if jump > C.MAX_STEP_M:
                    tr._jumpcnt = getattr(tr, '_jumpcnt', 0) + 1
                    if tr._jumpcnt >= C.JUMP_RESEED_COUNT:
                        # 真的移動了 → 重新播種到新位置、速度歸零、協方差放大
                        tr.kf.reset(x, y)
                        tr._jumpcnt = 0
                        tr.pos_ms = t
                    else:
                        tr.pos_ms = t
                        continue
                else:
                    tr._jumpcnt = 0        # 跳變恢復正常，清計數
            tr.kf.update(x, y)
            tr.pos_ms = t

    @staticmethod
    def _trilaterate(drone_id, pairs):
        """加權線性化最小二乘。以最後一個錨為參考，兩兩相減消去 x²/y² 項；
        每個方程按「距離越近權重越高」加權（近錨 RSSI 更可信，文獻共識）。
        權重 w_i = 1/d_i²，正規化後代入 (WA)x = Wb 求解。"""
        pts = [(C.ANCHORS[aid], PositionEngine._dist(aid, drone_id, r)) for aid, r in pairs]
        (xr, yr), dr = pts[-1]
        A, b, w = [], [], []
        for (xi, yi), di in pts[:-1]:
            A.append([2.0 * (xr - xi), 2.0 * (yr - yi)])
            b.append(di * di - dr * dr - xi * xi + xr * xr - yi * yi + yr * yr)
            if C.USE_WEIGHTED_LS:
                # 該方程涉及錨 i 與參考錨，取兩者較近距離主導權重
                dmin = max(0.3, min(di, dr))
                w.append(1.0 / (dmin * dmin))
            else:
                w.append(1.0)
        A = np.asarray(A)
        b = np.asarray(b)
        w = np.asarray(w)
        w = np.maximum(w / (w.max() if w.max() > 0 else 1.0), C.WLS_MIN_WEIGHT)
        try:
            W = np.sqrt(w)[:, None]           # 對 A、b 同乘 √w 等價加權最小二乘
            sol, *_ = np.linalg.lstsq(A * W, b * (W[:, 0]), rcond=None)
        except np.linalg.LinAlgError:
            return None
        if not np.all(np.isfinite(sol)):
            return None
        return float(sol[0]), float(sol[1])

    def distances(self, drone_id):
        """選中機到各錨的『估計距離』（P0/偏移/n 生效後的中間量）。
        用途：與卷尺實測對比即可直接檢驗標定——這就是 P0 的可見形態。"""
        out = {}
        tr = self.tracks.get(drone_id)
        if not tr:
            return out
        t = now_ms()
        for aid, e in tr.rssi.items():
            if aid in C.ANCHORS and (t - e[1]) < C.RSSI_FRESH_MS:
                out[aid] = self._dist(aid, drone_id, e[0])
        return out

    def anchor_hearing(self, anchor_id) -> int:
        """該錨此刻有幾台無人機的 RSSI 是新鮮的（用於地圖上的活動指示）。"""
        t = now_ms()
        n = 0
        for tr in self.tracks.values():
            e = tr.rssi.get(anchor_id)
            if e and (t - e[1]) < C.RSSI_FRESH_MS:
                n += 1
        return n

    def anchor_online(self, anchor_id, timeout_ms=1500) -> bool:
        seen = self.anchor_seen.get(anchor_id)
        return bool(seen) and (now_ms() - seen) < timeout_ms

    # ── 標定（距離可調）─────────────────────────────────────────
    # 模型：rssi = P0[錨] + off[機] − 10n·log10(d)
    #  · 標錨（用參考機）  ：P0  = rssi + 10n·log10(d) − off[機]
    #  · 標機型偏移（用已標定的錨）：off = rssi + 10n·log10(d) − P0[錨]
    # 注意：d≠1m 時 n 的誤差會折進結果——在標定距離那個環上精確、離開有偏。
    # 建議在典型工作距離（1~2m）標，且四錨用同一距離。
    def _fresh_rssi(self, anchor_id, drone_id):
        tr = self.tracks.get(drone_id)
        if not tr:
            return None
        e = tr.rssi.get(anchor_id)
        if not e or (now_ms() - e[1]) > C.RSSI_FRESH_MS:
            return None
        return e[0]

    def calibrate_p0(self, anchor_id, drone_id, dist_m=1.0):
        r = self._fresh_rssi(anchor_id, drone_id)
        if r is None:
            return None
        p0 = (r + 10.0 * C.PATHLOSS_N * math.log10(max(dist_m, 0.05))
              - C.DRONE_TX_OFFSET.get(drone_id, 0.0))
        C.RSSI_P0[anchor_id] = round(p0, 1)
        self._save_cal()
        return C.RSSI_P0[anchor_id]

    def calibrate_drone_offset(self, anchor_id, drone_id, dist_m=1.0):
        r = self._fresh_rssi(anchor_id, drone_id)
        if r is None:
            return None
        off = (r + 10.0 * C.PATHLOSS_N * math.log10(max(dist_m, 0.05))
               - C.RSSI_P0.get(anchor_id, -59.0))
        C.DRONE_TX_OFFSET[drone_id] = round(off, 1)
        self._save_cal()
        return C.DRONE_TX_OFFSET[drone_id]

    # ── 多點標定（穩健,論文 Table 4.3 做法）──────────────────────
    # 在多個已知距離採 RSSI,最小二乘同時擬合 P0 與 n。
    # 比單點標定對距離量測誤差穩健得多(單點距離差10%→n差0.2,多點→n差0.08)。
    # 用法:_cal_add_point(錨,機,距離) 逐點採樣,最後 _cal_fit(錨) 擬合。
    def cal_sample_start(self, anchor_id, drone_id):
        """開始為某錨採集一批RSSI(用於取中位數,對多徑尖峰鲁棒)。"""
        self._cal_buf = {"aid": anchor_id, "did": drone_id, "vals": []}

    def cal_sample_tick(self):
        """採集期間每個UI tick調用,累積當前RSSI。回傳已採集數。"""
        buf = getattr(self, "_cal_buf", None)
        if not buf:
            return 0
        tr = self.tracks.get(buf["did"])
        e = tr.rssi.get(buf["aid"]) if tr else None
        if e is not None and (now_ms() - e[1]) < C.CAL_FRESH_MS:
            buf["vals"].append(float(e[0]))
        return len(buf["vals"])

    def cal_sample_commit(self, dist_m):
        """把採集的一批RSSI取中位數,作為該距離的標定點。
        回傳 (狀態, 值),狀態同 cal_add_point。"""
        buf = getattr(self, "_cal_buf", None)
        if not buf or len(buf["vals"]) < 3:
            self._cal_buf = None
            return ("no_rssi", None)
        if dist_m <= 0:
            self._cal_buf = None
            return ("bad_dist", None)
        aid = buf["aid"]
        vals = sorted(buf["vals"])
        med = vals[len(vals) // 2]      # 中位數,抗尖峰
        n = len(buf["vals"])
        self._cal_buf = None
        pts = self._cal_pts.setdefault(aid, [])
        for i, (d0, _) in enumerate(pts):
            if abs(d0 - dist_m) < 0.3:
                pts[i] = (float(dist_m), float(med))
                return ("replaced", (med, n))
        pts.append((float(dist_m), float(med)))
        return ("ok", (med, n))

    def cal_add_point(self, anchor_id, drone_id, dist_m):
        """記錄一個標定點(當前濾波RSSI + 已知距離)。
        回傳 (狀態碼, 值):
          ("ok", rssi)         成功
          ("no_rssi", None)    該錨沒收到此機的RSSI(信標沒發/錨沒在線/距離太遠收不到)
          ("stale", age_ms)    RSSI 太舊(搬機後久未更新或信標丟幀)
          ("bad_dist", None)   距離無效
          ("dup_dist", d)      與已有點距離幾乎相同(無法定斜率)
        標定是靜態操作(機不動),用比解算更寬鬆的新鮮窗。"""
        if dist_m <= 0:
            return ("bad_dist", None)
        tr = self.tracks.get(drone_id)
        e = tr.rssi.get(anchor_id) if tr else None
        if e is None:
            return ("no_rssi", None)
        age = now_ms() - e[1]
        if age > C.CAL_FRESH_MS:       # 標定專用寬鬆窗
            return ("stale", age)
        r = float(e[0])
        pts = self._cal_pts.setdefault(anchor_id, [])
        # 距離已存在(差<0.3m)→ 覆蓋該點(重標同距離即更新,不用先刪)
        for i, (d0, _) in enumerate(pts):
            if abs(d0 - dist_m) < 0.3:
                pts[i] = (float(dist_m), r)
                return ("replaced", r)
        pts.append((float(dist_m), r))
        return ("ok", r)

    def cal_fit(self, anchor_id, drone_id):
        """對已採集的點最小二乘擬合 P0 與 n:RSSI = P0 − 10n·log10(d)。
        回傳 (狀態, 值):
          ("ok", (P0, n))       擬合成功且物理合理
          ("few_pts", n)        點數/距離不足
          ("bad_p0", p0)        P0 為正或離譜(多徑污染,數據不可信)
          ("bad_n", n)          n 出界(數據不單調,多徑污染)
          ("non_mono", None)    RSSI 明顯不隨距離遞減(近距離多徑)
        物理檢查會擋掉「2m比1m強」這種被多徑攪亂的數據,拒絕存入垃圾標定。"""
        pts = self._cal_pts.get(anchor_id, [])
        ds = sorted(set(p[0] for p in pts))
        if len(pts) < 2 or len(ds) < 2:
            return ("few_pts", len(ds))

        # 物理檢查1:整體趨勢必須「遠→弱」。按距離排序,檢查是否大致單調遞減。
        by_dist = sorted(pts, key=lambda t: t[0])
        # 允許局部抖動,但最遠點必須比最近點弱(否則整組數據被多徑污染)
        near_r = by_dist[0][1]
        far_r = by_dist[-1][1]
        if far_r > near_r + 1.0:   # 最遠反而比最近強>1dB → 數據不可信
            return ("non_mono", (by_dist[0][0], near_r, by_dist[-1][0], far_r))

        x = np.array([math.log10(d) for d, _ in pts])
        y = np.array([r for _, r in pts])
        A = np.vstack([x, np.ones_like(x)]).T
        try:
            (a, b), *_ = np.linalg.lstsq(A, y, rcond=None)
        except np.linalg.LinAlgError:
            return ("few_pts", 0)
        n = -a / 10.0
        p0 = b   # 直接用擬合截距。不扣機型偏移——單信標場景偏移機制無意義,
                 # 且殘留的壞偏移值曾污染P0(把-27拉成+14被誤拒)。
        if not (math.isfinite(n) and math.isfinite(p0)):
            return ("few_pts", 0)

        # 物理檢查2:P0 是「1m處RSSI」,2.4GHz近距離應在 -25~-55dBm。正數或>-15必是壞數據。
        if p0 > -15.0:
            return ("bad_p0", round(p0, 1))
        # 物理檢查3:n 出界(擬合斜率不合理→數據不單調)
        if n < 1.6 or n > 4.5:
            return ("bad_n", round(n, 2))

        C.RSSI_P0[anchor_id] = round(p0, 1)
        C.PATHLOSS_N_PER_ANCHOR[anchor_id] = round(n, 2)
        self._save_cal()
        return ("ok", (round(p0, 1), round(n, 2)))

    def cal_clear_points(self, anchor_id=None):
        if anchor_id is None:
            self._cal_pts.clear()
        else:
            self._cal_pts.pop(anchor_id, None)

    def cal_list_points(self, anchor_id):
        """回傳該錨的採樣點列表 [(dist, rssi), ...]，按距離排序。"""
        return sorted(self._cal_pts.get(anchor_id, []), key=lambda t: t[0])

    def cal_remove_point(self, anchor_id, dist_m, tol=0.15):
        """刪除指定距離的採樣點(用於去掉標歪的那一個)。回傳是否刪到。"""
        pts = self._cal_pts.get(anchor_id, [])
        for i, (d, _) in enumerate(pts):
            if abs(d - dist_m) < tol:
                pts.pop(i)
                return True
        return False

    def cal_point_count(self, anchor_id):
        return len(self._cal_pts.get(anchor_id, []))

    def calibrate_n(self, anchor_id, drone_id, dist_m, ref_dist_m=1.0):
        """自適應 n 標定（論文核心步驟）：已知機在距該錨 dist_m 處，
        用 P0(參考距離處值)與當前 RSSI 反算該錨專屬的 n：
            n = (P0[錨]+off[機] − rssi) / (10·log10(dist_m/ref))
        流程：先在 1m 標好 P0，再把機移到已知的較遠處(如 3~4m)按此鈕。
        兩點(近P0 + 遠rssi)定出真實衰減斜率 n —— 這正是你四個方向各異的關鍵。"""
        r = self._fresh_rssi(anchor_id, drone_id)
        if r is None:
            return None
        ratio = max(dist_m, 0.05) / max(ref_dist_m, 0.05)
        denom = 10.0 * math.log10(ratio)
        if abs(denom) < 1e-6:          # dist≈ref，無法定斜率
            return None
        p0 = C.RSSI_P0.get(anchor_id, -59.0) + C.DRONE_TX_OFFSET.get(drone_id, 0.0)
        n = (p0 - r) / denom
        n = max(1.5, min(4.5, n))      # 鉗在物理合理範圍
        C.PATHLOSS_N_PER_ANCHOR[anchor_id] = round(n, 2)
        self._save_cal()
        return C.PATHLOSS_N_PER_ANCHOR[anchor_id]

    def _save_cal(self):
        try:
            with open(C.P0_FILE, "w", encoding="utf-8") as f:
                json.dump({"p0": {str(k): v for k, v in C.RSSI_P0.items()},
                           "tx_offset": {str(k): v for k, v in C.DRONE_TX_OFFSET.items()},
                           "n": C.PATHLOSS_N,
                           "n_per_anchor": {str(k): v for k, v in
                                            C.PATHLOSS_N_PER_ANCHOR.items()}},
                          f, indent=1)
        except Exception:
            pass
