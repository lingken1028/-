# -*- coding: utf-8 -*-
"""串口鏈路（v1.7：自動重連）。

Gateway/遙控器復位或 USB 抖動時，埠會從作業系統消失又回來。舊版丟一個
io_error 就放棄，需要人工重連——現在讀線程自己負責「開埠 → 讀 → 斷線重試」
的整個生命週期：
  - 記住目標埠與其 hwid/序號：Linux 重枚舉改名（ttyACM0→ACM1）也能按序號找回。
  - 事件：("io_error", None) 每次斷線一次；("reconnected", {"port"}) 每次重連成功一次。
  - state: "disconnected" / "connected" / "reconnecting"（UI 據此顯示按鈕文字）。
"""
import threading
import time
import queue
import serial
import serial.tools.list_ports


def list_ports():
    return [(p.device, p.description) for p in serial.tools.list_ports.comports()]


class SerialLink:
    RETRY_S = 1.0          # 斷線後的重試間隔（測試會調小）

    def __init__(self, name: str, parser_feed, event_q: queue.Queue):
        """parser_feed(bytes) -> list[event]；event 以 (name, event) 入隊。"""
        self.name = name
        self._feed = parser_feed
        self._q = event_q
        self._ser = None
        self._thread = None
        self._run = False
        self._wlock = threading.Lock()
        self._want_port = None
        self._want_baud = None
        self._want_hwid = None
        self._state = "disconnected"

    # ── 對外 ────────────────────────────────────────────────────
    @property
    def state(self):
        return self._state

    @property
    def connected(self):
        return self._state == "connected"

    def open(self, port: str, baud: int) -> bool:
        """啟動連接（背景線程負責實際開埠與此後的所有重試）。
        回傳「1.2 秒內是否已連上」，False 不代表失敗——背景仍在重試。"""
        self.close()
        self._want_port = port
        self._want_baud = baud
        self._want_hwid = self._hwid_of(port)
        self._run = True
        self._state = "reconnecting"
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                        name=f"ser-{self.name}")
        self._thread.start()
        t0 = time.monotonic()
        while time.monotonic() - t0 < 1.2 and self._state == "reconnecting":
            time.sleep(0.05)
        return self._state == "connected"

    def close(self):
        self._run = False
        t = self._thread
        if t:
            t.join(timeout=1.5)
            self._thread = None
        self._close_ser()
        self._state = "disconnected"

    def write(self, data: bytes) -> bool:
        with self._wlock:
            s = self._ser
            if not (s and s.is_open and self._state == "connected"):
                return False
            try:
                s.write(data)
                return True
            except Exception:
                return False       # 讀線程會偵測到並進入重連

    # ── 內部 ────────────────────────────────────────────────────
    @staticmethod
    def _hwid_key(p):
        return getattr(p, "serial_number", None) or p.hwid

    def _hwid_of(self, dev):
        for p in serial.tools.list_ports.comports():
            if p.device == dev:
                return self._hwid_key(p)
        return None

    def _find_port(self):
        ports = list(serial.tools.list_ports.comports())
        for p in ports:                       # 先同名
            if p.device == self._want_port:
                return p.device
        if self._want_hwid:                   # 再同序號（重枚舉改名）
            for p in ports:
                if self._hwid_key(p) == self._want_hwid:
                    return p.device
        return None

    def _close_ser(self):
        with self._wlock:
            if self._ser:
                try:
                    self._ser.close()
                except Exception:
                    pass
                self._ser = None

    def _loop(self):
        first = True
        while self._run:
            dev = self._find_port()
            if not dev:
                self._state = "reconnecting"
                time.sleep(self.RETRY_S)
                continue
            try:
                ser = serial.Serial(dev, self._want_baud, timeout=0.05)
            except Exception:
                self._state = "reconnecting"
                time.sleep(self.RETRY_S)
                continue
            with self._wlock:
                self._ser = ser
            self._state = "connected"
            if first:
                first = False
            else:
                self._q.put((self.name, ("reconnected", {"port": dev})))

            while self._run:                  # 讀循環
                try:
                    data = ser.read(256)
                except Exception:
                    break
                if not data:
                    continue
                try:
                    for ev in self._feed(data):
                        self._q.put((self.name, ev))
                except Exception:
                    pass

            self._close_ser()
            if self._run:                     # 非人工關閉 → 通報並重試
                self._state = "reconnecting"
                self._q.put((self.name, ("io_error", None)))
                time.sleep(self.RETRY_S)
        self._close_ser()
