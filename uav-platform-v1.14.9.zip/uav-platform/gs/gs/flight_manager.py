# -*- coding: utf-8 -*-
"""飛行管理：地圖點目標 → 位置外環 → 兩條鏈路的 RC 指令流。

控制假設（誠實版）：
- ATK / nRF：先在遙控器/GS 上讓飛機進「定高模式」，本模組只接管橫側向
  （roll/pitch 指令，thrust 固定送 ATKP_THRUST_HOLD，yaw 固定 0）。
- ESP-FC：ESPFC 沒有定高 —— goto 只接管橫側向，油門永遠來自界面滑條（人管高度）。
- 機頭朝向：有 yaw 遙測就做世界系→機體系旋轉；沒有就假設機頭對準 +X（開飛前擺好）。
- 任一環節超時（位置過期 / 串口斷）→ 指令歸中，2 秒後棄任務。
"""
import math
import time
import threading
from . import config as C
from . import atkp
from . import gwlink


class Mission:
    def __init__(self, drone_id, tx, ty):
        self.drone_id = drone_id
        self.target = (tx, ty)
        self.state = "GOTO"          # GOTO / HOLD / STALE
        self.arrive_since = None
        self.stale_since = None


class FlightManager:
    def __init__(self, engine, remote_link, gateway_link, log):
        self.engine = engine
        self.remote = remote_link      # SerialLink → ATKP 橋接遙控器
        self.gateway = gateway_link    # SerialLink → Gateway
        self.log = log
        self.missions = {}             # drone_id -> Mission
        self.espfc_throttle = C.ESPFC_THROTTLE_DEFAULT
        self.espfc_armed = False
        self._espfc_streaming = False
        self._last = time.monotonic()
        self._mlock = threading.Lock()   # UI 線程增刪 / 控制線程迭代

    # ── 對外操作 ────────────────────────────────────────────────
    def goto(self, drone_id, tx, ty):
        if drone_id not in C.DRONES:
            return
        tr = self.engine.track(drone_id)
        if not tr.fresh:
            self.log(f"✗ 無人機 {drone_id} 沒有新鮮位置，拒絕 goto")
            return
        if C.DRONES[drone_id]["link"] == "espfc" and not self.espfc_armed:
            self.log("⚠ ESP-FC 未 ARM，goto 指令不會產生實際動作")
        with self._mlock:
            self.missions[drone_id] = Mission(drone_id, tx, ty)
        self.log(f"▶ goto: 機{drone_id} → ({tx:.2f}, {ty:.2f}) m")

    def cancel(self, drone_id):
        with self._mlock:
            existed = self.missions.pop(drone_id, None) is not None
        if existed:
            self._send_neutral(drone_id)
            self.log(f"■ 取消任務：機{drone_id}")

    def cancel_by_link(self, link_kind: str):
        """該鏈路串口斷開時棄掉其上所有任務（不發中性幀——鏈路已死，發不出去）。"""
        with self._mlock:
            gone = [d for d in self.missions
                    if C.DRONES.get(d, {}).get("link") == link_kind]
            for d in gone:
                self.missions.pop(d, None)
        for d in gone:
            self.log(f"■ 串口斷開，棄任務：機{d}")
        return gone

    def emergency_all(self):
        """急停：ATKP 連發 thrust=0（+可選指令幀）；ESPFC 收油門到底 + AUX 解除。"""
        with self._mlock:
            self.missions.clear()
        for did, info in C.DRONES.items():
            if info["link"] == "atkp" and self.remote.connected:
                if C.ATKP_CMD_EMER_STOP:
                    self.remote.write(atkp.pack_command(C.ATKP_CMD_EMER_STOP))
                for _ in range(5):
                    self.remote.write(atkp.pack_rc(0.0, 0.0, 0.0, C.ATKP_THRUST_ZERO))
        self.espfc_armed = False
        if self.gateway.connected:
            ch = [C.ESPFC_CH_MID, C.ESPFC_CH_MID, C.ESPFC_CH_MIN, C.ESPFC_CH_MID,
                  C.ESPFC_ARM_OFF, 1000, 1000, 1000]
            for _ in range(5):
                self.gateway.write(gwlink.encode_rc8(ch))
        self.log("‼ 急停已下發")

    # ── 主循環（UI 以 CTRL_HZ 呼叫）─────────────────────────────
    def step(self):
        now = time.monotonic()
        self._last = now

        done = []
        with self._mlock:
            items = list(self.missions.items())
        for did, ms in items:
            tr = self.engine.track(did)
            link = C.DRONES[did]["link"]

            if not tr.fresh:
                if ms.stale_since is None:
                    ms.stale_since = now
                    self.log(f"⚠ 機{did} 位置過期，指令歸中")
                self._send_attitude(did, link, 0.0, 0.0)
                if now - ms.stale_since > 2.0:
                    self.log(f"✗ 機{did} 位置持續丟失，棄任務")
                    done.append(did)
                continue
            ms.stale_since = None

            roll_cmd, pitch_cmd, err = self._outer_loop(tr, ms.target)
            self._send_attitude(did, link, roll_cmd, pitch_cmd)

            if err < C.ARRIVE_R:
                if ms.arrive_since is None:
                    ms.arrive_since = now
                elif ms.state == "GOTO" and now - ms.arrive_since > C.ARRIVE_HOLD_S:
                    ms.state = "HOLD"
                    self.log(f"✔ 機{did} 到達目標，保持中（取消任務以釋放）")
            else:
                ms.arrive_since = None

        if done:
            with self._mlock:
                for did in done:
                    self.missions.pop(did, None)
            for did in done:
                self._send_neutral(did)

        # ESPFC：只要 ARM 著就必須持續供流（含無任務時的姿態歸中）
        if self.espfc_armed:
            espfc_ids = [d for d, i in C.DRONES.items() if i["link"] == "espfc"]
            if not any(d in self.missions for d in espfc_ids):
                self._send_espfc(0.0, 0.0)
            self._espfc_streaming = True
        elif self._espfc_streaming:
            if self.gateway.connected:
                self.gateway.write(gwlink.encode_rcstop())
            self._espfc_streaming = False

    # ── 位置外環：err → v_des → a_cmd → 角度，世界系 → 機體系 ────
    def _outer_loop(self, tr, target):
        x, y = tr.xy
        vx, vy = tr.vxy
        ex, ey = target[0] - x, target[1] - y
        err = math.hypot(ex, ey)

        vdx = _clamp(C.GOTO_KP * ex, C.GOTO_VMAX)
        vdy = _clamp(C.GOTO_KP * ey, C.GOTO_VMAX)
        ax = _clamp(C.GOTO_KV * (vdx - vx), C.GOTO_AMAX)
        ay = _clamp(C.GOTO_KV * (vdy - vy), C.GOTO_AMAX)

        # 世界系加速度 → 姿態（小角度：a ≈ g·θ）
        pitch_w = math.degrees(ax / 9.81)    # +X 前進 = 低頭（+pitch 指令定義見下）
        roll_w = math.degrees(ay / 9.81)

        yaw = tr.yaw_deg
        psi = math.radians(yaw) if yaw is not None else 0.0
        cp, sp = math.cos(psi), math.sin(psi)
        # 機體系：前 = 世界向量在機頭方向的投影
        pitch_b = pitch_w * cp + roll_w * sp
        roll_b = -pitch_w * sp + roll_w * cp

        pitch_b = _clamp(pitch_b, C.ANGLE_MAX_DEG)
        roll_b = _clamp(roll_b, C.ANGLE_MAX_DEG)
        # 符號約定 [VERIFY]：+pitch = 機頭朝前傾（向 +X 加速）、+roll = 向 +Y 傾。
        # 首飛用 2° 手動注入驗證方向，錯了就在這裡取反。
        return roll_b, pitch_b, err

    # ── 鏈路輸出 ────────────────────────────────────────────────
    def _send_attitude(self, drone_id, link, roll_deg, pitch_deg):
        if link == "atkp":
            if self.remote.connected:
                self.remote.write(atkp.pack_rc(roll_deg, pitch_deg, 0.0, C.ATKP_THRUST_HOLD))
        else:
            self._send_espfc(roll_deg, pitch_deg)

    def _send_espfc(self, roll_deg, pitch_deg):
        if not self.gateway.connected:
            return
        span = (C.ESPFC_CH_MAX - C.ESPFC_CH_MIN) / 2.0
        r = C.ESPFC_CH_MID + roll_deg / C.ESPFC_ANGLE_FULLSCALE_DEG * span
        p = C.ESPFC_CH_MID + pitch_deg / C.ESPFC_ANGLE_FULLSCALE_DEG * span
        ch = [int(_clampv(r, C.ESPFC_CH_MIN, C.ESPFC_CH_MAX)),
              int(_clampv(p, C.ESPFC_CH_MIN, C.ESPFC_CH_MAX)),
              int(self.espfc_throttle),
              C.ESPFC_CH_MID,
              C.ESPFC_ARM_ON if self.espfc_armed else C.ESPFC_ARM_OFF,
              1000, 1000, 1000]
        self.gateway.write(gwlink.encode_rc8(ch))

    def _send_neutral(self, drone_id):
        link = C.DRONES[drone_id]["link"]
        self._send_attitude(drone_id, link, 0.0, 0.0)


def _clamp(v, lim):
    return max(-lim, min(lim, v))


def _clampv(v, lo, hi):
    return max(lo, min(hi, v))
