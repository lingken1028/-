# -*- coding: utf-8 -*-
import sys
from PySide6.QtCore import QLocale
from PySide6.QtWidgets import QApplication

# Windows 區域設置若開「使用本地數字」，Qt 會用蘇州碼子（〡〢…〩）渲染
# QDoubleSpinBox 的數字——〇.〩 其實是 0.9。強制 C locale 一勞永逸。
QLocale.setDefault(QLocale.c())
from gs.main_window import MainWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = MainWindow()
    w.resize(1180, 720)
    w.show()
    sys.exit(app.exec())
