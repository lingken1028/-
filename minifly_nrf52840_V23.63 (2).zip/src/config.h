#pragma once
#include <Arduino.h>
#include <stdint.h>
#include <stdbool.h>

/* ═══════════════════════════════════════════════════════════════════════════
 *  ATK-MiniFly → Seeed XIAO nRF52840 Sense  移植固件  配置总表
 *  ─────────────────────────────────────────────────────────────────────────
 *  全部 173 个 #define 按功能归入九大节。每宏一行注释(作用/单位/可调范围)。
 *  改参口诀: 一次只动一个, 记下原值, 装桨前先看第九节安全开关。
 *
 *   一、硬件引脚 / I2C / 地址        六、定高(基准·触地·起飞·垂直PID·气压融合·辅助)
 *   二、电池(读取方式·ADC标定)       七、飞行增强(推力线性化·AirMode·低压补偿·杆)
 *   三、传感器方向 / 数学常量        八、通信 / 系统 / 电机驱动
 *   四、姿态滤波 / 校准              九、⚠安全 / 测试开关(装桨飞行前必查)
 *   五、角速率 / 姿态 PID
 * ═══════════════════════════════════════════════════════════════════════════ */

/* ══【导读】本文件为全机唯一配置中枢, 分区: 一.引脚/I2C 二.电池/ADC
 * 三.安装方向 四.姿态滤波/校准 五.定高全参数(ALTHOLD_*触地三判据在此)
 * 六.失控保护(RC_LOSS_*) 七.无线ESB(信道/地址) 八.任务栈/优先级 等。
 * 铁律: 每个宏必须有真实代码引用(死宏审计见批5文档), 注释声称≠代码事实。 ══ */
/* ═══════════════════ 一、硬件引脚 / I2C / 地址 ═══════════════════ */

/* ── 电机引脚 (V22.5 适配实际接线) ── */
#define MOTOR1_PIN             D1   /* 电机1 PWM 输出脚 */
#define MOTOR2_PIN             D2   /* 电机2 */
#define MOTOR3_PIN             D3   /* 电机3 */
#define MOTOR4_PIN             D0   /* 电机4 */

/* ── 其他引脚 ── */
#define EXT_LED_PIN            D6   /* 外部 LED (active-HIGH) */

/* ── GY-91 外部 I2C (TWIM0 @ D8/D10) ── */
#define GY91_SDA               D10   /* SDA 引脚 (D10) */
#define GY91_SCL               D8   /* SCL 引脚 (D8) */
#define GY91_AD0               D9   /* AD0: LOW→MPU9250=0x68 / BMP280=0x76 */
#define GY91_SCL_PORT          1u   /* SCL 的 nRF 端口号 (P1) */
#define GY91_SCL_PIN           13u   /* SCL 的 nRF 引脚号 (D8=P1.13) */
#define GY91_SDA_PORT          1u   /* SDA 端口 (P1) */
#define GY91_SDA_PIN           15u   /* SDA 引脚 (D10=P1.15) */

/* ── GY-91 开机断电重上电 (V22.38): BMP280 偶发 POR 失败时用电源循环兜底 ── */
#define GY91_PWR_CYCLE_ENABLE  0   /* 1=开机给 GY-91 断电再上电; 0=关 */
#define GY91_PWR_PIN           D5   /* 控制 GY-91 供电的脚 */
#define GY91_PWR_ON_LEVEL      HIGH   /* 供电有效电平 */
#define GY91_PWR_OFF_MS        250   /* 断电保持 ms(确保电彻底放掉) */
#define GY91_PWR_SETTLE_MS     120   /* 上电后等 BMP280 POR 完成再探测 ms */

/* ── 板载 LSM6DS3TR-C 内部 I2C (TWIM1) ── */
#define IMU_INT_SCL_PORT       0u   /* 板载 IMU SCL 端口 (P0) */
#define IMU_INT_SCL_PIN        27u   /* SCL 引脚 (P0.27) */
#define IMU_INT_SDA_PORT       0u   /* SDA 端口 (P0) */
#define IMU_INT_SDA_PIN        7u   /* SDA 引脚 (P0.7) */
#define IMU_INT_PWR_PORT       1u   /* 板载 IMU 电源使能 端口 (P1) */
#define IMU_INT_PWR_PIN        8u   /* 电源使能 引脚 (P1.8, 高=供电) */

/* ── I2C 从机地址 ── */
#define MPU9250_I2C_ADDR       0x68   /* MPU9250 (GY-91 主 IMU) */
#define BMP280_I2C_ADDR_HW     0x76   /* BMP280 气压计  （说明性: 实际双地址探测0x76/0x77见bmp280.cpp, 改此宏不生效） */
#define LSM6DS3_ADDR           0x6A   /* 板载 LSM6DS3TR-C 6DOF  （说明性: 实际探测见sensors.cpp, 改此宏不生效） */

/* ═══════════════════ 二、电池 (读取方式 + ADC 标定) ═══════════════════ */

/* ── 电压读取方式 (V22.40) ──
 *  =1: 用 XIAO 背面 BAT 焊盘的内置检测电路(接电池即用, 不占 D 脚, 推荐)。
 *      P0.31(AIN7)读分压; ★P0.14 必须保持 LOW, 置 HIGH 时 P0.31 可能到 3.6V 烧脚。
 *  =0: 用外部分压器, BAT_ADC_PIN 必须 D0~D5(仅 P0 口有 ADC)。 */
#define BAT_USE_INTERNAL 1   /* 1=内置检测电路 / 0=外部分压器 */
#if BAT_USE_INTERNAL
  #define BAT_ADC_PIN     PIN_VBAT   /* 内置 P0.31 (pm.cpp 有 #ifndef 兜底) */
  #define BAT_DIV_RATIO   2.961f     /* 分压比 1510/510 (内置 1M+510k) */
  #define BAT_CALIB       1.0f       /* 读数标定系数, 内置分压已知先用 1.0 */
#else
  #define BAT_ADC_PIN     D4         /* 外部分压 ADC 脚 (必须 D0~D5) */
  #define BAT_DIV_RATIO   2.0f       /* 外部 10k+10k = 1:2 */
  #define BAT_CALIB       0.87f      /* 外部分压标定系数 */
#endif
/* 标定(一次): BAT_CALIB = 万用表真实电压 ÷ 显示电压, 改上面对应分支, 重编。 */

/* ── ADC 与低压判定 ── */
#define PM_BAT_LOW_VOLTAGE     3.35f   /* 低压阈值 V(触发 LED/上报低压标志) */
#define PM_BAT_LOW_TIMEOUT_MS  5000u   /* 低于阈值持续多久才判定 ms */
#define BAT_ADC_VREF           3.0f   /* ADC 参考 V (V22.18: 匹配内部 3.0V 基准, 不随 VDD 漂) */
#define BAT_ADC_RES            4096.0f   /* ADC 分辨率 (12-bit=4096) */

/* ── 电压下垂(载荷)补偿 (V22.96) — 修"给油门电压猛掉但其实还有电"的低压误判 ──
 *  静息电压 ≈ 实测V + K×(油门/65535); 仅用于低压判定, 显示与姿态补偿仍用实测V。
 *  标定: K = (怠速V - 悬停V) / (悬停thr/65535)。默认 0 = 关(行为不变)。 */
#define VBAT_SAG_COMP_K        0.5f   /* 下垂补偿系数 K(V23.62 依用户要求启用)。
                                      * 用途: 低压判定改用「静息电压」= 实测v + K×油门占比,
                                      * 使大油门时的瞬时压降不再触发假低压告警。
                                      * 0.35 表示满油门时补偿 0.35V — 依你电池压降情况可调:
                                      * 仍误报低压→调大(0.4~0.5); 电池真的没电却不报→调小。
                                      * ⚠ 只影响低压【判定】, 显示的电压仍是实测值。 */

/* ── 上报电压夹紧(防偶发乱值致遥控器不显示)── */
#define BAT_REPORT_MIN         2.5f   /* 上报电压下限 V */
#define BAT_REPORT_MAX         4.5f   /* 上报电压上限 V */

/* ═══════════════════ 三、传感器安装方向 / 数学常量 ═══════════════════ */

/* ── 数学常量 ── */
#define DEG2RAD                0.017453293f   /* 角度→弧度 */
#define RAD2DEG                57.29578f   /* 弧度→角度 */
#define GRAVITY_CMSS           980.0f   /* 重力加速度 cm/s² */

/* ── 传感器轴映射 / 符号 (安装方向; MAP=轴重排, SIGN=正负翻转) ── */
#define GY91_AXIS_MAP          {0, 1, 2}   /* GY-91 轴顺序 {x,y,z} */
#define GY91_AXIS_SIGN         {1, 1, 1}   /* GY-91 轴符号 */
#define LSM6_AXIS_MAP          {0, 1, 2}   /* 板载 LSM6 轴顺序 */
#define LSM6_AXIS_SIGN         {-1, -1, 1}   /* 板载 LSM6 轴符号(装反→翻负) */

/* ── 铁律 V23.35 D43: 传感器ODR必须<=任务读取率(奈奎斯特)! LSM6陀螺曾833Hz被500Hz读→混叠→抖, V22.85降416救命 ── */
/* ── MPU9250 陀螺数字低通 DLPF (V22.19) ── */
#define MPU_GYRO_DLPF          MPU6500_DLPF_BW_98   /* MPU 陀螺硬件低通带宽档 */

/* ═══════════════════ 四、姿态滤波 / 校准 ═══════════════════ */
/*    (Mahony · 加计拒绝 · 开机校平+Kp提升 · 磁偏航 · 双IMU · 陷波) */

/* ── Mahony 姿态滤波增益 (V22.56) ── */
#define MAHONY_KP              0.3f   /* 加速度修正P(减晃→0.25; 跑偏→0.4) */
#define MAHONY_KI              0.005f   /* 陀螺零偏消除I(V22.92: 修越飞越前飘) */
#define MAHONY_KI_LIMIT        0.08f   /* I 积分限幅 rad/s(防 windup, ≈4.6°/s) */

/* ── 加速度拒绝 (V22.57) — 治移动时前后/左右晃 ── */
#define ACC_REJECT_ENABLE      1   /* 1=开启加速度拒绝; 0=关 */
#define ACC_REJECT_RANGE       0.15f   /* 偏离量 g²到此修正降到MIN(还晃→调小) */
#define ACC_REJECT_MIN         0.2f   /* 拒绝时最小修正比(V22.92: 0.1→0.2) */

/* ── 水平微调 trim (V22.92 架构) — 遥控器物理微调 + 固件基准 ── */
#define USE_REMOTE_TRIM        1   /* 1=启用遥控器物理trim(出站发0不回传) */

/* ── 油门-姿态补偿 (V22.78): 油门高时叠加微调度数, 补桨差/重心 ── */
#define THROTTLE_TRIM_ENABLE   1   /* 1=开启(斜率全0时无效果) */
#define THROTTLE_TRIM_REF      38000   /* 悬停油门参考(此油门补偿=0) */
#define THROTTLE_TRIM_SLOPE_R  0.0f   /* 横滚: 每高于REF一万油门叠加度数 */
#define THROTTLE_TRIM_SLOPE_P  0.0f   /* 俯仰: 同上 */

/* ── 6DOF(板载LSM6单用)专用水平微调 (V22.90) ── */
/* V23.22: 6DOF独立水平微调已删除 — 融合与纯LSM6两模式统一用 configParam.trim(见state_control),
 * 避免换模式trim源不一致/上位机校准被覆盖。6DOF水平微调: 用上位机校准(存configParam)或遥控器物理trim。 */

/* ── 开机自动水平校平 (V22.53) ── */
#define BOOT_AUTO_LEVEL_ENABLE 1   /* 1=开机自动校平; 0=只手动 */
#define BOOT_AUTO_LEVEL_DELAY  3.0f   /* 开机等几秒再校(等滤波收敛, 2~5) */
#define BOOT_AUTO_LEVEL_STILL_DPS 8.0f   /* 陀螺<此值才算静止可校 deg/s */
#define BOOT_AUTO_LEVEL_MAX_TILT 25.0f   /* 倾斜保护: 零偏>此角放弃 度 */

/* ── 开机 Kp 提升 (V22.65, 配合自动校平快速收敛) ── */
#define BOOT_KP_BOOST_ENABLE   1   /* 1=开机Kp提升; 0=关 */
#define BOOT_KP_BOOST_TIME     2.5f   /* 提升持续秒(须<AUTO_LEVEL_DELAY) */
#define BOOT_KP_BOOST_KP       5.0f   /* 提升期Kp(高→快, τ≈1/Kp秒) */

/* ── 9轴磁力计偏航融合 (V22.24) — 绝对航向(需罗盘校准) ── */
#define USE_MAG_YAW            1   /* 1=开磁偏航融合(yaw=罗盘航向) */
#define MAG_YAW_KP             0.4f   /* 偏航校正增益 1/s(低=抗扰慢跟) */
#define MAG_YAW_SIGN           -1   /* 符号(V22.66: 修校磁后yaw振荡) */
#define MAG_YAW_THR_GATE       0.85f   /* 高油门降磁权重(V22.76: 抗电机磁扰) */
#define MAG_YAW_GATE_MIN       0.1f   /* 磁增益门控地板(高油门段最低权重) */

/* ── 磁校准预设 (V23.45): 免去每次上电都要在上位机重校 ──
 * 本移植版 configParam 是纯 RAM(configParamInit 直接 memcpy 默认值, saveConfigAndNotify 不写flash),
 * 磁校准结果 s_magBias/s_magScale 断电即失 → 每次开机 magcal=-1, 磁偏航融合不生效。
 * 用法: 上位机校准一次 → 串口会打印 [MAGCAL] bias=... scale=... → 抄到下面 → 置 MAG_CAL_PRESET 1。
 * 此后开机即 magcal=100, 无需再校。换机架/换磁环境(挪到别的场地有大铁件)需重测一次。 */
#define MAG_CAL_PRESET         0   /* 0=每次开机需上位机校准(原行为); 1=用下面预设值 */
#define MAG_CAL_ON_BOOT        0   /* V23.47: 1=开机自动进入磁校准, 全程只需XCOM不需上位机。
                                    * 流程: 置1→烧录→开XCOM→上电→水平慢转飞机约12秒(看magcal 0→100)
                                    *       →XCOM持续打印[MAGCAL]那6个值→抄到下面→MAG_CAL_PRESET置1
                                    *       →本项改回0→重新烧录。此后开机即已校准。 */
#define MAG_BIAS_X             0.0f
#define MAG_BIAS_Y             0.0f
#define MAG_BIAS_Z             0.0f
#define MAG_SCALE_X            1.0f
#define MAG_SCALE_Y            1.0f
#define MAG_SCALE_Z            1.0f

/* ── 双 IMU 陀螺融合 (V22.27) ── */
#define DUAL_IMU_GYRO          0   /* 1=融合双IMU陀螺; 0=只用MPU(V22.84默认) */
#define DUAL_IMU_DISAGREE_LSB  1000   /* 两陀螺差>此值时软降LSM权重 */
#define DUAL_IMU_MPU_WEIGHT    0.6f   /* MPU标称权重(余下给LSM) */
#define DUAL_IMU_FUSE_YAW      0   /* 1=融合yaw轴; 0=yaw只用MPU */
#define DUAL_IMU_LSM_DIV       2   /* LSM每N周期读一次(2=250Hz) */

/* ── 陀螺振动陷波 (V22.27/V22.69自适应) ── */
/* ═══════════════════ 五、角速率 / 姿态 PID ═══════════════════ */
/*    (D低通 · 抗饱和 · D-on-measurement · 前馈) */

/* ── PID 微分项(D)低通 (V22.21): 抑制 D 项高频噪声 ── */
#define PID_DTERM_LPF_ENABLE   1   /* 1=开D项低通; 0=关 */
#define PID_DTERM_LPF_HZ       50.0f   /* D项低通截止 Hz */

/* ── 抗积分饱和 ── */
#define PID_ANTIWINDUP_ENABLE  1   /* 1=开抗windup(输出饱和时冻结I) */

/* ── D 项来源 + 前馈 (V22.61) ── */
#define PID_DERIV_ON_MEASUREMENT 1   /* 1=D on measurement(避免设定点微分冲击) */
#define PID_RATE_FF_ENABLE     1   /* 1=开角速率前馈 */
#define PID_RATE_FF_GAIN       0.1f   /* 比例前馈增益(0.05~0.2调手感) */
#define PID_RATE_FF_D_GAIN     0.0f   /* 微分前馈(默认关, 0.002~0.01试) */

/* ═══════════════════ 六、定高 ═══════════════════ */
/*    (基准油门 · 触地判停 · 起飞平顺 · 垂直PID · 加速度前馈 · 气压融合 · 辅助) */

/* ── 基准与目标 ── */
#define ALTHOLD_THRUST_BASE    34000u   /* 悬停基准油门(V23.63 实测值; 38000 会冲天且油门到底降不下来) */
#define ALTHOLD_TAKEOFF_HEIGHT 80.0f   /* 一键起飞目标高度 cm */
#define ALTHOLD_LAND_SPEED     80.0f   /* 一键降落下降速度 cm/s(越小越柔) */
#define ALTHOLD_LAND_THR_DROP  11000.0f   /* 降落停机: 油门跌破(base-此值)判触地 */

/* ── 触地判停三判据(①油门跌破②加速度尖峰③速度停住)── */
#define ALTHOLD_TD_ACC_MAX     250.0f   /* ②加速度正向尖峰阈值 cm/s² */
#define ALTHOLD_TD_ACC_MIN     -100.0f   /* ②加速度负向骤跌阈值 cm/s² */
#define ALTHOLD_TD_STICK_ACC   250.0f   /* 油门杆下拉触地的加速度阈值 cm/s² */
#define ALTHOLD_TD_VEL_ENABLE  1   /* ③1=启用速度触地判停(对轻落地灵敏) */
#define ALTHOLD_TD_VEL_STOP    18.0f   /* ③"已停住"速度阈值 cm/s */
#define ALTHOLD_TD_VEL_CNT     40   /* ③持续次数(@100Hz, 40=0.4s) */

/* ── 起飞平顺 ── */
#define ALTHOLD_TAKEOFF_CLIMB  60.0f   /* ①一键起飞最大爬升速度 cm/s(调低更柔) */
#define ALTHOLD_THRUST_SLEW_ENABLE 1   /* ②1=限制定高油门每周期变化率(减晃) */
#define ALTHOLD_THRUST_SLEW    600.0f   /* ②每250Hz周期油门最大变化量 */

/* ── 垂直 PID (V22.54基线; 一次只动一个) ── */
#define ALTHOLD_VZ_KP          100.0f   /* 速度环P */
#define ALTHOLD_VZ_KI          150.0f   /* 速度环I ★记住的悬停油门★ 别动 */
#define ALTHOLD_VZ_KD          5.0f   /* 速度环D(V22.62: 垂直阻尼, 半改前馈) */
#define ALTHOLD_Z_KP           6.0f   /* 位置环P(起飞蹿/晃才降) */
#define ALTHOLD_Z_KD           4.5f   /* 位置环D(阻尼, 太小易过冲) */

/* ── 直接加速度前馈 (V22.62): 干净的垂直阻尼来源 ── */
#define ALTHOLD_ACC_FF_ENABLE  1   /* 1=开加速度前馈 */
#define ALTHOLD_ACC_FF_GAIN    5.0f   /* 前馈增益 */

/* ── 气压/速度低通 (V22.34) ── */
#define BARO_ALT_LPF_ENABLE    1   /* 1=开气压海拔低通(改善浮动) */
#define BARO_ALT_LPF_HZ        15.0f   /* 气压海拔低通截止 Hz(低=平滑但滞后) */
#define ALT_VELZ_LPF_ENABLE    1   /* 1=开垂直速度低通(减油门抖) */
#define ALT_VELZ_LPF_HZ        20.0f   /* 垂直速度低通截止 Hz */

/* ── 气压/加速度互补融合 (V22.48/V22.72) ── */
#define BARO_FUSE_WEIGHT       0.6f   /* 位置校正权重Kp(跟不上→0.8, 抖→0.5) */
#define BARO_FUSE_DAMPING      0.7f   /* 互补滤波阻尼比ζ(0.7近临界; 振→0.8~1.0) */

/* ── 高度估计辅助 (V23.17 S3三件套之①②; ③=上面BARO_FUSE_WEIGHT) ── 各独立可关 ──
 *  ① 3点中值: 杀单拍气压尖峰(静置GS±1m快跳第一嫌疑), 延迟1拍。
 *  ② ZUPT: 电机停+陀螺静≥0.3s → vz拉0 + 快学acc偏置; 治静置下漂/vz踢腿, 飞行零影响。 */
#define BARO_MEDIAN_ENABLE     1   /* ①1=气压3点中值滤波 */
#define ZUPT_ENABLE            1   /* ②1=静置零速+偏置快学 */

/* ── 爬升卡死看门 (V23.10, 定高保护) — 默认关(历史两次误伤起飞) ──
 *  气压【读取】失效保护(>800ms读不到)始终常开, 与此无关。再试: 设1并先给BMP280盖泡棉。 */
/* ── V23.23【文献重构】爬升失控保护(定高第二道防线, 与失联无关)── 默认关 ──
 *   旧版(V23.07-08)用"气压高度窗口内没涨"判卡死 = 用被监控量监控自己(逻辑自指), 桨洗/正常慢爬误判 →
 *   两次误伤起飞。PX4/ArduPilot 的位置失效保护只在有独立航向源(GPS/光流)时触发, 从不自指。
 *   新法: 监控【油门饱和】— 定高模式油门持续顶到接近满(>58000)超过 SAT_S 秒 = 控制器饱和仍够不着目标
 *   = 真失控 → 转缓降交人。对桨洗噪声免疫(饱和是持续态)。V23.18已修绝对目标bug(冲天主因), 此为兜底。
 *   想开: 设1。SAT_S 别太小(正常大幅度拉升也会短暂饱和), 2秒是安全下限。 */
#define CLIMB_STUCK_WATCHDOG   0
#define CLIMB_STUCK_SAT_S      2.0f

/* ═══════════════════ 七、飞行增强算法 ═══════════════════ */
/*    (推力线性化 · Air Mode · 低压补偿 · 偏航杆) */

/* ── 推力线性化 (V22): 补偿 thrust∝duty² 非线性, 各油门段权威一致 ── */
#define THRUST_LIN_ENABLE      1   /* 1=开推力线性化 */
#define THRUST_LIN_REF         38000.0f   /* 参考油门(=悬停油门, PID在此调校) */
#define THRUST_LIN_MIN_SCALE   0.7f   /* 高油门最小修正倍(防高端过冲) */
#define THRUST_LIN_MAX_SCALE   1.5f   /* 低油门最大修正倍(下降软可升1.8) */

/* ── Air Mode (V22.58缩放式, 不扰高度): 低油门保姿态权威 ── */
#define AIRMODE_ENABLE         1   /* 1=开Air Mode */
#define AIRMODE_MIN_THRUST     10000   /* 油门>此值才启用(区分飞行/落地) */
#define AIRMODE_MOTOR_IDLE     3000   /* Air Mode最低电机不低于此(防停转) */

/* ── 低电压姿态权威补偿 (V22): 电压下垂时放大修正保操控 ── */
#define VBAT_COMP_ENABLE       1   /* 1=开低压补偿; 0=关(原版行为) */
#define VBAT_COMP_NOMINAL      3.7f   /* 标称电压V(低于此开始放大) */
#define VBAT_COMP_MAX          1.35f   /* 最大放大倍(防过补振荡) */
#define VBAT_COMP_LPF          0.002f   /* vbat慢滤波系数(只跟下垂不跟纹波) */

/* ── 遥控杆处理 ── */
#define REMOTE_YAW_INVERT      0   /* 1=偏航杆反向 */
#define RC_DEADBAND_YAW        2.0f   /* 偏航杆死区 deg/s(0=关) */
#define RC_DEADBAND_RP         0.0f   /* 横滚/俯仰杆死区 度(0=关) */

/* ═══════════════════ 八、通信 / 系统 / 电机驱动 ═══════════════════ */
/*    (ESB无线 · 看门狗 · PWM · 软启动 · 任务堆栈/优先级) */

/* ── ESB 无线链路 (与遥控器配对) ── */
#define ESB_DEFAULT_CHANNEL    2u   /* ESB 射频信道 */
#define ESB_ADDR_HIGH          0x00000012UL   /* 配对地址 高字节 */
#define ESB_ADDR_LOW           0x3456789AUL   /* 配对地址 低字节 */
#define RADIOLINK_TIMEOUT_MS   1000u   /* 链路超时 ms(超过判失联) */

/* ── 看门狗 ── */
#define WATCHDOG_RESET_MS      150u   /* 看门狗超时 ms  （说明性: 实际用vTaskDelay喂狗见system.cpp, 改此宏不生效） */

/* ── 固件版本(心跳 fw= / 开机横幅)── */
#define FW_VERSION           "23.63"   /* 固件版本号(每次发布必改) */

/* ── 电机 PWM 驱动 ── */
#define MOTOR_HIGHFREQ_PWM     1   /* 1=高频PWM(降电机啸叫) */
#define MOTORS_PWM_FREQ_HZ     62500u   /* PWM 频率 Hz  （说明性: 实际由setClockDiv+setMaxValue算出见motors.cpp, 改此宏不生效） */
#define MOTOR_SOFTSTART_ENABLE 1   /* 1=油门软启动(防解锁猛冲) */
#define MOTOR_SOFTSTART_STEP   0.02f   /* 软启动每步增量(0~1) */

/* ── FreeRTOS 任务堆栈(字)── */
#define STACK_START            1536  /* 512→1536字(2KB→6KB)。ALIVE循环跑在startTask里,
                                      * 每2秒一次带十几个%f的snprintf — newlib浮点格式化需600~1500字节,
                                      * 加上 line[384] 等局部, 2KB 余量过紧。RAM共256KB, 多4KB无压力。 */
#define STACK_RADIOLINK        512   /* 无线链路任务 */
#define STACK_USBLINK_RX       512   /* USB 接收 */
#define STACK_USBLINK_TX       384   /* USB 发送 */
#define STACK_ATKP_TX          384   /* ATKP 协议发送 */
#define STACK_ATKP_RX          512   /* ATKP 协议接收 */
#define STACK_CONFIG           256   /* 配置任务 */
#define STACK_PM               256   /* 电源管理 */
#define STACK_SENSORS          1024   /* 传感器读取 */
#define STACK_STABILIZER       1024   /* 姿态/控制主任务 */

/* ── FreeRTOS 任务优先级(高数字=高优先)── */
/* V23.62 优先级修正 —— 原安排违反实时控制层级, 是侧翻与上位机卡顿的根因:
 *   ATKP_RX=6 高于 STABILIZER=5 → 上位机一连, 每秒上百包的解析任务
 *   就抢占正在跑 PID 的姿态任务; SENSORS=4 又低于姿态任务 → 传感器
 *   读取被双双压制, 姿态解算拿到的是迟到的数据 → 控制发散、侧翻。
 * 正确层级: 传感器 > 姿态控制 > 无线 > 通信解析 > 后台。
 * 传感器必须最高: 它是控制链的输入, 迟到一拍全链路都错。 */
#define PRIO_START             4   /* 启动任务 */
#define PRIO_SENSORS           6   /* 传感器读取 — 控制链输入, 最高优先 */
#define PRIO_STABILIZER        5   /* 姿态/控制主任务 */
#define PRIO_RADIOLINK         4   /* 无线链路(遥控指令) */
#define PRIO_ATKP_RX           3   /* ATKP 接收(上位机) — 绝不可高于控制 */
#define PRIO_USBLINK_RX        3   /* USB 接收 */
#define PRIO_ATKP_TX           2   /* ATKP 发送 */
#define PRIO_USBLINK_TX        2   /* USB 发送 */
#define PRIO_PM                2   /* 电源管理 */
#define PRIO_CONFIG            1   /* 配置任务 */

/* ═══════════════════ 九、⚠ 安全 / 测试开关 (装桨飞行前必查!) ═══════════════════ */

/* ── 异常保护 ── */
#define ENABLE_TUMBLE_DISARM   1   /* 1=翻倒>60°自动切电(始终建议开) */
#define ENABLE_FREEFALL_LAUNCH 0   /* 1=自由落体抛飞启动(默认0关) */

/* ── 失联/关机动作 (RC_LOSS_ACTION) ── V23.23【文献对照 PX4/ArduPilot】──
 *  商业飞控失控保护的两条铁律:
 *    ① "先给反应窗口再动作": PX4 失联后先进 Hold 悬停 COM_FAIL_ACT_T 秒, 让飞手有机会切模式接管,
 *       再执行落地。→ 对应本固件动作1(悬停等待)。ArduPilot 失联可选 do-nothing/land/RTL。
 *    ② "缓降不需要位置估计": PX4 的 Descend 模式是"不依赖位置估计的落地"→ 无光流也能安全下降。
 *       但水平位置会漂(无GPS/光流是物理限制, 非固件缺陷)。→ 对应本固件动作2(缓降)。
 *  三个动作怎么选(你的机器无GPS/光流):
 *    0 = 失联>1s直接切油门(落体)。最简单可预测, 你当前选择; 适合室内低空+安全绳/软垫。
 *        (缓降/悬停/救援代码全部 #if 编译剔除, 零运行开销。)
 *    1 = 先悬停 RC_LOSS_HOVER_MAX_S 秒(给你抢救时间, PX4式)→ 超时转缓降。适合有一定高度、想抢救。
 *    2 = 立即缓降(PX4 Descend式): 按 RC_LOSS_LAND_SPEED 匀速下降到 RC_LOSS_CUT_HEIGHT 切电。
 *  注: 无论哪种, 水平漂移无法靠固件消除(需光流/GPS)。想要真正"失联悬停不动"必须上光流。 */
#define RC_LOSS_ACTION         0        /* 0切/1悬停后缓降/2立即缓降 */
#define RC_LOSS_GRACE_S        2.0f     /* V23.24: ACTION=0 短暂失联宽限秒 — 定高在飞时断线, 先【保持当前高度】
                                         * 等这么久, 期间信号回来→无缝续飞同高度同位置继续遥控(你的需求);
                                         * 超时才真落地。0=关(断线立即落, 原行为)。抖动/穿墙短断线建议2~3秒。 */
#define RC_LOSS_HOVER_MAX_S    8.0f     /* 动作1: 悬停等待秒(=PX4 COM_FAIL_ACT_T反应窗口), 超时转缓降 */
#define RC_LOSS_LAND_SPEED     15.0f    /* 动作1/2缓降速度 cm/s(V23.13: 25→15更柔) */
#define RC_LOSS_CUT_HEIGHT     15.0f    /* 降到此高度 cm切电机(落地保护) */
#define RC_LOSS_LAND_MAX_S     30.0f    /* 缓降兜底超时秒(防估计漂移致悬不下来) */

/* ── V23.38: 多机广播接收(统一分时架构第一步) ──
 *  飞机在私有地址(pipe0, 配对可变)之外, 固定监听一个广播地址(pipe1)。
 *  用途: 遥控器"同步广播"模式一包 NOACK 全体同收(编队同飞, 带宽与台数无关)。
 *  规则: 广播包【绝不回ACK】(N 机同答必碰撞), 但照常刷新链路活跃/进指令流。
 *  本版仅加"耳朵", 遥控器未改 → 行为与 V23.37 完全一致(回归验证)。 */
#define RADIO_BCAST_EN         1                /* 1=监听广播地址(pipe1); 0=仅私有(回V23.37行为) */
#define RADIO_BCAST_ADDR       0xB1B2B3B4B5ULL  /* 固定广播地址(独立于配对), 遥控器端须一致 */

/* ── 测试/降级开关(平时保持默认!)── */
#define ALLOW_FLIGHT_WITHOUT_BARO 1   /* 1=允许无气压计飞行(6DOF板) */
#define FORCE_MANUAL_MODE      0   /* 1=强制手动模式(调试) */
#define FORCE_CANFLY           0   /* 1=跳过起飞前检查(危险!调试) */
#define MOTOR_TEST_EQUAL_MODE  0   /* 1=四电机等值测试模式(危险!) */
#define MOTOR_TEST_EQUAL       0   /* 等值测试油门值 */
#define DISABLE_VOLTAGE_PROTECTION 0   /* 1=禁用电压保护(危险!) */