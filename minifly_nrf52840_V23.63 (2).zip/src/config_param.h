/**
 * @file    config_param.h
 * @brief   飞行参数配置
 *          对应: CONFIG/interface/config_param.h (结构体逐字对照)
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>

typedef struct { float kp, ki, kd; } pidInit_t;

typedef struct {
    pidInit_t roll;
    pidInit_t pitch;
    pidInit_t yaw;
} pidParam_t;

typedef struct {
    pidInit_t vx, vy, vz;
    pidInit_t x,  y,  z;
} pidParamPos_t;

typedef struct {
    uint8_t       version;
    pidParam_t    pidAngle;
    pidParam_t    pidRate;
    pidParamPos_t pidPos;
    float         trimP;
    float         trimR;
    uint16_t      thrustBase;
    uint8_t       cksum;
} configParam_t;

extern configParam_t configParam;

void configParamInit(void);
void configParamTask(void* param);
bool configParamTest(void);
void configParamGiveSemaphore(void);
void resetConfigParamPID(void);
void saveConfigAndNotify(void);