/**
 * @file    config_param.cpp
 * @brief   飞行参数配置实现
 *          对应: CONFIG/src/config_param.c
 *
 * 移植变化:
 *   STMFLASH_Read/Write (STM32 Flash) → RAM 默认值
 *   所有默认值完全来自原始固件 configParamDefault (逐字对照):
 *     pidAngle.roll   kp=8.0   ki=0    kd=0
 *     pidAngle.pitch  kp=8.0   ki=0    kd=0
 *     pidAngle.yaw    kp=20.0  ki=0    kd=1.5
 *     pidRate.roll    kp=260.0 ki=0    kd=6.5(V23.63 實測)
 *     pidRate.pitch   kp=260.0 ki=0    kd=6.5(V23.63 實測)
 *     pidRate.yaw     kp=200.0 ki=18.5 kd=0
 *     pidPos.vz       kp=100.0 ki=150.0 kd=10.0
 *     pidPos.z        kp=6.0   ki=0    kd=4.5
 *     thrustBase = 34000
 *     VERSION = 13 (V1.3)
 */
#include "config_param.h"
#include "config.h"        /* V22.26: ALTHOLD_THRUST_BASE */
#include <string.h>
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>

#define VERSION 13

configParam_t configParam;

/* 完整 configParamDefault (对应原始固件每个字段) */
static const configParam_t configParamDefault = {
    .version  = VERSION,
    .pidAngle = {
        .roll  = {8.0f,   0.0f,  0.0f},
        .pitch = {8.0f,   0.0f,  0.0f},
        .yaw   = {20.0f,  0.0f,  1.5f},
    },
    .pidRate = {
        .roll  = {260.0f, 0.0f,  6.5f},
        .pitch = {260.0f, 0.0f,  6.5f},
        .yaw   = {200.0f, 18.5f, 0.0f},
    },
    .pidPos = {
        .vx = {4.5f,   0.0f,   0.0f},
        .vy = {4.5f,   0.0f,   0.0f},
        .vz = {ALTHOLD_VZ_KP, ALTHOLD_VZ_KI, ALTHOLD_VZ_KD},  /* V22.52: 暴露到 config.h */
        .x  = {4.0f,   0.0f,   0.6f},
        .y  = {4.0f,   0.0f,   0.6f},
        .z  = {ALTHOLD_Z_KP, 0.0f, ALTHOLD_Z_KD},             /* V22.52: 暴露到 config.h */
    },
    .trimP      = 0.0f,
    .trimR      = 0.0f,
    .thrustBase = ALTHOLD_THRUST_BASE,  /* V22.26: 提为 config.h 可调 (≈悬停油门, 起飞关键) */
    .cksum      = 0,
};

static SemaphoreHandle_t s_sem  = NULL;
static bool              s_init = false;

static uint8_t configParamCksum(const configParam_t* d) {
    const uint8_t* p = (const uint8_t*)d;
    uint8_t ck = 0;
    for (size_t i = 0; i < sizeof(configParam_t); i++) ck += p[i];
    ck -= d->cksum;
    return ck;
}

void configParamInit(void) {
    if (s_init) return;
    memcpy(&configParam, &configParamDefault, sizeof(configParam));
    configParam.cksum = configParamCksum(&configParam);
    s_sem  = xSemaphoreCreateBinary();
    s_init = true;
    Serial.printf("[CONFIG] V%1.1f OK (RAM)\r\n", configParam.version / 10.0f);
}

bool configParamTest(void) { return s_init; }

/* configParamTask: 等待信号量 → 校验 → 保存 (对应原始 configParamTask) */
void configParamTask(void* param) {
    while (1) {
        xSemaphoreTake(s_sem, portMAX_DELAY);
        uint8_t ck = configParamCksum(&configParam);
        if (configParam.cksum != ck) {
            configParam.cksum = ck;
            /* V17: 打印移除 — 避免文本混入ANO协议流 */
        }
    }
}

void configParamGiveSemaphore(void) { if (s_sem) xSemaphoreGive(s_sem); }

void resetConfigParamPID(void) {
    configParam.pidAngle = configParamDefault.pidAngle;
    configParam.pidRate  = configParamDefault.pidRate;
    configParam.pidPos   = configParamDefault.pidPos;
}

void saveConfigAndNotify(void) {
    uint8_t ck = configParamCksum(&configParam);
    if (configParam.cksum != ck) configParam.cksum = ck;
    configParamGiveSemaphore();
}