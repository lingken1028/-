/**
 * @file    bmp280.cpp
 * @brief   BMP280 原生 I2C 驱动实现
 *
 * 补偿算法来自 BMP280 datasheet Section 4.2.3 (Float version)
 *   温度补偿 → t_fine → 气压补偿
 *   海拔: 44330 * (1 - (P/P0)^0.1903), P0=1013.25 hPa
 *
 * 校准数据: 24字节从 0x88 读取
 *   dig_T1 (uint16): 0x88/0x89
 *   dig_T2 (int16):  0x8A/0x8B
 *   dig_T3 (int16):  0x8C/0x8D
 *   dig_P1 (uint16): 0x8E/0x8F
 *   dig_P2..P9 (int16): 0x90..0x9F
 */
#include "bmp280.h"
#include "i2cdev.h"
#include <math.h>
#include <string.h>
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>

/* 校准数据 */
static uint16_t dig_T1;
static int16_t  dig_T2, dig_T3;
static uint16_t dig_P1;
static int16_t  dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;
static int32_t  t_fine;

static I2C_Dev* s_dev    = NULL;
static bool     s_isInit = false;
static uint8_t  s_addr   = 0;      /* V22.2: 实际响应的地址 0x76/0x77, 0=未找到 */

/** 读校准数据 (24字节, 0x88起始) */
static bool readCalib(void) {
    uint8_t buf[24];
    if (!i2cdevRead(s_dev, s_addr, BMP280_REG_CALIB, 24, buf)) return false;
    dig_T1 = (uint16_t)(buf[1]  << 8 | buf[0]);
    dig_T2 = (int16_t) (buf[3]  << 8 | buf[2]);
    dig_T3 = (int16_t) (buf[5]  << 8 | buf[4]);
    dig_P1 = (uint16_t)(buf[7]  << 8 | buf[6]);
    dig_P2 = (int16_t) (buf[9]  << 8 | buf[8]);
    dig_P3 = (int16_t) (buf[11] << 8 | buf[10]);
    dig_P4 = (int16_t) (buf[13] << 8 | buf[12]);
    dig_P5 = (int16_t) (buf[15] << 8 | buf[14]);
    dig_P6 = (int16_t) (buf[17] << 8 | buf[16]);
    dig_P7 = (int16_t) (buf[19] << 8 | buf[18]);
    dig_P8 = (int16_t) (buf[21] << 8 | buf[20]);
    dig_P9 = (int16_t) (buf[23] << 8 | buf[22]);
    return true;
}

/** 温度补偿 (BMP280 datasheet 4.2.3 float) → 副产品 t_fine */
static float compensateTemp(int32_t adc_T) {
    float v1 = (float)adc_T / 16384.0f - (float)dig_T1 / 1024.0f;
    float v2 = (float)adc_T / 131072.0f - (float)dig_T1 / 8192.0f;
    v1 *= (float)dig_T2;
    v2  = v2 * v2 * (float)dig_T3;
    t_fine = (int32_t)(v1 + v2);
    return (v1 + v2) / 5120.0f;
}

/** 气压补偿 (BMP280 datasheet 4.2.3 float) → Pa */
static float compensatePress(int32_t adc_P) {
    float v1 = (float)t_fine / 2.0f - 64000.0f;
    float v2 = v1 * v1 * (float)dig_P6 / 32768.0f
             + v1 * (float)dig_P5 * 2.0f;
    v2 = v2 / 4.0f + (float)dig_P4 * 65536.0f;
    v1 = ((float)dig_P3 * v1 * v1 / 524288.0f
        + (float)dig_P2 * v1) / 524288.0f;
    v1 = (1.0f + v1 / 32768.0f) * (float)dig_P1;
    if (v1 == 0.0f) return 0.0f;
    float p = 1048576.0f - (float)adc_P;
    p = (p - v2 / 4096.0f) * 6250.0f / v1;
    v1 = (float)dig_P9 * p * p / 2147483648.0f;
    v2 = p * (float)dig_P8 / 32768.0f;
    p += (v1 + v2 + (float)dig_P7) / 16.0f;
    return p;  /* Pa */
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】bmp280Init — 气压计上线三部曲
 *   这段做了什么: ① 双地址探测 0x76/0x77(GY-91 不同批次 SDO 接法不同)
 *   ×6轮重试(V22.35: BMP280 上电就绪比 MPU 慢, 一次探不到≠没有);
 *   ② 软复位 → 读 24 字节出厂校准系数(补偿公式的原料);
 *   ③ 写 CONFIG/CTRL_MEAS 进 Normal 连续测量。读数经 datasheet 4.2.3
 *   浮点补偿(温度→t_fine→气压), 海拔 = 44330×(1−(P/1013.25)^0.1903)。
 * ══════════════════════════════════════════════════════════════ */
void bmp280Init(I2C_Dev* dev) {
    s_dev    = dev;
    s_isInit = false;
    s_addr   = 0;

    /* V22.2: GY-91 上 BMP280 的 SDO 可能接 GND(0x76) 或 VCC(0x77),
     * 不同批次不一样。两个地址都探一下, 谁回 chip_id=0x58/0x60 用谁。
     * (0x58=BMP280, 0x60=BME280; GY-91 一般是 BMP280) */
    static const uint8_t cand[2] = { 0x76, 0x77 };
    /* V22.35: 重试探测 — BMP280 上电就绪比 MPU 慢 / 总线上电瞬间可能未稳,
     *   一次探测失败会导致 baro=N。多探几次(各 15ms)显著提高检出率。 */
    for (int retry = 0; retry < 6 && s_addr == 0; retry++) {
        for (int i = 0; i < 2; i++) {
            uint8_t id = 0;
            if (i2cdevReadByte(s_dev, cand[i], BMP280_REG_CHIP_ID, &id) &&
                (id == 0x58 || id == 0x60)) {
                s_addr = cand[i];
                break;
            }
        }
        if (s_addr == 0) vTaskDelay(pdMS_TO_TICKS(15));
    }
    if (s_addr == 0) return;          /* 没有气压计 (例如没插 GY-91 / BMP280 失联) */

    /* 软复位 */
    i2cdevWriteByte(s_dev, s_addr, BMP280_REG_RESET, 0xB6);
    vTaskDelay(pdMS_TO_TICKS(5));
    if (!readCalib()) { s_addr = 0; return; }
    i2cdevWriteByte(s_dev, s_addr, BMP280_REG_CONFIG,    BMP280_CONFIG_VAL);
    i2cdevWriteByte(s_dev, s_addr, BMP280_REG_CTRL_MEAS, BMP280_CTRL_MEAS_VAL);
    vTaskDelay(pdMS_TO_TICKS(3));
    s_isInit = true;
}

bool bmp280IsPresent(void) {
    return s_isInit && s_addr != 0;   /* V22.2: 用探测结果, 不再每次重读 */
}

/* V22.45: 周期性重置模式 — GY-91 热插拔/电源毛刺会让 BMP280 掉电复位回 sleep(默认态),
 *   而 bmp280Init 只在开机跑一次 → 复位后停在 sleep, 数据冻结(读到的全是同一个复位值)。
 *   重写 CONFIG + CTRL_MEAS 即可恢复 Normal 连续转换。
 *   校准系数(dig_T/P)存在 BMP280 的 OTP 里(掉电不丢, 上电自动重载), 故无需重读校准。 */
void bmp280EnsureMode(void) {
    if (s_addr == 0) return;
    i2cdevWriteByte(s_dev, s_addr, BMP280_REG_CONFIG,    BMP280_CONFIG_VAL);
    i2cdevWriteByte(s_dev, s_addr, BMP280_REG_CTRL_MEAS, BMP280_CTRL_MEAS_VAL);
}

/**
 * bmp280Read — 读取温度和气压
 * @param press_hPa  输出气压 hPa (100 Pa)
 * @param temp_C     输出温度 °C
 */
bool bmp280Read(float* press_hPa, float* temp_C) {
    if (!s_isInit) return false;
    uint8_t buf[6];
    /* 一次读 press(3字节) + temp(3字节) 从 0xF7 */
    if (!i2cdevRead(s_dev, s_addr, BMP280_REG_PRESS_MSB, 6, buf))
        return false;
    int32_t adc_P = ((int32_t)buf[0] << 12) | ((int32_t)buf[1] << 4) | (buf[2] >> 4);
    int32_t adc_T = ((int32_t)buf[3] << 12) | ((int32_t)buf[4] << 4) | (buf[5] >> 4);
    *temp_C    = compensateTemp(adc_T);
    float pa   = compensatePress(adc_P);
    *press_hPa = pa / 100.0f;          /* Pa → hPa */
    return true;
}

/**
 * bmp280GetAltitude — 气压转海拔 (ISA 气压公式)
 * 对应 Adafruit_BMP280::readAltitude(1013.25)
 */
float bmp280GetAltitude(float press_hPa) {
    /* 44330 * (1 - (P/P0)^(1/5.255)) */
    if (!(press_hPa > 0.0f)) return 0.0f;   /* V22.38: 防 powf(负/NaN)→NaN (刚上电未就绪会出负压) */
    return 44330.0f * (1.0f - powf(press_hPa / 1013.25f, 0.1903f));
}