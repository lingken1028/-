/**
 * @file    ak8963.h
 * @brief   AK8963 三轴磁力计驱动
 *          对应: HARDWARE/interface/ak8963.h (逐字对照)
 *
 * GY-91 模块访问方式:
 *   MPU-9250 内置 AK8963，通过 MPU-9250 辅助 I2C 连接。
 *   访问前提: 先令 MPU-9250 进入 I2C bypass 模式
 *             写 INT_PIN_CFG (0x37) |= 0x02
 *   然后在同一 I2C 总线 (WireGY91) 直接访问 AK8963 @ 0x0C。
 *
 * 原固件初始化 (sensorsDeviceInit):
 *   ak8963Init(I2C1_DEV)
 *   ak8963TestConnection() → WIA == 0x48
 *   ak8963SetMode(AK8963_MODE_16BIT | AK8963_MODE_CONT2)  → 16bit 100Hz
 *
 * 量程: MAG_GAUSS_PER_LSB = 666.7 (对应 0.15 µT/LSB = 1/6667 Gauss/LSB)
 * 寄存器: HXL(0x03) ~ HZH(0x08) 6字节, 小端序
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "../hardware/i2cdev.h"

/* 地址 (对应原始固件 AK8963_ADDRESS_00 = 0x0C) */
#define AK8963_ADDR             0x0C
#define AK8963_DEFAULT_ADDRESS  AK8963_ADDR

/* 寄存器 (对应原始固件 ak8963.h 全部定义) */
#define AK8963_RA_WIA    0x00   /* Device ID = 0x48 */
#define AK8963_RA_INFO   0x01
#define AK8963_RA_ST1    0x02   /* Data status 1: bit0=DRDY */
#define AK8963_RA_HXL    0x03
#define AK8963_RA_HXH    0x04
#define AK8963_RA_HYL    0x05
#define AK8963_RA_HYH    0x06
#define AK8963_RA_HZL    0x07
#define AK8963_RA_HZH    0x08
#define AK8963_RA_ST2    0x09   /* Data status 2: bit3=HOFL */
#define AK8963_RA_CNTL   0x0A   /* 控制寄存器 */
#define AK8963_RA_ASTC   0x0C   /* Self-test */
#define AK8963_RA_ASAX   0x10   /* X轴灵敏度调整 (Fuse ROM) */
#define AK8963_RA_ASAY   0x11
#define AK8963_RA_ASAZ   0x12

/* 测量模式 (对应原始固件宏) */
#define AK8963_MODE_POWERDOWN 0x00
#define AK8963_MODE_SINGLE    0x01
#define AK8963_MODE_CONT1     0x02   /* 8Hz 连续测量 */
#define AK8963_MODE_CONT2     0x06   /* 100Hz 连续测量 */
#define AK8963_MODE_14BIT     0x00
#define AK8963_MODE_16BIT     0x10   /* 16-bit 输出 */

/* 量程 (对应原始固件 MAG_GAUSS_PER_LSB) */
#define MAG_GAUSS_PER_LSB  666.7f   /* 16-bit 模式: 0.15 µT/LSB → 1/6667 Gauss/LSB */

void  ak8963Init(I2C_Dev* dev);
bool  ak8963TestConnection(void);
void  ak8963SetMode(uint8_t mode);
bool  ak8963GetDataReady(void);
void  ak8963GetHeading(int16_t* x, int16_t* y, int16_t* z);
bool  ak8963GetOverflowStatus(void);