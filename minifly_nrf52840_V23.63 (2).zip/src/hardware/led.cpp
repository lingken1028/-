/**
 * @file    led.cpp
 * @brief   LED 驱动 (V16: 增加外部 D6 LED)
 * 板载 active-LOW; D6 active-HIGH 跟随 SYS_LED/CHG_LED
 */
#include "led.h"
#include "../config.h"
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>

#if !defined(LED_RED)
  #if defined(LEDR)
    #define LED_RED    LEDR
    #define LED_GREEN  LEDG
    #define LED_BLUE   LEDB
  #else
    #define LED_RED    LED_BUILTIN
    #define LED_GREEN  LED_BUILTIN
    #define LED_BLUE   LED_BUILTIN
  #endif
#endif

static const int s_pins[LED_NUM] = {
    [LED_BLUE_L]  = LED_BLUE,
    [LED_GREEN_L] = LED_GREEN,
    [LED_RED_L]   = LED_RED,
    [LED_GREEN_R] = LED_GREEN,
    [LED_RED_R]   = LED_RED,
};

static bool s_isInit = false;

void ledInit(void) {
    if (s_isInit) return;
    pinMode(LED_RED,     OUTPUT); digitalWrite(LED_RED,     HIGH);
    pinMode(LED_GREEN,   OUTPUT); digitalWrite(LED_GREEN,   HIGH);
    pinMode(LED_BLUE,    OUTPUT); digitalWrite(LED_BLUE,    HIGH);
    pinMode(EXT_LED_PIN, OUTPUT); digitalWrite(EXT_LED_PIN, LOW);
    s_isInit = true;
}

bool ledTest(void) {
    ledSet(LED_GREEN_L, 1); ledSet(LED_GREEN_R, 1);
    vTaskDelay(pdMS_TO_TICKS(250));
    ledSet(LED_GREEN_L, 0); ledSet(LED_GREEN_R, 0);
    ledSet(LED_RED_L,   1); ledSet(LED_RED_R,   1);
    vTaskDelay(pdMS_TO_TICKS(250));
    ledClearAll();
    ledSet(LED_BLUE_L, 1);
    return s_isInit;
}

void ledClearAll(void) { for (int i=0;i<LED_NUM;i++) ledSet((led_e)i, 0); }
void ledSetAll(void)   { for (int i=0;i<LED_NUM;i++) ledSet((led_e)i, 1); }

void ledSet(led_e led, bool value) {
    if (!s_isInit || led >= LED_NUM) return;
    digitalWrite(s_pins[led], value ? LOW : HIGH);       /* 板载 active-LOW */
    if (led == LED_GREEN_R || led == LED_BLUE_L)
        digitalWrite(EXT_LED_PIN, value ? HIGH : LOW);   /* D6 active-HIGH */
}

void ledFlashOne(led_e led, uint32_t onTime, uint32_t offTime) {
    ledSet(led, 1);
    vTaskDelay(pdMS_TO_TICKS(onTime));
    ledSet(led, 0);
    vTaskDelay(pdMS_TO_TICKS(offTime));
}