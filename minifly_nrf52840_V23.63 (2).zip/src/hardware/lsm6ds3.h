/**
 * @file    lsm6ds3.h
 * @brief   XIAO nRF52840 Sense 板载 LSM6DS3TR-C 6轴 IMU 驱动 (V22 新增)
 *
 * ══ 为什么不用 Adafruit_LSM6DS / Wire1 ══
 *   旧版降级路径 s_lsm.begin_I2C(0x6A, &Wire1) 有两个隐患:
 *     1. 板载 IMU 的供电脚 P1.08 从未拉高 → 芯片根本没电, 必然探测失败
 *     2. Wire1 是否映射到内部 IMU 总线取决于 BSP 变体, 不可控
 *   V22 改为: 自己控制 P1.08 供电 + i2cdev(TWIM1, P0.27/P0.07) 寄存器直驱,
 *   与 GY-91 路径同一套 I2C 代码, 行为完全确定。
 *
 * ══ 硬件事实 (Seeed 原理图) ══
 *   电源:  P1.08 → LSM6DS3TR-C VDD (总线上拉电阻也挂在该电源轨上)
 *   总线:  SCL = P0.27, SDA = P0.07  (与 D4/D5 外部 I2C 相互独立)
 *   中断:  INT1 = P0.11 (本工程不用)
 *   地址:  0x6A (WHO_AM_I=0x6A; 老款 LSM6DS3 为 0x69)
 *
 * ══ 配置 (对照 GY-91/MPU9250 同量程) ══
 *   加速度: ±16g  @ 833Hz   →  0.488 mg/LSB
 *   陀螺:   ±2000dps @ 833Hz →  70 mdps/LSB
 *   数据顺序: OUTX_L_G(0x22) 起连续 12 字节 = 陀螺XYZ + 加速XYZ, 小端!
 *   (注意与 MPU9250 相反: MPU 是 加速→温度→陀螺, 大端)
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "i2cdev.h"

/* 寄存器 */
#define LSM6DS3_REG_WHO_AM_I   0x0F   /* TR-C: 0x6A, 老款: 0x69 */
#define LSM6DS3_REG_CTRL1_XL   0x10
#define LSM6DS3_REG_CTRL2_G    0x11
#define LSM6DS3_REG_CTRL3_C    0x12
#define LSM6DS3_REG_OUTX_L_G   0x22   /* 陀螺X低字节, 起始连读12字节 */

/* 配置值 */
#define LSM6DS3_CTRL3_SWRESET  0x01   /* 软复位 */
#define LSM6DS3_CTRL3_BDU_INC  0x44   /* BDU=1 + IF_INC=1 */
#define LSM6DS3_CTRL1_833_16G  0x74   /* ODR=833Hz, FS=±16g  */
#define LSM6DS3_CTRL2_833_2K   0x7C   /* ODR=833Hz, FS=±2000dps */
#define LSM6DS3_CTRL1_416_16G  0x64   /* V22.85: ODR=416Hz, FS=±16g (降ODR防混叠, 缩放不变) */
#define LSM6DS3_CTRL2_416_2K   0x6C   /* V22.85: ODR=416Hz, FS=±2000dps */

/* ── V23.36 D43 落实: ODR 的 Hz 孪生值 + 编译期奈奎斯特守卫 ──
 * 改用哪组 CTRL 宏, 就把下面 LSM6_SELECTED_ODR_HZ 改成对应 Hz。
 * lsm6ds3.cpp 里的 static_assert 会强制它 <= 任务读取率, 改超即编译报错。 */
#define LSM6_ODR_HZ_833   833
#define LSM6_ODR_HZ_416   416
#define LSM6_SELECTED_ODR_HZ   LSM6_ODR_HZ_416   /* 当前选用 416Hz(配 CTRL1_416/CTRL2_416) */
#define LSM6_TASK_READ_RATE_HZ 500   /* = sensors.h SENSOR9_UPDATE_RATE(sensorsTask 2ms周期)。改任务周期时两处同步! */

/* 量程换算 */
#define LSM6DS3_DEG_PER_LSB_2000   0.070f      /* 2000dps: 70 mdps/LSB */
#define LSM6DS3_G_PER_LSB_16       0.000488f   /* 16g: 0.488 mg/LSB    */

/* 上电 + 探测 + 配置; 成功返回 true (之后才可调用 lsm6ds3Read) */
bool lsm6ds3Init(void);
/* 是否探测成功 */
bool lsm6ds3IsPresent(void);
/* 实际响应的 I2C 地址 (0x6A/0x6B), 探测失败为 0 */
uint8_t lsm6ds3GetAddr(void);
/* WHO_AM_I 值 (诊断用) */
uint8_t lsm6ds3GetWhoAmI(void);
/* 读取原始数据: acc[3]/gyro[3], 失败返回 false */
bool lsm6ds3Read(int16_t acc[3], int16_t gyro[3]);
