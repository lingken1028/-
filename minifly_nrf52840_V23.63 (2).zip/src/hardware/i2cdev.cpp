/**
 * @file    i2cdev.cpp
 * @brief   I2C — 真实 TWIM0/TWIM1 寄存器轮询驱动 (V22)
 *
 * ══ V22 关键修复 ══
 *   旧版地址 0x40022000 ("NRF_TWIM2") 实际是 NRF_PWM2 —
 *   nRF52840 没有 TWIM2 外设! 改用真实 TWIM0/TWIM1。
 *
 * ══ 设计 ══
 *   · 轮询 + 有限超时 (~几 ms)，无 ISR，不依赖 BSP g_ADigitalPinMap
 *   · 每条总线一个 FreeRTOS mutex → 多任务安全
 *   · SCL/SDA 内部上拉 + S0D1 开漏 → 总线无外设/无上拉也不会卡死
 *   · 出错/超时统一走 RESUME→STOP 恢复序列, 再失败则重新初始化外设
 *
 * 引脚 (config.h):
 *   I2C1_DEV    (TWIM0): SCL=D8 (P1.13)  SDA=D10 (P1.15)  → GY-91
 *   I2C_INT_DEV (TWIM1): SCL=P0.27       SDA=P0.07        → LSM6DS3TR-C
 */
#include "i2cdev.h"
#include "../config.h"
#include <string.h>

/* ── 总线实例 ── */
static I2C_Dev s_busGY91 = {
    NRF_TWIM0,
    GY91_SCL_PORT, GY91_SCL_PIN,
    GY91_SDA_PORT, GY91_SDA_PIN,
    NULL, false, {0}
};
static I2C_Dev s_busInt = {
    NRF_TWIM1,
    IMU_INT_SCL_PORT, IMU_INT_SCL_PIN,
    IMU_INT_SDA_PORT, IMU_INT_SDA_PIN,
    NULL, false, {0}
};
I2C_Dev* I2C1_DEV    = &s_busGY91;
I2C_Dev* I2C_INT_DEV = &s_busInt;

/* 轮询超时: 400kHz 下最长事务(~25字节)约 0.6ms ≈ 数千次循环
 * 200000 次 ≈ 数 ms, 远大于正常事务, 又不会像旧版空转 100ms+ */
#define TWIM_TIMEOUT_LOOPS   200000UL
#define TWIM_STOP_LOOPS      20000UL

static inline NRF_GPIO_Type* portReg(uint8_t port) {
    return (port == 1) ? NRF_P1 : NRF_P0;
}

static void i2cPinCfg(uint8_t port, uint8_t pin) {
    portReg(port)->PIN_CNF[pin] =
        (GPIO_PIN_CNF_DIR_Input      << GPIO_PIN_CNF_DIR_Pos)   |
        (GPIO_PIN_CNF_INPUT_Connect  << GPIO_PIN_CNF_INPUT_Pos) |
        (GPIO_PIN_CNF_PULL_Pullup    << GPIO_PIN_CNF_PULL_Pos)  |
        (GPIO_PIN_CNF_DRIVE_S0D1     << GPIO_PIN_CNF_DRIVE_Pos) |
        (GPIO_PIN_CNF_SENSE_Disabled << GPIO_PIN_CNF_SENSE_Pos);
}

static void twimHwSetup(I2C_Dev* dev) {
    NRF_TWIM_Type* t = dev->twim;

    i2cPinCfg(dev->sclPort, dev->sclPin);
    i2cPinCfg(dev->sdaPort, dev->sdaPin);

    t->ENABLE   = TWIM_ENABLE_ENABLE_Disabled;
    t->INTENCLR = 0xFFFFFFFFUL;                 /* 纯轮询, 不用中断 */
    t->PSEL.SCL = ((uint32_t)dev->sclPort << 5) | dev->sclPin;
    t->PSEL.SDA = ((uint32_t)dev->sdaPort << 5) | dev->sdaPin;
    t->FREQUENCY = TWIM_FREQUENCY_FREQUENCY_K400;
    t->SHORTS   = 0;

    t->EVENTS_STOPPED   = 0;
    t->EVENTS_ERROR     = 0;
    t->EVENTS_SUSPENDED = 0;
    t->EVENTS_RXSTARTED = 0;
    t->EVENTS_TXSTARTED = 0;
    t->EVENTS_LASTRX    = 0;
    t->EVENTS_LASTTX    = 0;
    t->ERRORSRC = t->ERRORSRC;                  /* W1C 清错误源 */

    t->ENABLE = TWIM_ENABLE_ENABLE_Enabled;
}

/* 等待事务结束; 出错/超时时执行 RESUME→STOP 恢复 */
static bool twimWait(I2C_Dev* dev) {
    NRF_TWIM_Type* t = dev->twim;
    uint32_t n = TWIM_TIMEOUT_LOOPS;
    bool ok = false, timedOut = true;

    while (n--) {
        if (t->EVENTS_STOPPED) { ok = true; timedOut = false; break; }
        if (t->EVENTS_ERROR)   { ok = false; timedOut = false; break; }
    }

    if (!ok) {
        /* NACK/总线异常/超时 → 标准恢复: RESUME + STOP, 等待 STOPPED */
        t->EVENTS_ERROR = 0;
        t->ERRORSRC     = t->ERRORSRC;
        t->TASKS_RESUME = 1;
        t->TASKS_STOP   = 1;
        uint32_t s = TWIM_STOP_LOOPS;
        while (s-- && !t->EVENTS_STOPPED) {}
        if (timedOut && !t->EVENTS_STOPPED) {
            twimHwSetup(dev);                   /* 彻底卡死 → 重启外设 */
        }
    }

    t->EVENTS_STOPPED = 0;
    t->SHORTS = 0;
    return ok;
}

bool i2cdevInit(I2C_Dev* dev) {
    if (!dev) return false;
    if (dev->isInit) return true;

    if (dev->mutex == NULL)
        dev->mutex = xSemaphoreCreateMutex();

    twimHwSetup(dev);
    dev->isInit = true;
    return true;
}

bool i2cdevRead(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr,
                uint16_t len, uint8_t* data) {
    if (!dev || !dev->isInit || len == 0 || len > 255 || data == NULL) return false;

    if (dev->mutex) xSemaphoreTake(dev->mutex, portMAX_DELAY);

    NRF_TWIM_Type* t = dev->twim;
    dev->txBuf[0] = memAddr;

    t->ADDRESS    = devAddr;
    t->TXD.PTR    = (uint32_t)(uintptr_t)dev->txBuf;       /* EasyDMA: 必须是 RAM */
    t->TXD.MAXCNT = 1;
    t->RXD.PTR    = (uint32_t)(uintptr_t)data;
    t->RXD.MAXCNT = len;
    t->SHORTS     = TWIM_SHORTS_LASTTX_STARTRX_Msk | TWIM_SHORTS_LASTRX_STOP_Msk;
    t->EVENTS_STOPPED = 0;
    t->EVENTS_ERROR   = 0;
    t->TASKS_STARTTX  = 1;

    bool ok = twimWait(dev);
    if (ok) ok = (t->RXD.AMOUNT == len);

    if (dev->mutex) xSemaphoreGive(dev->mutex);
    return ok;
}

bool i2cdevWrite(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr,
                 uint16_t len, uint8_t* data) {
    if (!dev || !dev->isInit || len == 0 || len > 63 || data == NULL) return false;

    if (dev->mutex) xSemaphoreTake(dev->mutex, portMAX_DELAY);

    NRF_TWIM_Type* t = dev->twim;
    dev->txBuf[0] = memAddr;
    memcpy(&dev->txBuf[1], data, len);

    t->ADDRESS    = devAddr;
    t->TXD.PTR    = (uint32_t)(uintptr_t)dev->txBuf;
    t->TXD.MAXCNT = (uint32_t)len + 1;
    t->SHORTS     = TWIM_SHORTS_LASTTX_STOP_Msk;
    t->EVENTS_STOPPED = 0;
    t->EVENTS_ERROR   = 0;
    t->TASKS_STARTTX  = 1;

    bool ok = twimWait(dev);
    if (ok) ok = (t->TXD.AMOUNT == (uint32_t)len + 1);

    if (dev->mutex) xSemaphoreGive(dev->mutex);
    return ok;
}

bool i2cdevReadByte(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t* data) {
    return i2cdevRead(dev, devAddr, memAddr, 1, data);
}
bool i2cdevWriteByte(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t data) {
    return i2cdevWrite(dev, devAddr, memAddr, 1, &data);
}

bool i2cdevReadBit(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr,
                   uint8_t bitNum, uint8_t* data) {
    uint8_t b = 0;
    if (!i2cdevReadByte(dev, devAddr, memAddr, &b)) return false;
    *data = (b >> bitNum) & 0x01;
    return true;
}
bool i2cdevWriteBit(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr,
                    uint8_t bitNum, uint8_t data) {
    uint8_t b = 0;
    if (!i2cdevReadByte(dev, devAddr, memAddr, &b)) return false;
    b = data ? (b | (1u << bitNum)) : (b & ~(1u << bitNum));
    return i2cdevWriteByte(dev, devAddr, memAddr, b);
}
bool i2cdevReadBits(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr,
                    uint8_t bitStart, uint8_t length, uint8_t* data) {
    uint8_t b = 0;
    if (!i2cdevReadByte(dev, devAddr, memAddr, &b)) return false;
    uint8_t mask = ((1u << length) - 1u) << (bitStart - length + 1);
    *data = (b & mask) >> (bitStart - length + 1);
    return true;
}
bool i2cdevWriteBits(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr,
                     uint8_t bitStart, uint8_t length, uint8_t data) {
    uint8_t b = 0;
    if (!i2cdevReadByte(dev, devAddr, memAddr, &b)) return false;
    uint8_t mask = ((1u << length) - 1u) << (bitStart - length + 1);
    b = (b & ~mask) | ((data << (bitStart - length + 1)) & mask);
    return i2cdevWriteByte(dev, devAddr, memAddr, b);
}
