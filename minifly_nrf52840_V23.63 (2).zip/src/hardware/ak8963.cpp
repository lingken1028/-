/**
 * @file    ak8963.cpp
 * @brief   AK8963 磁力计驱动实现
 *          对应: HARDWARE/src/ak8963.c
 *
 * ══ GY-91 AK8963 初始化完整步骤 ══
 *   1. MPU-9250 已配置并工作
 *   2. MPU-9250 INT_PIN_CFG (0x37) |= 0x02  (bypass enable, 已在 sensors.cpp 中写入)
 *   3. WireGY91.begin() 已在 i2cdev.cpp 中完成
 *   4. ak8963Init(I2C1_DEV)  → 设置 devAddr = 0x0C
 *   5. ak8963TestConnection() → 读 WIA(0x00) 期望 0x48
 *   6. ak8963SetMode(0x16)   → 16-bit + 100Hz 连续测量
 *
 * ══ 数据读取 ══
 *   sensorsAcquire 每 20 tick (50Hz) 调用一次:
 *   1. 检查 ST1 (0x02) bit0 DRDY
 *   2. 读 HXL(0x03) 连续 6 字节 (HXL,HXH,HYL,HYH,HZL,HZH)
 *   3. 小端序组合: X = (HXH<<8) | HXL
 *   4. 转换: float_gauss = raw / MAG_GAUSS_PER_LSB
 *      (对应原始固件 sensors.c processMagnetometerMeasurements)
 */
#include "ak8963.h"
#include "i2cdev.h"
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>

static uint8_t s_devAddr = AK8963_ADDR;
static I2C_Dev* s_i2c    = NULL;
static bool     s_isInit  = false;
static uint8_t  s_buf[6];

void ak8963Init(I2C_Dev* dev) {
    if (s_isInit) return;
    s_i2c    = dev;
    s_devAddr = AK8963_ADDR;
    s_isInit  = true;
}

/**
 * @brief  ak8963TestConnection — 对应原始 ak8963TestConnection()
 *         读取 WIA 寄存器，期望 0x48
 */
bool ak8963TestConnection(void) {
    uint8_t wia = 0;
    if (!i2cdevReadByte(s_i2c, s_devAddr, AK8963_RA_WIA, &wia)) return false;
    return (wia == 0x48);
}

/**
 * @brief  ak8963SetMode — 对应原始 ak8963SetMode(u8 mode)
 *         写 CNTL(0x0A) 寄存器
 *         注: 从任意模式切换到新模式，需先进入 PowerDown 再设置
 *         (原始固件在 sensorsDeviceInit 直接写 AK8963_MODE_16BIT | AK8963_MODE_CONT2)
 */
void ak8963SetMode(uint8_t mode) {
    i2cdevWriteByte(s_i2c, s_devAddr, AK8963_RA_CNTL, mode);
    vTaskDelay(pdMS_TO_TICKS(1));
}

/**
 * @brief  ak8963GetDataReady — 对应原始 ak8963GetDataReady()
 *         读取 ST1(0x02) bit0 DRDY
 */
bool ak8963GetDataReady(void) {
    uint8_t st1 = 0;
    i2cdevReadBit(s_i2c, s_devAddr, AK8963_RA_ST1, 0, &st1);
    return (st1 != 0);
}

/**
 * @brief  ak8963GetHeading — 对应原始 ak8963GetHeading(s16*, s16*, s16*)
 *         读 HXL(0x03) 连续 6 字节，小端序组合
 *         必须读完 ST2 以清除 DRDY 标志 (否则不产生下次中断)
 */
void ak8963GetHeading(int16_t* x, int16_t* y, int16_t* z) {
    if (!i2cdevRead(s_i2c, s_devAddr, AK8963_RA_HXL, 6, s_buf)) {
        *x = *y = *z = 0; return;
    }
    *x = (int16_t)((s_buf[1] << 8) | s_buf[0]);
    *y = (int16_t)((s_buf[3] << 8) | s_buf[2]);
    *z = (int16_t)((s_buf[5] << 8) | s_buf[4]);
    /* 读 ST2 清除 DRDY (连续模式必须) */
    uint8_t st2;
    i2cdevReadByte(s_i2c, s_devAddr, AK8963_RA_ST2, &st2);
}

bool ak8963GetOverflowStatus(void) {
    uint8_t st2 = 0;
    i2cdevReadBit(s_i2c, s_devAddr, AK8963_RA_ST2, 3, &st2);
    return (st2 != 0);
}