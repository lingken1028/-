/**
 * @file    motors.cpp
 * @brief   电机驱动实现
 *          对应: HARDWARE/src/motors.c
 *
 * V7 修正:
 *   isExitFlip 现在在 flip.cpp 中定义, motors.cpp 只 extern 声明
 *   (原始固件: isExitFlip 在 flip.c 定义, motors.c 用 extern bool isExitFlip)
 */
#include "motors.h"
#include "../config.h"
#include "../communicate/pm.h"
#include <Arduino.h>

static bool   s_isInit = false;
uint32_t      motor_ratios[NBR_OF_MOTORS] = {0,0,0,0};

/* 对应原始 motors.c: extern bool isExitFlip (在 flip.c 定义) */
extern bool isExitFlip;

static const uint8_t MOTOR_PINS[NBR_OF_MOTORS] = {
    MOTOR1_PIN, MOTOR2_PIN, MOTOR3_PIN, MOTOR4_PIN
};

static inline uint8_t ratioToCCRx(uint16_t val) {
    return (uint8_t)((val >> (16 - MOTORS_PWM_BITS)) & ((1 << MOTORS_PWM_BITS) - 1));
}

void motorsInit(void) {
    if (s_isInit) return;
#if MOTOR_HIGHFREQ_PWM
    /* V22.18: 高频 PWM —— 用 nRF52 HardwarePWM(HwPWM0) 把四路电机 PWM 拉到
     * 16MHz / 256 = 62.5kHz (原版 F411 是 375kHz, nRF52 PWM 时钟仅 16MHz 故为上限),
     * 远高于 ~1kHz 的 analogWrite。无刷芯/有刷电机电感能平滑电流, 关断期不再大量
     * 经续流二极管泄放 → 有效动能接近原版, 无可闻啸叫。占空比分辨率仍 8 位(0~255)。 */
    for (int i=0;i<NBR_OF_MOTORS;i++) pinMode(MOTOR_PINS[i], OUTPUT);
    HwPWM0.addPin(MOTOR_PINS[0]);
    HwPWM0.addPin(MOTOR_PINS[1]);
    HwPWM0.addPin(MOTOR_PINS[2]);
    HwPWM0.addPin(MOTOR_PINS[3]);
    HwPWM0.setClockDiv(PWM_PRESCALER_PRESCALER_DIV_1);     /* 16 MHz */
    HwPWM0.setMaxValue((uint16_t)(1u << MOTORS_PWM_BITS)); /* 256 → 62.5kHz */
    for (int i=0;i<NBR_OF_MOTORS;i++) HwPWM0.writePin(MOTOR_PINS[i], 0, false);
#else
    /* V22.3 回退: analogWrite 8 位(约 1kHz)。已知能转, HwPWM 出问题时用本路。 */
    analogWriteResolution(MOTORS_PWM_BITS);   /* =8 */
    for (int i=0;i<NBR_OF_MOTORS;i++) { pinMode(MOTOR_PINS[i],OUTPUT); analogWrite(MOTOR_PINS[i],0); }
#endif
    s_isInit = true;
}

bool motorsTest(void) {
    for (int i=0;i<NBR_OF_MOTORS;i++) {
        motorsSetRatio(i, MOTORS_TEST_RATIO);
        delay(MOTORS_TEST_ON_TIME_MS);
        motorsSetRatio(i, 0);
        delay(MOTORS_TEST_DELAY_TIME_MS);
    }
    return s_isInit;
}

void motorsSetRatio(uint32_t id, uint16_t ithrust) {
    if (!s_isInit || id>=NBR_OF_MOTORS) return;
    uint16_t ratio = ithrust;
    motor_ratios[id] = ratio;   /* V23.21: 无条件记录真实ratio(原来只在ENABLE_THRUST_BAT_COMPENSATED且isExitFlip时更新→数组永久停在{0,0,0,0}, 读它的诊断全拿到假零) */
#ifdef ENABLE_THRUST_BAT_COMPENSATED
    if (isExitFlip) {
        float thrust     = ((float)ithrust/65536.0f)*60.0f;
        float volts      = -0.0006239f*thrust*thrust + 0.088f*thrust;
        float supply_voltage = pmGetBatteryVoltage();
        if (supply_voltage > 0.5f) {
            float pct = volts/supply_voltage;
            if (pct>1.0f) pct=1.0f;
            ratio = (uint16_t)(pct*65535.0f);
        }
        motor_ratios[id] = ratio;   /* 补偿路径覆盖后再刷新一次(值可能与上面不同) */
    }
#endif
#if MOTOR_HIGHFREQ_PWM
    HwPWM0.writePin(MOTOR_PINS[id], ratioToCCRx(ratio), false);
#else
    analogWrite(MOTOR_PINS[id], ratioToCCRx(ratio));
#endif
}