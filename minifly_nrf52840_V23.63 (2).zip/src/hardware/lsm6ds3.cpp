/**
 * @file    lsm6ds3.cpp
 * @brief   板载 LSM6DS3TR-C 驱动实现 (V22 新增)
 *
 * 上电时序:
 *   1. P1.08 配置为高驱动输出并拉高 (IMU VDD + 总线上拉都由它供电)
 *   2. 等待 ≥35ms (芯片 boot time 典型 15ms, 留裕量)
 *   3. TWIM1 初始化 (P0.27/P0.07)
 *   4. 读 WHO_AM_I, 期望 0x6A (TR-C) 或 0x69 (老款 LSM6DS3)
 *   5. 软复位 → BDU+地址自增 → 配置量程/ODR
 */
#include "lsm6ds3.h"
#include "../config.h"
#include <nrf.h>
#include <FreeRTOS.h>
#include <task.h>

static bool    s_present = false;
static uint8_t s_addr    = 0;
static uint8_t s_who     = 0;

/* P1.08 → IMU 电源 (高驱动: 需带动芯片 + 两颗 4.7k 上拉) */
static void imuPowerOn(void) {
    NRF_GPIO_Type* P = (IMU_INT_PWR_PORT == 1) ? NRF_P1 : NRF_P0;
    P->PIN_CNF[IMU_INT_PWR_PIN] =
        (GPIO_PIN_CNF_DIR_Output        << GPIO_PIN_CNF_DIR_Pos)   |
        (GPIO_PIN_CNF_INPUT_Disconnect  << GPIO_PIN_CNF_INPUT_Pos) |
        (GPIO_PIN_CNF_PULL_Disabled     << GPIO_PIN_CNF_PULL_Pos)  |
        (GPIO_PIN_CNF_DRIVE_H0H1        << GPIO_PIN_CNF_DRIVE_Pos) |
        (GPIO_PIN_CNF_SENSE_Disabled    << GPIO_PIN_CNF_SENSE_Pos);
    P->OUTSET = (1UL << IMU_INT_PWR_PIN);
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】lsm6ds3Init — 板载 IMU 上线(降级/双IMU共用)
 *   这段做了什么: ① P1.08 高驱动拉高 = 给芯片和总线上拉供电(硬件设计:
 *   IMU 电源由 GPIO 控) → 等50ms boot; ② TWIM1(独立总线, 与 GY-91 隔离);
 *   ③ 双地址×3重试探 WHO_AM_I; ④ 软复位 → BDU+自增;
 *   ⑤ 量程 ±16g/±2000dps @ 【416Hz】— V22.85 采样定理修复: 原833Hz陀螺
 *   无硬件低通, 被500Hz任务读取产生【混叠】(高频振动折进低频、穿过80Hz
 *   软低通→D项放大→突发抖动)。降到416<500即不混叠, 一行救命。
 * ══════════════════════════════════════════════════════════════ */
bool lsm6ds3Init(void) {
    if (s_present) return true;

    imuPowerOn();
    vTaskDelay(pdMS_TO_TICKS(50));      /* 等芯片上电 + 内部 boot */

    i2cdevInit(I2C_INT_DEV);

    /* 探测 0x6A (XIAO Sense 固定), 兜底再试 0x6B */
    static const uint8_t addrs[2] = { 0x6A, 0x6B };
    for (int a = 0; a < 2; a++) {
        uint8_t who = 0;
        /* 多试两次, 给总线/芯片一点稳定时间 */
        for (int retry = 0; retry < 3; retry++) {
            if (i2cdevReadByte(I2C_INT_DEV, addrs[a], LSM6DS3_REG_WHO_AM_I, &who) &&
                (who == 0x6A || who == 0x69)) {
                s_addr = addrs[a];
                s_who  = who;
                break;
            }
            vTaskDelay(pdMS_TO_TICKS(5));
        }
        if (s_addr != 0) break;
    }
    if (s_addr == 0) return false;

    /* 软复位 → 等待 → BDU + 地址自增 */
    i2cdevWriteByte(I2C_INT_DEV, s_addr, LSM6DS3_REG_CTRL3_C, LSM6DS3_CTRL3_SWRESET);
    vTaskDelay(pdMS_TO_TICKS(20));
    i2cdevWriteByte(I2C_INT_DEV, s_addr, LSM6DS3_REG_CTRL3_C, LSM6DS3_CTRL3_BDU_INC);

    /* V22.85: 量程/ODR ±16g / ±2000dps @ 416Hz(原833Hz)。
     * 833Hz 陀螺无硬件低通, 被 500Hz 采样任务读取会【混叠】(高频振动折进低频、穿过80Hz软低通)
     * → 间歇尖峰 → rate环D项放大 → "突然抖动窜偏"(尤其只用板载LSM6、无GY-91时)。
     * 降到 416Hz: 读取率500Hz > 416Hz → 不再混叠, 振动由现有80Hz软低通干净滤掉。
     * 量程不变→缩放(70mdps/LSB, 0.488mg/LSB)不变; 延迟仅多~1.2ms(可接受)。
     * 回退: 改回 LSM6DS3_CTRL1_833_16G / LSM6DS3_CTRL2_833_2K。 */
    /* ── V23.36 D43 编译期奈奎斯特守卫: 陀螺ODR必须<=任务读取率, 否则混叠(见V22.85事故)。
     *    谁把 LSM6_SELECTED_ODR_HZ 改回833(或改超读取率), 这行直接编译失败, 拦在飞起来抖之前。 ── */
    static_assert(LSM6_SELECTED_ODR_HZ <= LSM6_TASK_READ_RATE_HZ,
                  "LSM6 gyro ODR exceeds sensor read rate -> aliasing (V22.85). Lower ODR or raise read rate.");

    i2cdevWriteByte(I2C_INT_DEV, s_addr, LSM6DS3_REG_CTRL1_XL, LSM6DS3_CTRL1_416_16G);
    i2cdevWriteByte(I2C_INT_DEV, s_addr, LSM6DS3_REG_CTRL2_G,  LSM6DS3_CTRL2_416_2K);
    vTaskDelay(pdMS_TO_TICKS(20));      /* 第一笔有效数据 */

    s_present = true;
    return true;
}

bool    lsm6ds3IsPresent(void) { return s_present; }
uint8_t lsm6ds3GetAddr(void)   { return s_addr; }
uint8_t lsm6ds3GetWhoAmI(void) { return s_who; }

bool lsm6ds3Read(int16_t acc[3], int16_t gyro[3]) {
    if (!s_present) return false;

    uint8_t b[12];
    if (!i2cdevRead(I2C_INT_DEV, s_addr, LSM6DS3_REG_OUTX_L_G, 12, b))
        return false;

    /* 小端: 低字节在前; 顺序: 陀螺XYZ → 加速XYZ */
    gyro[0] = (int16_t)((b[1]  << 8) | b[0]);
    gyro[1] = (int16_t)((b[3]  << 8) | b[2]);
    gyro[2] = (int16_t)((b[5]  << 8) | b[4]);
    acc[0]  = (int16_t)((b[7]  << 8) | b[6]);
    acc[1]  = (int16_t)((b[9]  << 8) | b[8]);
    acc[2]  = (int16_t)((b[11] << 8) | b[10]);
    return true;
}
