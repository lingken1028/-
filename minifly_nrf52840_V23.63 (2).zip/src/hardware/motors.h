/**
 * @file    motors.h
 * @brief   电机驱动
 *          对应: HARDWARE/interface/motors.h (逐字对照)
 *
 * 原始: STM32F411 96MHz, TIM2/TIM4 8-bit PWM @ 375kHz
 *   TIM4-CH2 PB7  = M1
 *   TIM4-CH1 PB6  = M2
 *   TIM2-CH3 PB10 = M3
 *   TIM2-CH1 PA5  = M4
 *   MOTORS_PWM_BITS = 8, MOTORS_PWM_PERIOD = 255
 *   ratioToCCRx(u16 val) = (val >> (16-8)) & 0xFF
 *
 * 移植: nRF52840 analogWrite() 8-bit (0~255)
 *   D0=M1  D1=M2  D2=M3  D3=M4
 *   motorsSetRatio(id, u16): u16 >> 8 → analogWrite
 *
 * 电机布局 (俯视 X型):
 *   M1(CW 左前)   M2(CCW 右前)
 *        ╲       ╱
 *        ╱       ╲
 *   M4(CCW 左后) M3(CW 右后)
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>

/* 96M主频下 8位精度输出375K PWM (对应原始宏) */
#define TIM_CLOCK_HZ              96000000
#define MOTORS_PWM_BITS           8
#define MOTORS_PWM_PERIOD         ((1<<MOTORS_PWM_BITS) - 1)   /* 255 */
#define MOTORS_PWM_PRESCALE       0

/* 电池油门补偿使能 (对应原始 motors.c #define ENABLE_THRUST_BAT_COMPENSATED) */
#define ENABLE_THRUST_BAT_COMPENSATED

#define NBR_OF_MOTORS  4
#define MOTOR_M1       0
#define MOTOR_M2       1
#define MOTOR_M3       2
#define MOTOR_M4       3

/* 测试参数 (对应原始宏) */
#define MOTORS_TEST_RATIO         ((uint16_t)(0.2f * 65535))
#define MOTORS_TEST_ON_TIME_MS    50
#define MOTORS_TEST_DELAY_TIME_MS 150

/* 全局电机占空比记录 (对应原始 motor_ratios[]) */
extern uint32_t motor_ratios[NBR_OF_MOTORS];

void motorsInit(void);
bool motorsTest(void);
void motorsSetRatio(uint32_t id, uint16_t ithrust);