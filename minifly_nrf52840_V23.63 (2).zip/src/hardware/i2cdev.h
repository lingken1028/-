/**
 * @file    i2cdev.h
 * @brief   I2C 工具函数接口 — V22
 *          对应: HARDWARE/interface/i2cdev.h
 *
 * ══ V22 重写原因 (V14~V21 的致命 bug) ══
 *   旧版自定义 "NRF_TWIM2 = 0x40022000":
 *   nRF52840 根本没有 TWIM2! 0x40022000 实际是 NRF_PWM2 外设。
 *   所有 "I2C" 读写都打进了 PWM2 寄存器 →
 *     · GY-91 永远探测不到 (WHO_AM_I 恒为 0)
 *     · 每次读写空转 ~50 万次轮询超时 (≈100ms+ 忙等)
 *
 * ══ V22 方案 ══
 *   nRF52840 真实 TWIM 实例只有 TWIM0(0x40003000) / TWIM1(0x40004000)。
 *   本工程从不调用 Wire.begin()/Wire1.begin()，因此两个 TWIM 都空闲：
 *     I2C1_DEV    = TWIM0 → GY-91 外部总线  (SCL=D8/P1.13, SDA=D10/P1.15)
 *     I2C_INT_DEV = TWIM1 → 板载 LSM6DS3TR-C (SCL=P0.27,   SDA=P0.07)
 *   轮询模式 + 超时 + 互斥锁 (FreeRTOS mutex)，不依赖中断与 BSP 引脚表。
 *   两条总线均开内部上拉：拔掉 GY-91 后总线悬空也不会卡死。
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <nrf.h>
#include <FreeRTOS.h>
#include <semphr.h>

/* I2C 总线描述符 (V22: 不再是 TwoWire) */
typedef struct I2C_Dev_s {
    NRF_TWIM_Type*    twim;       /* NRF_TWIM0 / NRF_TWIM1 */
    uint8_t           sclPort, sclPin;
    uint8_t           sdaPort, sdaPin;
    SemaphoreHandle_t mutex;      /* 总线互斥 (i2cdevInit 中创建) */
    bool              isInit;
    uint8_t           txBuf[64];  /* EasyDMA 发送缓冲 (必须在 RAM) */
} I2C_Dev;

extern I2C_Dev* I2C1_DEV;     /* GY-91 外部总线 (TWIM0, D8/D10) */
extern I2C_Dev* I2C_INT_DEV;  /* 板载 LSM6DS3TR-C 内部总线 (TWIM1) */

bool i2cdevInit(I2C_Dev* dev);
bool i2cdevReadByte(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t* data);
bool i2cdevWriteByte(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t data);
bool i2cdevRead(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint16_t len, uint8_t* data);
bool i2cdevWrite(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint16_t len, uint8_t* data);
bool i2cdevReadBit(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t bitNum, uint8_t* data);
bool i2cdevWriteBit(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t bitNum, uint8_t data);
bool i2cdevReadBits(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t bitStart, uint8_t length, uint8_t* data);
bool i2cdevWriteBits(I2C_Dev* dev, uint8_t devAddr, uint8_t memAddr, uint8_t bitStart, uint8_t length, uint8_t data);
