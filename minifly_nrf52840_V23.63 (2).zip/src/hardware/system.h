/**
 * @file    system.h
 * @brief   系统初始化头文件
 *          对应: HARDWARE/interface/system.h
 *
 * 原始 system.c 初始化顺序 (systemInit):
 *   1. nvicInit()        → nRF52840 无需（Arduino 核心已处理）
 *   2. extiInit()        → nRF52840 无需（无 EXTI，改用轮询）
 *   3. delay_init(96)    → 无需
 *   4. ledInit()         → D6 引脚初始化
 *   5. ledseqInit()      → FreeRTOS 软件定时器 LED 序列
 *   6. commInit()        → atkpInit() + usblinkInit()
 *   7. atkpInit()        → 已在 commInit 中
 *   8. configParamInit() → RAM 默认参数
 *   9. pmInit()          → ADC 预热
 *  10. stabilizerInit()  → 电机 + 传感器 + PID 初始化
 *  11. expModuleDriverInit() → 已移除
 *  12. systemTest()      → 各模块测试
 *  13. watchdogInit(150) → nRF52840 WDT (可选)
 *
 * 注意: nRF52840 版本不需要调用 vTaskStartScheduler()
 */
#pragma once
#include <stdbool.h>

void systemInit(void);