/**
 * @file    led.h
 * @brief   LED 驱动接口 (V16: 增加外部 D6 LED)
 *
 * 板载 RGB active-LOW; 外部D6 active-HIGH (跟随SYS/CHG)
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>

#define LED_NUM 5

typedef enum {
    LED_BLUE_L  = 0,
    LED_GREEN_L = 1,
    LED_RED_L   = 2,
    LED_GREEN_R = 3,
    LED_RED_R   = 4,
} led_e;

#define DATA_RX_LED  LED_GREEN_L
#define DATA_TX_LED  LED_RED_L
#define CHG_LED      LED_BLUE_L
#define LOWBAT_LED   LED_RED_R
#define SYS_LED      LED_GREEN_R
#define ERR_LED1     LED_RED_L
#define ERR_LED2     LED_RED_R

void ledInit(void);
bool ledTest(void);
void ledSetAll(void);
void ledClearAll(void);
void ledSet(led_e led, bool value);
void ledFlashOne(led_e led, uint32_t onTime, uint32_t offTime);