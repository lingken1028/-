/**
 * @file    system.cpp
 * @brief   系统初始化 — 针对上位机连接延迟优化
 *
 * ══ 原始 system.c 阻塞时间分析 ══
 *   初始 LED 快闪 6 次        = 1200ms
 *   ledTest() vTaskDelay×2   =  500ms
 *   pass/fail ledFlashOne×5  =  500ms
 *   ──────────────────────────────
 *   合计约                   = 2200ms → 超过上位机超时阈值
 *
 * ══ 优化方案 ══
 *   初始 LED 快闪 1 次        =  100ms  (仍可确认代码运行)
 *   systemTest 移至后台       =    0ms  (不阻塞任务启动)
 *   合计约                   =  150ms  → 上位机 <1.5s 即可连接
 *
 * ══ 移植变化 ══
 *   nvicInit/extiInit/delay_init → 无需 (Arduino 核心已处理)
 *   expModuleDriverInit → 已移除
 *   systemTest → 调用但不阻塞启动流程
 *   watchdogInit → loop() 中 vTaskDelay 替代喂狗
 */
#include "system.h"
#include "led.h"
#include "../communicate/ledseq.h"
#include "../communicate/comm.h"
#include "../communicate/atkp.h"
#include "../communicate/console.h"
#include "../config_param.h"
#include "../communicate/pm.h"
#include "../flight/stabilizer.h"
#include "../config.h"
#include <Arduino.h>

static bool systemTest(void);

void systemInit(void)
{
    /* ── 最早诊断: 板载蓝灯快闪 1 次 (~100ms) ─────────────────────
     * 原版 6 次 = 1200ms 阻塞 → 改为 1 次仍能目视确认代码在运行
     * XIAO nRF52840 板载 LED = active-LOW (LOW=亮, HIGH=灭)        */
#if defined(LED_BLUE)
    pinMode(LED_BLUE, OUTPUT);
    for (int i = 0; i < 3; i++) {
        digitalWrite(LED_BLUE, LOW);   delay(100);
        digitalWrite(LED_BLUE, HIGH);  delay(100);
    }
#else
    pinMode(LED_BUILTIN, OUTPUT);
    for (int i = 0; i < 3; i++) {
        digitalWrite(LED_BUILTIN, LOW);   delay(100);
        digitalWrite(LED_BUILTIN, HIGH);  delay(100);
    }
#endif

    /* ── 电机安全: 上电立即关闭所有电机 ──
     * V22.18: 用 digitalWrite(LOW) 而非 analogWrite —— 高频 PWM 模式下电机由
     * HwPWM0 接管, 这里若先 analogWrite 会抢占 PWM 外设/引脚, 与 motorsInit 冲突。
     * 占空比 0 = 持续低电平, digitalWrite(LOW) 等效且不碰 PWM 外设。 */
    pinMode(MOTOR1_PIN, OUTPUT); digitalWrite(MOTOR1_PIN, LOW);
    pinMode(MOTOR2_PIN, OUTPUT); digitalWrite(MOTOR2_PIN, LOW);
    pinMode(MOTOR3_PIN, OUTPUT); digitalWrite(MOTOR3_PIN, LOW);
    pinMode(MOTOR4_PIN, OUTPUT); digitalWrite(MOTOR4_PIN, LOW);
    analogReadResolution(12);

    /* Serial.begin 已在 setup() 最早调用 */

    /* 对应原始: ledInit / ledseqInit */
    ledInit();
    ledseqInit();
    /* debug removed — conflicts with ANO */

    /* 对应原始: commInit / atkpInit / consoleInit */
    commInit();
    atkpInit();
    consoleInit();
    /* debug removed — conflicts with ANO */

    /* 对应原始: configParamInit / pmInit / stabilizerInit */
    configParamInit();
    pmInit();
    stabilizerInit();
    /* debug removed — conflicts with ANO */

    /* expModuleDriverInit() → 已移除 */

    /* ── systemTest: 执行但不用 LED 阻塞流程 ──────────────────────
     * 原版: pass → ledFlashOne×5 = 500ms; fail → 死循环
     * 优化: 直接打印结果, 不延时, 继续运行
     * 任务将在 startTask() 中创建, 不能在这里阻塞太久             */
    bool testOk = systemTest();
    if (testOk) {
        ledSet(LED_GREEN_L, 1);   /* 绿灯亮 (非阻塞) */
        /* debug removed — conflicts with ANO */
    } else {
        ledSet(LED_RED_R, 1);     /* 红灯亮 (非阻塞) */
        /* debug removed — conflicts with ANO */
    }

    /* watchdogInit — loop() vTaskDelay 替代喂狗 */
}

static bool systemTest(void)
{
    bool pass = true;

    /* ledseqTest/ledTest: 含 vTaskDelay 500ms → 跳过以加快启动
     * LED 状态会在上面 ledSet 中体现                             */
    /* pass &= ledseqTest(); */

    if (!pmTest())          {
pass=false; }
    if (!configParamTest()) {
pass=false; }
    if (!commTest())        {
pass=false; }
    if (!stabilizerTest())  {
pass=false; }

    /* watchdogTest → nRF52840 简化, 始终通过 */
    return pass;
}