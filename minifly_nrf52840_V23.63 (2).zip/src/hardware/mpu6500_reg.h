/**
 * @file    mpu6500_reg.h
 * @brief   MPU6500/MPU-9250 寄存器地址和常量定义
 *          对应: HARDWARE/interface/mpu6500.h (寄存器部分摘录)
 *
 * 原固件关键配置 (sensors.c sensorsDeviceInit):
 *   地址:     0x69 (AD0_HIGH, 原固件)
 *             0x68 (GY-91 AD0=GND, 移植版)
 *   WHO_AM_I: 0x38 / 0x39 = MPU-9250
 *   陀螺量程: MPU6500_GYRO_FS_2000 (±2000°/s)
 *             DEG_PER_LSB_2000 = (2×2000)/65536 ≈ 0.06103°/LSB
 *   加速量程: MPU6500_ACCEL_FS_16  (±16g)
 *             G_PER_LSB_16    = (2×16)/65536   ≈ 0.000488 g/LSB
 *   陀螺 LPF: MPU6500_DLPF_BW_98  (98Hz)
 *   加速 LPF: MPU6500_ACCEL_DLPF_BW_41 (41Hz)
 *   采样率:   0 → 1000Hz (SMPLRT_DIV=0)
 *   软件 LPF: 陀螺 80Hz, 加速计 30Hz (lpf2p 二阶)
 */
#pragma once
#include <stdint.h>

/* ── I2C 地址 ── */
#define MPU6500_ADDRESS_AD0_LOW   0x68
#define MPU6500_ADDRESS_AD0_HIGH  0x69
#define MPU6500_DEFAULT_ADDRESS   MPU6500_ADDRESS_AD0_HIGH

/* ── 关键寄存器地址 ── */
#define MPU6500_RA_SMPLRT_DIV     0x19
#define MPU6500_RA_CONFIG         0x1A
#define MPU6500_RA_GYRO_CONFIG    0x1B
#define MPU6500_RA_ACCEL_CONFIG   0x1C
#define MPU6500_RA_ACCEL_CONFIG_2 0x1D
#define MPU6500_RA_INT_PIN_CFG    0x37
#define MPU6500_RA_INT_ENABLE     0x38
#define MPU6500_RA_ACCEL_XOUT_H   0x3B
#define MPU6500_RA_GYRO_XOUT_H    0x43
#define MPU6500_RA_PWR_MGMT_1     0x6B
#define MPU6500_RA_USER_CTRL      0x6A
#define MPU6500_RA_I2C_MST_CTRL   0x24
#define MPU6500_RA_WHO_AM_I       0x75

/* ── 陀螺量程 (GYRO_CONFIG FS_SEL[4:3]) ── */
#define MPU6500_GYRO_FS_250   0x00
#define MPU6500_GYRO_FS_500   0x01
#define MPU6500_GYRO_FS_1000  0x02
#define MPU6500_GYRO_FS_2000  0x03   /* 原固件使用: SENSORS_GYRO_FS_CFG */

/* ── 加速计量程 (ACCEL_CONFIG AFS_SEL[4:3]) ── */
#define MPU6500_ACCEL_FS_2    0x00
#define MPU6500_ACCEL_FS_4    0x01
#define MPU6500_ACCEL_FS_8    0x02
#define MPU6500_ACCEL_FS_16   0x03   /* 原固件使用: SENSORS_ACCEL_FS_CFG */

/* ── DLPF 配置 (CONFIG register) ── */
#define MPU6500_DLPF_BW_256   0x00
#define MPU6500_DLPF_BW_188   0x01
#define MPU6500_DLPF_BW_98    0x02   /* 原固件陀螺滤波 */
#define MPU6500_DLPF_BW_42    0x03
#define MPU6500_DLPF_BW_20    0x04
#define MPU6500_DLPF_BW_10    0x05
#define MPU6500_DLPF_BW_5     0x06

/* ── 加速计 DLPF (ACCEL_CONFIG_2 register) ── */
#define MPU6500_ACCEL_DLPF_BW_460  0x00
#define MPU6500_ACCEL_DLPF_BW_184  0x01
#define MPU6500_ACCEL_DLPF_BW_92   0x02
#define MPU6500_ACCEL_DLPF_BW_41   0x03   /* 原固件加速计滤波 */
#define MPU6500_ACCEL_DLPF_BW_20   0x04
#define MPU6500_ACCEL_DLPF_BW_10   0x05
#define MPU6500_ACCEL_DLPF_BW_5    0x06

/* ── 时钟源 (PWR_MGMT_1) ── */
#define MPU6500_CLOCK_PLL_XGYRO   0x01   /* 原固件: X轴陀螺作为时钟 */
#define MPU6500_PWR1_DEVICE_RESET 0x80
#define MPU6500_PWR1_SLEEP_BIT    6

/* ── 量程转换因子 (原固件 sensors.c 使用) ── */
/* sensors.c: SENSORS_GYRO_FS_CFG=MPU6500_GYRO_FS_2000
 *            SENSORS_DEG_PER_LSB_CFG=MPU6500_DEG_PER_LSB_2000 */
#define MPU6500_DEG_PER_LSB_2000  ((float)((2.0f * 2000.0f) / 65536.0f))  /* 0.06103°/LSB */
#define MPU6500_G_PER_LSB_16      ((float)((2.0f * 16.0f)   / 65536.0f))  /* 0.000488 g/LSB */

/* sensors.c 低通滤波截止频率 */
/* GYRO_LPF_CUTOFF_FREQ defined in sensors.h (removed here V11) */
/* ACCEL_LPF_CUTOFF_FREQ defined in sensors.h (removed here V11) */

/* WHO_AM_I 期望值 */
#define MPU9250_WHO_AM_I_VAL_0  0x38  /* AD0=0: MPU-9250 WHO_AM_I */
#define MPU9250_WHO_AM_I_VAL_1  0x39