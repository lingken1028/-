/**
 * @file    bmp280.h
 * @brief   BMP280 原生 I2C 驱动
 *          替代 Adafruit_BMP280 库 — 直接寄存器访问
 *
 * ══ 变更原因 (V10) ══
 *   新 platformio.ini 移除了 Adafruit BMP280 Library
 *   BMP280 通过 GY-91 连接在 WireGY91 (D8/D10 自定义 I2C) 上
 *   直接寄存器读写无需额外库
 *
 * ══ 初始化配置 (对应原始固件) ══
 *   ctrl_meas = 0x93: osrs_t=×8, osrs_p=×8, Normal mode
 *   config    = 0x10: filter=×16, t_sb=0.5ms
 *
 * ══ 补偿公式 (BMP280 datasheet 4.2.3) ══
 *   温度: float → °C
 *   气压: float → Pa → hPa (/100)
 *   海拔: ISA 气压公式 → m
 *
 * ══ 使用方法 ══
 *   bmp280Init(I2C1_DEV);          // 初始化
 *   if (bmp280IsPresent()) ...     // 检测 (chip_id=0x60)
 *   bmp280Read(&press_hPa, &temp); // 50Hz 读取
 *   float asl = bmp280GetAlt(press_hPa); // 海拔 m
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "i2cdev.h"

/* BMP280 I2C 地址 (SDO=GND → 0x76) */
#define BMP280_ADDR   0x76

/* 寄存器 (对应原始 bmp280.h) */
#define BMP280_REG_CHIP_ID   0xD0   /* 期望值: 0x60 */
#define BMP280_REG_RESET     0xE0   /* 写 0xB6 软复位 */
#define BMP280_REG_STATUS    0xF3
#define BMP280_REG_CTRL_MEAS 0xF4   /* osrs_t[7:5] osrs_p[4:2] mode[1:0] */
#define BMP280_REG_CONFIG    0xF5   /* t_sb[7:5] filter[4:2] spi3w_en[0] */
#define BMP280_REG_PRESS_MSB 0xF7   /* press_raw[19:12] */
#define BMP280_REG_PRESS_LSB 0xF8   /* press_raw[11:4] */
#define BMP280_REG_PRESS_XSB 0xF9   /* press_raw[3:0] in bits[7:4] */
#define BMP280_REG_TEMP_MSB  0xFA   /* temp_raw[19:12] */
#define BMP280_REG_TEMP_LSB  0xFB   /* temp_raw[11:4] */
#define BMP280_REG_TEMP_XSB  0xFC   /* temp_raw[3:0] in bits[7:4] */
#define BMP280_REG_CALIB     0x88   /* 24字节校准数据起始 */

/* 配置值 (对应原始 bmp280.c Normal×8×16) */
#define BMP280_CTRL_MEAS_VAL 0x93   /* osrs_t=100(×8) osrs_p=100(×8) mode=11(Normal) */
#define BMP280_CONFIG_VAL    0x10   /* filter=100(×16) t_sb=000(0.5ms) */

void  bmp280Init(I2C_Dev* dev);
bool  bmp280IsPresent(void);
void  bmp280EnsureMode(void);   /* V22.45: 重写模式寄存器, 热插拔/掉电复位后恢复 Normal 连续转换 */
bool  bmp280Read(float* press_hPa, float* temp_C);
float bmp280GetAltitude(float press_hPa);