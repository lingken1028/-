/**
 * @file    main.cpp — V22 正式启动版 (取代 V21 分级诊断版)
 *
 * ══ V21 → V22 变化 ══
 *   V21 是"分级诊断版": 每级任务间隔3秒 + 8秒倒计时, 用来定位
 *   "某任务一启动就死"。该现象的根因已在 V22 修掉:
 *     · I2C 打进 PWM2 (假 TWIM2) → 改真实 TWIM0/TWIM1
 *     · sensors 与 stabilizer 抢 I2C → 改单读者架构 + 队列先建填零
 *     · 拔 GY-91 后 Wire1 降级失败 → 板载 IMU 自供电直驱
 *   因此 V22 直接按原厂顺序一次性启动所有任务, 不再人为分级延时。
 *
 * ══ 启动流程 ══
 *   setup(): Serial → systemInit()(LED/驱动/各模块Init) → 建 startTask
 *   startTask():
 *     - 3 秒"打开串口"窗口 (方便地面站/XCOM 连接, 可按需删)
 *     - 依次创建: USBLINK / CONFIG+PM / ATKP / SENSORS / STABILIZER / RADIOLINK
 *     - 传感器探测完成后打印一行诊断 (IMU 类型/磁/气压)
 *     - 进入心跳: 每 5 秒一行 ALIVE + 电压 + 连接状态 (可按需删)
 *
 * ══ 诊断输出 (XCOM/匿名上位机串口, 115200) ══
 *   [V22] BOOT
 *   SENSORS: IMU=MPU9250@0x68 who=0x71 MAG=AK8963 BARO=BMP280
 *   (或) SENSORS: IMU=LSM6DS3@0x6A who=0x6A (onboard) MAG=none BARO=none
 *   (或) SENSORS: IMU=NONE!! check wiring ...
 *   READY radio=ON
 *   ALIVE 1 vbat=3.92 link=NO
 */
#include <Arduino.h>
#include <Adafruit_TinyUSB.h>
#include "config.h"
#include <FreeRTOS.h>
#include <task.h>
#include <stdio.h>
#include <string.h>
#include "hardware/system.h"
#include "communicate/radiolink.h"
#include "communicate/usblink.h"
#include "communicate/atkp.h"
#include "config_param.h"
#include "communicate/pm.h"
#include "flight/sensors.h"
#include "flight/stabilizer.h"
#include "flight/sensfusion6.h"   /* getIsCalibrated() — 心跳显示校准状态 */
#include "flight/power_control.h"  /* V22.19: getMotorPWM — 心跳显示四电机PWM(诊断削顶/打架) */
#include "communicate/commander.h" /* V22.3: 心跳显示遥控/油门/解锁状态 */

/* 设为 0 可去掉启动窗口与心跳, 进入纯静默正式运行 */
#define V22_BOOT_VERBOSE   1
#define V22_OPEN_WINDOW_S  3

TaskHandle_t startTaskHandle;
static void startTask(void *arg);

/* 直写 CDC FIFO, 不依赖 DTR (XCOM 不勾 DTR 也能收) */
static void diag(const char* s) {
#if V22_BOOT_VERBOSE
    tud_cdc_write(s, strlen(s));
    tud_cdc_write_flush();
#else
    (void)s;
#endif
}

void setup()
{
    Serial.begin(115200);
    /* V23.13: RESETREAS 打印移至 startTask 的 READY 之后 — 原来打在这里时主机还没开串口, 进了虚空还把寄存器清了(你日志里看不到它的原因)。 */
    { uint32_t t0 = millis();
      while (!Serial && millis() - t0 < 2000) { delay(10); } }

    systemInit();   /* LED/电机关断/各模块 Init (含 stabilizerInit) */

    xTaskCreate(startTask, "START_TASK", STACK_START, NULL, PRIO_START, &startTaskHandle);
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】startTask — 整机的"启动指挥官"
 *   这段做了什么(按顺序):
 *   ① 打 BOOT 横幅 + 3 秒开串口窗口(方便地面站抢先连上看启动日志)
 *   ② 按依赖顺序创建八个任务: USB收发 → 参数/电源 → ATKP协议收发
 *      → 传感器(等600ms探测) → 姿态主循环 → 无线ESB(最后开, 避免
 *      遥控器数据在控制链就绪前涌入)
 *   ③ 打 READY + RESETREAS 复位取证(V23.13: 0x0=掉电复位/0x2=看门狗/
 *      0x8=CPU LOCKUP — 空中重启事故的第一现场证据)
 *   ④ 自身转入 2 秒心跳循环(全字段诊断行, 每个字段的判读法见下方注释)
 * ══════════════════════════════════════════════════════════════ */
static void startTask(void *arg)
{
    (void)arg;
    static char line[384];   /* 移出栈: startTask栈紧张, 见 STACK_START 注释 */

    snprintf(line, sizeof(line), "\r\n[BOOT] fw=%s\r\n", FW_VERSION);   /* V23.13: 陈年"[V22] BOOT"横幅换真实版本 */
    diag(line);
#if V22_BOOT_VERBOSE
    for (int i = V22_OPEN_WINDOW_S; i > 0; i--) {
        snprintf(line, sizeof(line), "open serial... %d\r\n", i);
        diag(line);
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
#endif

    /* USB 链路 (上位机收发) */
    xTaskCreate(usblinkRxTask, "USBLINK_RX", STACK_USBLINK_RX, NULL, PRIO_USBLINK_RX, NULL);
    xTaskCreate(usblinkTxTask, "USBLINK_TX", STACK_USBLINK_TX, NULL, PRIO_USBLINK_TX, NULL);

    /* 参数 + 电源管理 */
    xTaskCreate(configParamTask, "CONFIG_TASK", STACK_CONFIG, NULL, PRIO_CONFIG, NULL);
    xTaskCreate(pmTask,          "PWRMGNT",     STACK_PM,     NULL, PRIO_PM,     NULL);

    /* ATKP 协议收发 */
    xTaskCreate(atkpTxTask,    "ATKP_TX",     STACK_ATKP_TX, NULL, PRIO_ATKP_TX, NULL);
    xTaskCreate(atkpRxAnlTask, "ATKP_RX_ANL", STACK_ATKP_RX, NULL, PRIO_ATKP_RX, NULL);

    /* 传感器 (内部完成 GY-91/板载IMU 探测) */
    xTaskCreate(sensorsTask, "SENSORS", STACK_SENSORS, NULL, PRIO_SENSORS, NULL);

    /* 等探测完成后打印诊断 (sensorsTask 入口有 150ms 延时) */
    vTaskDelay(pdMS_TO_TICKS(600));
    snprintf(line, sizeof(line), "SENSORS: %s\r\n", sensorsGetDiagString());
    diag(line);

#if MAG_CAL_ON_BOOT
    /* V23.47: 开机自动进入磁校准 —— 免去必须连上位机(上位机与XCOM抢串口, 二选一)。
     * 上电后水平慢转飞机约12秒, ALIVE 的 magcal 会 0→100, 完成后持续打印 [MAGCAL] 六个值。 */
    vTaskDelay(pdMS_TO_TICKS(2000));
    diag("[MAGCAL] auto-cal started: rotate level ~12s, watch magcal 0->100\r\n");
    sensorsStartMagCal();
#endif

    /* 姿态/控制主循环 */
    xTaskCreate(stabilizerTask, "STABILIZER", STACK_STABILIZER, NULL, PRIO_STABILIZER, NULL);

    /* 无线 ESB (与原遥控器 @1Mbps 通信) */
    xTaskCreate(radiolinkTask, "RADIOLINK", STACK_RADIOLINK, NULL, PRIO_RADIOLINK, NULL);

    diag("READY radio=ON\r\n");

    /* V23.13: 复位原因取证(此刻主机已开串口, 看得见了)。
     * 0x0=掉电/上电复位(满油门vbat已到2.8x, 头号嫌疑)  0x2=看门狗  0x8=CPU LOCKUP。异常后重新上电抄这行。 */
    snprintf(line, sizeof(line), "[BOOT] fw=%s RESETREAS=0x%08lX%s\r\n", FW_VERSION,
             (unsigned long)NRF_POWER->RESETREAS,
             (NRF_POWER->RESETREAS == 0) ? " (POR/掉电复位)" : "");
    diag(line);
    NRF_POWER->RESETREAS = 0xFFFFFFFF;

#if V22_BOOT_VERBOSE
    /* 心跳 + 姿态/校准诊断:
     *  - 把飞机放平静置, 几秒后应看到 cal=YES (重力校准完成, 遥控器才放行可飞)
     *  - 放平时 roll/pitch 应 ≈0; 机头朝下压, pitch 应单向变化; 右滚, roll 单向变化
     *  - 若放平却 |roll|或|pitch|>60, 或方向相反 → GY-91 安装方向不对,
     *    去 config.h 改 GY91_AXIS_MAP / GY91_AXIS_SIGN (见文末说明) */
    uint32_t n = 0;
    while (1) {
        attitude_t att; getAttitudeData(&att);
        motorPWM_t mp; getMotorPWM(&mp);   /* V22.19: 四电机PWM —— 满油门时若一高一低/有的撞65535 = rate PID削顶丢升力 */
        Axis3f sAcc, sVel, sPos; getStateData(&sAcc, &sVel, &sPos);  /* V22.32: 定高调试 — 估测高度/垂直速度 */
        /* rx=YES 表示正在收遥控杆数据(isRCLocked==false); thr=当前油门;
         * fly=已解锁起飞键。叶片不动时按这行判断:
         *   rx=NO   → 没收到遥控数据(无线/解锁问题, 见说明)
         *   rx=YES thr=0 → 收到了但油门为0(把油门杆往上推)
         *   rx=YES thr>0 但电机不转 → 看电机接线/供电
         * M1..M4: 满油门时应四个都接近且都高; 若一两个=65535其余很低 → 振动→rate PID削顶 */
        snprintf(line, sizeof(line),
                 "ALIVE %lu B=%lu/%lu/m%u fw=%s vbat=%.2f link=%s cal=%s baro=%s rx=%s thr=%u fly=%d land=%d hd=%d cm=0x%02X M=%lu,%lu,%lu,%lu R=%.0f P=%.0f Y=%.0f alt=%.0f zt=%.0f vz=%.0f mag=%s magY=%.0f magcal=%d brd=%lu imuerr=%lu vib=%.1f fs=%c st=%02X ce=%lu\r\n",
                 (unsigned long)++n,
#if RADIO_BCAST_EN
                 (unsigned long)radiolinkBcastRxCnt(), (unsigned long)radiolinkRxTotCnt(), (unsigned)radiolinkLastRxMatch(),
#else
                 0UL, 0UL, 0U,
#endif
                 FW_VERSION, pmGetBatteryVoltage(),
                 radiolinkIsConnected() ? "YES" : "NO",
                 getIsCalibrated() ? "YES" : "NO",
                 getIsBaroPresent() ? "Y" : "N",
                 commanderGetIsRCLocked() ? "NO" : "YES",
                 (unsigned)commanderGetThrust(),
                 getCommanderKeyFlight() ? 1 : 0,
                 getCommanderKeyland() ? 1 : 0,
                 getCommanderFlightmode() ? 1 : 0,
                 (unsigned)getCommanderCtrlMode(),
                 (unsigned long)mp.m1,(unsigned long)mp.m2,(unsigned long)mp.m3,(unsigned long)mp.m4,
                 att.roll, att.pitch, att.yaw,
                 sPos.z, commanderGetTargetZ(), sVel.z,
                 getIsMagPresent() ? "Y" : "N", getMagHeading(), getMagCalPercent(),
                 (unsigned long)sensorsGetBaroReadOK(),
                 (unsigned long)sensorsGetImuFailTotal(),
                 sensorsGetGyroVib(), commanderGetFailsafeChar(), (unsigned)commanderGetStateBits(),
                 (unsigned long)radiolinkGetCrcErrCount());   /* V23.44 精简: 移除 adc/ah/tb/brt/bpa/bt/txd/trim (mag三项保留 — 磁力计参与飞行)
                                                              * (可由其他字段推出、或运行中不变、或与飞行无关) */
        diag(line);

        /* V23.45: 磁校准完成 → 打印可直接抄进 config.h 的预设值。
         * 本移植版无flash持久化(configParam纯RAM), 校准结果断电即失;
         * 抄进 config.h 的 MAG_BIAS / MAG_SCALE 六个宏, 并置 MAG_CAL_PRESET=1 后, 开机即已校准。 */
        {
            /* V23.47: 改为持续打印(原一次性) —— 上位机与XCOM抢同一个串口,
             * 校准时接的是上位机, 看不到这行; 校完切回XCOM才看得到, 故必须反复打印。 */
            if (!MAG_CAL_PRESET && sensorsIsMagCalibrated()) {
                float mb[3], ms[3];
                sensorsGetMagCal(mb, ms);
                char ml[180];
                snprintf(ml, sizeof(ml),
                         "[MAGCAL] MAG_BIAS_X %.1ff MAG_BIAS_Y %.1ff MAG_BIAS_Z %.1ff MAG_SCALE_X %.4ff MAG_SCALE_Y %.4ff MAG_SCALE_Z %.4ff\r\n",
                         mb[0], mb[1], mb[2], ms[0], ms[1], ms[2]);
                diag(ml);
            }
        }
#if DUAL_IMU_GYRO
        /* V22.60 双IMU轴向验证: 转动飞机某一轴, Gm(MPU) 与 Gl(LSM) 对应轴应同号同步;
         * 某轴反号或串到别轴 → 改 config.h 的 LSM6_AXIS_MAP / LSM6_AXIS_SIGN。lsmBias=Y 表示LSM零偏已确定。 */
        {
            float gm[3], gl[3]; bool lbr = false;
            sensorsGetDualGyroDbg(gm, gl, &lbr);
            char dl[160];
            snprintf(dl, sizeof(dl),
                     "DUAL lsmBias=%s Gm=%.0f,%.0f,%.0f Gl=%.0f,%.0f,%.0f\r\n",
                     lbr ? "Y" : "N", gm[0], gm[1], gm[2], gl[0], gl[1], gl[2]);
            diag(dl);
        }
#endif
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
#else
    vTaskDelete(NULL);
#endif
}

void loop()
{
    vTaskDelay(pdMS_TO_TICKS(100));
}
