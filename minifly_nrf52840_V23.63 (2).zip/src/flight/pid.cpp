/**
 * @file    pid.cpp
 * @brief   PID 控制器实现
 *          对应: FLIGHT/src/pid.c (V1.3 逐字对照)
 *
 * V1.3 改动: 新增 pid->out 记录最终输出
 * 积分限幅 → 输出限幅 (outputLimit=0 时不限幅)
 */
#include "pid.h"
#include "../config.h"
#include <math.h>

void pidInit(PidObject* p, const float desired, const pidInit_t param, const float dt) {
    p->error = p->prevError = p->integ = p->deriv = p->out = 0.0f;
    p->prevMeas = 0.0f;   /* V22.44 */
    p->ffDLpf   = 0.0f;   /* V22.61 */
    p->desired = desired;
    p->kp = param.kp;
    p->ki = param.ki;
    p->kd = param.kd;
    p->iLimit      = DEFAULT_PID_INTEGRATION_LIMIT;
    p->outputLimit = DEFAULT_PID_OUTPUT_LIMIT;
    p->dt = dt;
    p->derivLpf = 0.0f;
#if PID_DTERM_LPF_ENABLE
    /* 一阶 IIR 低通系数: alpha = dt / (dt + RC), RC = 1/(2π·fc)
     * 慢速 PID(dt 大)算出的 alpha 接近 1 → 基本不滤(自动安全)。*/
    {
        float rc = 1.0f / (2.0f * 3.14159265f * (PID_DTERM_LPF_HZ));
        float a  = (dt > 0.0f) ? (dt / (dt + rc)) : 1.0f;
        if (a > 1.0f || a <= 0.0f) a = 1.0f;
        p->dAlpha = a;
    }
#else
    p->dAlpha = 1.0f;   /* =1 → 不滤波 (等于原始行为) */
#endif
}

float pidUpdate(PidObject* p, const float error) {
    p->error = error;

    p->deriv = (p->error - p->prevError) / p->dt;
    p->derivLpf += (p->deriv - p->derivLpf) * p->dAlpha;   /* V22.21: D项低通, 压住高频噪声放大 */

    p->outP = p->kp * p->error;
    p->outD = p->kd * p->derivLpf;

#if PID_ANTIWINDUP_ENABLE
    /* V22.36 条件抗饱和: 用"当前积分"算的输出若已撞限幅, 且误差还要把输出往同方向推,
     * 则暂停积分(防 windup)。不饱和时与原行为一致(照常累积)。 */
    float outNoNewI = p->outP + p->ki * p->integ + p->outD;
    bool atUpper = (p->outputLimit != 0.0f) && (outNoNewI >=  p->outputLimit);
    bool atLower = (p->outputLimit != 0.0f) && (outNoNewI <= -p->outputLimit);
    if (!((atUpper && p->error > 0.0f) || (atLower && p->error < 0.0f)))
        p->integ += p->error * p->dt;
#else
    p->integ += p->error * p->dt;
#endif
    if (p->integ >  p->iLimit) p->integ =  p->iLimit;
    if (p->integ < -p->iLimit) p->integ = -p->iLimit;

    p->outI = p->ki * p->integ;

    float out = p->outP + p->outI + p->outD;

    if (p->outputLimit != 0.0f) {
        if (out >  p->outputLimit) out =  p->outputLimit;
        if (out < -p->outputLimit) out = -p->outputLimit;
    }

    p->prevError = p->error;
    p->out = out;
    return out;
}

/* V22.44: 角速率内环用 — 传 设定点+测量, 支持 D-on-measurement(除微分踢) + 前馈。
 * 与 pidUpdate 的唯一区别: D 项可基于测量求导, 并可加前馈。其余(P/I/抗饱和/限幅)一致。 */
float pidUpdateFull(PidObject* p, const float setpoint, const float meas) {
    const float error = setpoint - meas;
    p->error = error;

#if PID_DERIV_ON_MEASUREMENT
    /* D = -d(测量)/dt: 设定点突变不进微分 → 无踢。稳态下 = d(误差)/dt, 与原行为一致。 */
    p->deriv = -(meas - p->prevMeas) / p->dt;
#else
    p->deriv = (error - p->prevError) / p->dt;
#endif
    p->derivLpf += (p->deriv - p->derivLpf) * p->dAlpha;

    p->outP = p->kp * error;
    p->outD = p->kd * p->derivLpf;

#if PID_ANTIWINDUP_ENABLE
    float outNoNewI = p->outP + p->ki * p->integ + p->outD;
    bool atUpper = (p->outputLimit != 0.0f) && (outNoNewI >=  p->outputLimit);
    bool atLower = (p->outputLimit != 0.0f) && (outNoNewI <= -p->outputLimit);
    if (!((atUpper && error > 0.0f) || (atLower && error < 0.0f)))
        p->integ += error * p->dt;
#else
    p->integ += error * p->dt;
#endif
    if (p->integ >  p->iLimit) p->integ =  p->iLimit;
    if (p->integ < -p->iLimit) p->integ = -p->iLimit;
    p->outI = p->ki * p->integ;

    float out = p->outP + p->outI + p->outD;
#if PID_RATE_FF_ENABLE
    out += PID_RATE_FF_GAIN * setpoint;   /* 比例前馈: 设定点直接驱动输出, 减少稳态靠积分追赶的滞后 */
    /* V22.61: 微分前馈(Betaflight 式"跟手") — 设定点变化率(≈期望角加速)前馈, 带低通(微分放大噪声)。
     * d(setpoint)/dt = [(error-prevError)+(meas-prevMeas)]/dt → 无需额外存上次设定点。默认增益0(先调好比例再开)。 */
    {
        float dsp = ((error - p->prevError) + (meas - p->prevMeas)) / p->dt;
        p->ffDLpf += (dsp - p->ffDLpf) * p->dAlpha;   /* 复用 D 项低通系数 */
        out += PID_RATE_FF_D_GAIN * p->ffDLpf;
    }
#endif

    if (p->outputLimit != 0.0f) {
        if (out >  p->outputLimit) out =  p->outputLimit;
        if (out < -p->outputLimit) out = -p->outputLimit;
    }

    p->prevError = error;
    p->prevMeas  = meas;
    p->out = out;
    return out;
}

void  pidReset(PidObject* p)               { p->error=p->prevError=p->integ=p->deriv=p->derivLpf=0.0f;
                                             p->prevMeas=0.0f; p->ffDLpf=0.0f; }   /* V23.19: 补清prevMeas/ffDLpf — 否则复位后首拍 D-on-measurement 用陈旧prevMeas → 假微分尖峰(切换/失联恢复抽一下) */
void  pidSetDesired(PidObject* p,float v)  { p->desired=v; }
float pidGetDesired(PidObject* p)          { return p->desired; }
void  pidSetIntegralLimit(PidObject* p,float v){ p->iLimit=v; }
void  pidSetOutputLimit(PidObject* p,float v)  { p->outputLimit=v; }
void  pidSetError(PidObject* p,float v)    { p->error=v; }
void  pidSetKp(PidObject* p,float v)       { p->kp=v; }
void  pidSetKi(PidObject* p,float v)       { p->ki=v; }
void  pidSetKd(PidObject* p,float v)       { p->kd=v; }
void  pidSetDt(PidObject* p,float v)       { p->dt=v; }
bool  pidIsActive(PidObject* p)            { return p->outputLimit==0.0f || fabsf(p->out)<=p->outputLimit; }