/**
 * @file    stabilizer.h
 * @brief   稳定控制器接口
 *          对应: FLIGHT/interface/stabilizer.h (逐字对照)
 */
#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "stabilizer_types.h"

void  stabilizerInit(void);
void  stabilizerTask(void* param);
bool  stabilizerTest(void);

void  getAttitudeData(attitude_t* get);
float getBaroData(void);
void  getSensorData(sensorData_t* get);
void  getStateData(Axis3f* acc, Axis3f* vel, Axis3f* pos);
void  setFastAdjustPosParam(uint16_t velTimes, uint16_t absTimes, float height);