/**
 * @file    stabilizer.cpp
 * @brief   稳定控制器主任务
 *          对应: FLIGHT/src/stabilizer.c (V1.3 逐字对照)
 *
 * V9 修正: getIsBaroPresent() 保护
 *   - positionEstimate() 只在有气压计时调用 (否则 state_estimator.cpp 已清零)
 *   - fastAdjustPosZ() 只在有气压计时运行
 *
 * 任务速率 (对应原始):
 *   500Hz: sensorsAcquire
 *   250Hz: imuUpdate (四元数+欧拉角)
 *   250Hz: positionEstimate [V9: 仅有气压计时]
 *   100Hz: commanderGetSetpoint (校准完成后)
 *   250Hz: fastAdjustPosZ [V9: 仅有气压计时]
 *   500Hz: flyerFlipCheck (非定点模式)
 *   全速:  anomalDetec + stateControl
 *   500Hz: powerControl
 *
 * getAttitudeData() 取反:
 *   pitch = -state.pitch, yaw = -state.yaw (对应原始固件)
 */
#include "stabilizer.h"
#include "sensors.h"
#include "sensfusion6.h"
#include "anomal_detec.h"
#include "state_control.h"
#include "state_estimator.h"
#include "power_control.h"
#include "flip.h"
#include "../communicate/commander.h"
#include "../communicate/ledseq.h"
#include "../config.h"
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <math.h>

static bool         s_isInit     = false;
static setpoint_t   s_setpoint   = {};
static sensorData_t s_sensorData = {};
static state_t      s_state      = {};
static control_t    s_control    = {};

/* 快速调整高度参数 */
static uint16_t s_velModeTimes = 0;
static uint16_t s_absModeTimes = 0;
static float    s_setHeight    = 0.0f;
static float    s_baroLast     = 0.0f;
static float    s_baroVelLpf   = 0.0f;

void stabilizerInit(void) {
    if (s_isInit) return;
    stateControlInit();
    powerControlInit();
    s_isInit = true;
}

bool stabilizerTest(void) {
    return stateControlTest() && powerControlTest();
}

void setFastAdjustPosParam(uint16_t velTimes, uint16_t absTimes, float height) {
    if (velTimes != 0 && s_velModeTimes == 0) {
        s_baroLast   = s_sensorData.baro.asl;
        s_baroVelLpf = 0.0f;
        s_velModeTimes = velTimes;
    }
    if (absTimes != 0 && s_absModeTimes == 0) {
        s_setHeight    = height;
        s_absModeTimes = absTimes;
    }
}

/**
 * fastAdjustPosZ — 对应原始 fastAdjustPosZ
 * V9: 仅有气压计时调用; 无气压计时 velModeTimes/absModeTimes 永远为 0
 */
static void fastAdjustPosZ(void) {
    if (!getIsBaroPresent()) return;   /* V9: 无气压计跳过 */

    if (s_velModeTimes > 0) {
        s_velModeTimes--;
        estRstHeight();
        float baroVel = (s_sensorData.baro.asl - s_baroLast) / 0.004f;
        s_baroLast    = s_sensorData.baro.asl;
        s_baroVelLpf += (baroVel - s_baroVelLpf) * 0.35f;
        s_setpoint.mode.z     = modeVelocity;
        s_state.velocity.z    = s_baroVelLpf;
        s_setpoint.velocity.z = -1.0f * s_baroVelLpf;
        if (s_velModeTimes == 0) s_setHeight = s_state.position.z;
    } else if (s_absModeTimes > 0) {
        s_absModeTimes--;
        estRstAll();
        s_setpoint.mode.z     = modeAbs;
        /* V23.18 修"定高一启动就冲天": estRstAll() 刚把估计 position.z 归0, 而这里若把目标设成
         * 绝对 s_setHeight(80) → 位置环瞬间看到80cm巨大偏差 → 油门顶满冲天。
         * 正解: 目标 = 归零后当前高度 + 起飞增量。估计稳定后此bug才暴露(以前被估计漂移掩盖)。 */
        s_setpoint.position.z = s_state.position.z + s_setHeight;
    }
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】stabilizerTask — 飞控心脏(2ms一拍的速率分频总循环)
 *   这段做了什么: 校准等待(≤6s, 超时零值也跑)后进入主循环 —
 *   500Hz 取传感器 → 250Hz Mahony姿态融合 → 250Hz INAV高度估计 →
 *   100Hz 取setpoint(commander) + 落地高度归零(真实油门=0且静止0.5s,
 *   V23.06: vz>10不算落地防高空切电投毒基线) → 250Hz 一键起飞两阶段
 *   (fastAdjustPosZ) → 500Hz 空翻检测 → 全速 异常检测+三环PID →
 *   500Hz 混控输出。所有子系统在这一根时间轴上编队。
 * ══════════════════════════════════════════════════════════════ */
void stabilizerTask(void* param) {
    stabilizerInit();
    ledseqRun(SYS_LED, seq_alive);

    /* hasBaro: removed V11 (fastAdjustPosZ checks internally) */

    uint32_t   tick  = 0;
    TickType_t xLast = xTaskGetTickCount();

    /* V16: 校准超时 6s (对应V5 calib_timeout=3000×2ms)
     * 无IMU或运动过大时仍能启动, 以零值飞控数据继续运行 */
    { uint32_t calib_t = 3000;
      while (!sensorsAreCalibrated() && calib_t > 0) {
          vTaskDelayUntil(&xLast, pdMS_TO_TICKS(MAIN_LOOP_DT_MS));
          calib_t--;
      }
    }  /* end calibration block */

    while (1) {
        vTaskDelayUntil(&xLast, pdMS_TO_TICKS(MAIN_LOOP_DT_MS));

        /* 500Hz: 传感器数据 */
        if (RATE_DO_EXECUTE(RATE_500_HZ, tick))
            sensorsAcquire(&s_sensorData, tick);

        /* 250Hz: 姿态融合 (V22.24: 传入 mag 做偏航校正) */
        if (RATE_DO_EXECUTE(ATTITUDE_ESTIMAT_RATE, tick))
            imuUpdate(s_sensorData.acc, s_sensorData.gyro, s_sensorData.mag, &s_state, ATTITUDE_ESTIMAT_DT);

        /* 250Hz: 位置估测 (V9: 仅有气压计时有意义)
         * 无气压计时 state_estimator 内部已清零, 仍调用以维持接口一致 */
        if (RATE_DO_EXECUTE(POSITION_ESTIMAT_RATE, tick))
            positionEstimate(&s_sensorData, &s_state, POSITION_ESTIMAT_DT);

        /* 100Hz: 目标设定 */
        if (RATE_DO_EXECUTE(RATE_100_HZ, tick) && getIsCalibrated())
            commanderGetSetpoint(&s_setpoint, &s_state);

        /* 100Hz: V22.80 降落停止后高度归零 — 检测"飞→停"下降沿(去抖0.5s), 触发基线重置。
         * V22.84 关键修复: 仅【手动模式】才用摇杆油门判降落!定高模式下 sp->thrust=0(内部控制器算油门),
         * 摇杆油门=0 不代表降落(你拉低油门杆时会误判)→ 会在定高飞行中重置高度→定高失控猛爬升。
         * 定高模式有自己的触地归零(estRstAll @ commander 触地检测), 这里不插手。 */
        /* V23.04: 改【全模式】+【真实电机油门】判"飞→停": 定高飞行油门恒>0不误触,
         * 一键降落触地停机后=0持续0.5s→归零 → 修"定高一键降落后高度不归零"。 */
        if (RATE_DO_EXECUTE(RATE_100_HZ, tick)) {
            static bool     s_wasFlying = false;
            static uint16_t s_stopCnt   = 0;
            if (powerGetLastThrust() != 0) {        /* 真实电机油门 !=0 = 在飞 */
                s_wasFlying = true;  s_stopCnt = 0;
            } else if (s_wasFlying) {
                if (fabsf(s_state.velocity.z) > 10.0f) s_stopCnt = 0;   /* V23.06: 还在动(如空中被切电下落)→不算落地, 防基线被定在高空(alt=-119的投毒源头) */
                else if (++s_stopCnt >= 50) {       /* 100Hz×50 = 0.5s 油门停+静止 → 判定已降落 */
                    estRstHeight();                /* 高度归零 */
                    s_wasFlying = false;  s_stopCnt = 0;
                }
            }
        }

        /* 250Hz: 快速调整高度 (V9: 内部有 hasBaro 保护) */
        if (RATE_DO_EXECUTE(RATE_250_HZ, tick))
            fastAdjustPosZ();

        /* 500Hz: 空翻检测 (非定点模式) */
        if (RATE_DO_EXECUTE(RATE_500_HZ, tick) &&
            (getCommanderCtrlMode() & 0x03) != 0x03)
            flyerFlipCheck(&s_setpoint, &s_control, &s_state);

        /* 全速: 异常检测 + PID */
        anomalDetec(&s_sensorData, &s_state, &s_control);
        stateControl(&s_control, &s_sensorData, &s_state, &s_setpoint, tick);

        /* 500Hz: 电机输出 */
        if (RATE_DO_EXECUTE(RATE_500_HZ, tick))
            powerControl(&s_control);

        tick++;
    }
}

void getAttitudeData(attitude_t* get) {
    get->pitch = -s_state.attitude.pitch;
    get->roll  =  s_state.attitude.roll;
    get->yaw   = -s_state.attitude.yaw;
}
float getBaroData(void)              { return s_sensorData.baro.asl; }
/* getSensorData: 优先从 sensor queues 直接读取 (无需等待 stabilizerTask 主循环)
 * 对应原始 getSensorRawData → 确保 ANO ACC/GYR 在校准期间也有数据 */
void  getSensorData(sensorData_t* g) {
    if (!sensorsReadAcc(&g->acc))   g->acc  = s_sensorData.acc;
    if (!sensorsReadGyro(&g->gyro)) g->gyro = s_sensorData.gyro;
    if (!sensorsReadMag(&g->mag))   g->mag  = s_sensorData.mag;
    if (!sensorsReadBaro(&g->baro)) g->baro = s_sensorData.baro;
}
void  getStateData(Axis3f* acc, Axis3f* vel, Axis3f* pos) {
    acc->x=s_state.acc.x;      acc->y=s_state.acc.y;      acc->z=s_state.acc.z;
    vel->x=s_state.velocity.x; vel->y=s_state.velocity.y; vel->z=s_state.velocity.z;
    pos->x=s_state.position.x; pos->y=s_state.position.y; pos->z=s_state.position.z;
}