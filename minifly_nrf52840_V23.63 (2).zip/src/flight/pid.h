/**
 * @file    pid.h
 * @brief   PID 控制器
 *          对应: FLIGHT/interface/pid.h (逐字对照, V1.3)
 *
 * V1.3 改动: PidObject 新增 out 字段记录最终输出
 */
#pragma once
#include <stdbool.h>
#include "../config_param.h"

#define DEFAULT_PID_INTEGRATION_LIMIT  500.0f
#define DEFAULT_PID_OUTPUT_LIMIT         0.0f

typedef struct {
    float desired;
    float error;
    float prevError;
    float integ;
    float deriv;
    float kp;
    float ki;
    float kd;
    float outP;
    float outI;
    float outD;
    float iLimit;
    float outputLimit;
    float dt;
    float out;      /* V1.3 新增 */
    float derivLpf; /* V22.21: D项低通滤波状态 */
    float dAlpha;   /* V22.21: D项低通系数 (由 dt + PID_DTERM_LPF_HZ 算; =1 表示不滤) */
    float prevMeas; /* V22.44: 上次测量值 (D-on-measurement 用) */
    float ffDLpf;   /* V22.61: 设定点微分前馈的低通状态 */
} PidObject;

void  pidInit(PidObject* pid, const float desired, const pidInit_t pidParam, const float dt);
float pidUpdate(PidObject* pid, const float error);
/* V22.44: 传 设定点+测量 的版本, 支持 D-on-measurement(除微分踢) + 前馈。用于角速率内环。 */
float pidUpdateFull(PidObject* pid, const float setpoint, const float meas);
void  pidReset(PidObject* pid);
void  pidSetDesired(PidObject* pid, const float desired);
float pidGetDesired(PidObject* pid);
void  pidSetIntegralLimit(PidObject* pid, const float limit);
void  pidSetOutputLimit(PidObject* pid, const float limit);
void  pidSetError(PidObject* pid, const float error);
void  pidSetKp(PidObject* pid, const float kp);
void  pidSetKi(PidObject* pid, const float ki);
void  pidSetKd(PidObject* pid, const float kd);
void  pidSetDt(PidObject* pid, const float dt);
bool  pidIsActive(PidObject* pid);