/**
 * @file    power_control.h
 * @brief   功率输出控制 (对应 FLIGHT/interface/power_control.h)
 *
 * 混控公式 (与原始固件 power_control.c 完全一致):
 *   s16 r = roll/2,  p = pitch/2
 *   m1 = thrust - r - p + yaw
 *   m2 = thrust - r + p - yaw
 *   m3 = thrust + r + p + yaw
 *   m4 = thrust + r - p - yaw
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "stabilizer_types.h"

typedef struct { uint32_t m1,m2,m3,m4; } motorPWM_t;

void powerControlInit(void);
bool powerControlTest(void);
void powerControl(control_t* control);
void getMotorPWM(motorPWM_t* get);
void setMotorPWM(bool en, uint32_t m1, uint32_t m2, uint32_t m3, uint32_t m4);

uint16_t powerGetLastThrust(void);   /* V23.03: 真实电机油门(混控入口) */
