/**
 * @file    state_control.h
 * @brief   飞行状态控制 (对应 FLIGHT/interface/state_control.h)
 */
#pragma once
#include "stabilizer_types.h"

void stateControlInit(void);
bool stateControlTest(void);
void stateControl(control_t* control, sensorData_t* sensors,
                  state_t* state, setpoint_t* setpoint, uint32_t tick);