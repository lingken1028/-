/**
 * @file    flip.cpp
 * @brief   4D 空翻状态机
 *          对应: FLIGHT/src/flip.c (逐字对照)
 *
 * 状态机: IDLE→SET→SPEED_UP→SLOW_DOWN→PERIOD→FINISHED→REVER_SPEED_UP
 *         (FLIP_ERROR 超时处理)
 *
 * isExitFlip: 进入空翻时=false(关闭电池补偿), 空翻结束1秒后=true
 * fstate: 当前状态序号, 供 state_control.cpp 判断内环模式
 *
 * 移植变化:
 *   CMD_FLIP 指令在 remoter_ctrl.cpp 中被忽略 (无遥控器空翻硬件)
 *   状态机代码保留完整, 可通过 setFlipDir() 触发
 */
#include "flip.h"
#include "../config_param.h"
#include "../communicate/commander.h"
#include <FreeRTOS.h>
#include <task.h>
#include <stdint.h>

#define FLIP_RATE       RATE_500_HZ
#define MID_ANGLE       (180.0f * FLIP_RATE)
#define MAX_FLIP_RATE   1380
#define DELTA_RATE      (30000.0f / MAX_FLIP_RATE)
#define FLIP_TIMEOUT    800
#define SPEED_UP_TIMEOUT 400
#define REVER_SPEEDUP_TIME 160

static enum {
    FLIP_IDLE=0, FLIP_SET, FLIP_SPEED_UP, FLIP_SLOW_DOWN,
    FLIP_PERIOD, FLIP_FINISHED, REVER_SPEED_UP, FLIP_ERROR
} flipState = FLIP_IDLE;

uint8_t  fstate    = 0;
static enum dir_e flipDir = CENTER;
bool     isExitFlip = true;   /* 电池补偿开关 (motors.cpp 引用) */

static uint16_t s_maxRateCnt  = 0;
static float    s_desiredVelZ = 105.0f;
static float    s_curRate     = 0.0f;
static float    s_curAngle    = 0.0f;

void flyerFlipCheck(setpoint_t* sp, control_t* ctrl, state_t* state) {
    static uint16_t flipThrust=0, tempThrust=0, reverTime=0, flipTimeout=0;
    static float pitchTemp=0, rollTemp=0, yawTemp=0, deltaThrust=0;
    static uint16_t exitFlipCnt=0, flipThrustMax=0;

    fstate = (uint8_t)flipState;

    switch (flipState) {
    case FLIP_IDLE:
        if (flipDir != CENTER) {
            if (ctrl->thrust > 28000 && state->velocity.z > -20.0f) {
                flipState   = FLIP_SET;
                exitFlipCnt = 500;
                isExitFlip  = false;
            } else flipDir = CENTER;
        } else if (!isExitFlip) {
            if (exitFlipCnt > 0) exitFlipCnt--;
            else isExitFlip = true;
        }
        break;

    case FLIP_SET:
        s_curRate=0; s_maxRateCnt=0; s_curAngle=0; flipTimeout=0;
        ctrl->flipDir = flipDir;
        flipThrust  = (uint16_t)(-9000.0f + 1.2f*configParam.thrustBase);
        deltaThrust = configParam.thrustBase / 90.0f;
        flipThrustMax = configParam.thrustBase + 20000;
        if (flipThrustMax > 62000) flipThrustMax = 62000;
        tempThrust = flipThrust;
        rollTemp=state->attitude.roll; pitchTemp=state->attitude.pitch; yawTemp=state->attitude.yaw;
        flipState = FLIP_SPEED_UP;
        break;

    case FLIP_SPEED_UP:
        if (state->velocity.z < s_desiredVelZ) {
            sp->mode.z = modeDisable;
            if (tempThrust < flipThrustMax) tempThrust += (uint16_t)deltaThrust;
            sp->thrust = tempThrust;
            if (++flipTimeout > SPEED_UP_TIMEOUT) { flipTimeout=0; flipState=FLIP_SLOW_DOWN; }
        } else { flipTimeout=0; flipState=FLIP_SLOW_DOWN; }
        break;

    case FLIP_SLOW_DOWN:
        if (tempThrust > flipThrust) {
            int td = (int)(6500.0f - flipThrust/10.0f);
            if (tempThrust > td) tempThrust -= td; else tempThrust=0;
            sp->mode.z=modeDisable; sp->thrust=tempThrust;
        } else flipState=FLIP_PERIOD;
        /* fall through */

    case FLIP_PERIOD:
        if (++flipTimeout > FLIP_TIMEOUT) { flipTimeout=0; flipState=FLIP_ERROR; }
        sp->mode.z=modeDisable; sp->thrust=flipThrust - 3*s_curRate;
        s_curAngle += s_curRate;
        if (s_curAngle < MID_ANGLE) {
            if (s_curRate < MAX_FLIP_RATE) s_curRate += DELTA_RATE; else s_maxRateCnt++;
        } else {
            if (s_maxRateCnt > 0) s_maxRateCnt--;
            else {
                if (s_curRate >= DELTA_RATE && s_curAngle < 2*MID_ANGLE) s_curRate -= DELTA_RATE;
                else flipState = FLIP_FINISHED;
            }
        }
        switch (ctrl->flipDir) {
        case FORWARD: sp->attitude.pitch=s_curRate; sp->attitude.roll=state->attitude.roll=rollTemp; sp->attitude.yaw=state->attitude.yaw=yawTemp; break;
        case BACK:    sp->attitude.pitch=-s_curRate; sp->attitude.roll=state->attitude.roll=rollTemp; sp->attitude.yaw=state->attitude.yaw=yawTemp; break;
        case LEFT:    sp->attitude.roll=-s_curRate; sp->attitude.pitch=state->attitude.pitch=pitchTemp; sp->attitude.yaw=state->attitude.yaw=yawTemp; break;
        case RIGHT:   sp->attitude.roll=s_curRate; sp->attitude.pitch=state->attitude.pitch=pitchTemp; sp->attitude.yaw=state->attitude.yaw=yawTemp; break;
        default: break;
        }
        break;

    case FLIP_FINISHED:
        sp->mode.z=modeDisable; sp->thrust=tempThrust; tempThrust=flipThrust;
        reverTime=0; flipTimeout=0; flipDir=CENTER; ctrl->flipDir=CENTER;
        flipState=REVER_SPEED_UP;
        break;

    case REVER_SPEED_UP:
        if (reverTime++ < REVER_SPEEDUP_TIME) {
            if (tempThrust < flipThrustMax) tempThrust += (uint16_t)(2.0f*deltaThrust);
            sp->mode.z=modeDisable; sp->thrust=tempThrust;
        } else { flipTimeout=0; flipState=FLIP_IDLE; }
        break;

    case FLIP_ERROR:
        reverTime=0; flipDir=CENTER; ctrl->flipDir=CENTER;
        sp->mode.z=modeDisable; sp->thrust=0;
        if (++flipTimeout > 1) { flipTimeout=0; flipState=FLIP_IDLE; }
        break;
    default: break;
    }
}

void setFlipDir(uint8_t dir) { flipDir=(enum dir_e)dir; }