/**
 * @file    anomal_detec.h
 * @brief   异常检测 (自由落体 + 碰撞翻倒)
 *          对应: FLIGHT/interface/anomal_detec.h (逐字对照)
 *
 * DETEC_FF_THRESHOLD = 0.05: accZ 接近 -1.0 程度 (Free Fall)
 * DETEC_FF_COUNT     = 50:  连续50次 (1000Hz下 = 50ms)
 * DETEC_TU_THRESHOLD = 60°: 翻倒检测阈值
 * DETEC_TU_COUNT     = 100: 连续100次
 */
#pragma once
#include "stabilizer_types.h"

#define DETEC_ENABLED

#define DETEC_FF_THRESHOLD  0.05f
#define DETEC_FF_COUNT      50
#define DETEC_TU_THRESHOLD  60.0f
#define DETEC_TU_COUNT      100

void anomalDetec(const sensorData_t* sensorData,
                 const state_t* state,
                 const control_t* control);