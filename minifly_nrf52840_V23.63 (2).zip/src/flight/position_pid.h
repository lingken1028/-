/**
 * @file    position_pid.h
 * @brief   位置/定高 PID
 *          原文件: FLIGHT/interface/position_pid.h
 */
#pragma once
#include "pid.h"
#include "stabilizer_types.h"

extern PidObject pidVX, pidVY, pidVZ;
extern PidObject pidX,  pidY,  pidZ;

void  positionControlInit(float rateDt, float posDt);
void  positionResetAllPID(void);
void  positionController(float* thrust, attitude_t* attitude,
                         setpoint_t* setpoint, const state_t* state, float dt);
void  positionPIDwriteToConfigParam(void);
float getAltholdThrust(void);
float getAltholdThrustFast(void);   /* V22.26: 快速油门LPF, 一键降落判停 */