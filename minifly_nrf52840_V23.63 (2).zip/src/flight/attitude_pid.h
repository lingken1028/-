/**
 * @file    attitude_pid.h
 * @brief   姿态双环 PID
 *          原文件: FLIGHT/interface/attitude_pid.h (逐字对照)
 *
 * V1.3 改动: 修正角度环与角速度环积分时间参数错误
 */
#pragma once
#include "pid.h"
#include "stabilizer_types.h"

/* 积分限幅 (对应原始固件宏) */
#define PID_ANGLE_ROLL_ILIMIT    30.0f
#define PID_ANGLE_PITCH_ILIMIT   30.0f
#define PID_ANGLE_YAW_ILIMIT    180.0f
#define PID_RATE_ROLL_ILIMIT    500.0f
#define PID_RATE_PITCH_ILIMIT   500.0f
#define PID_RATE_YAW_ILIMIT      50.0f

extern PidObject pidAngleRoll, pidAnglePitch, pidAngleYaw;
extern PidObject pidRateRoll,  pidRatePitch,  pidRateYaw;

void attitudeControlInit(float rateDt, float angleDt);
bool attitudeControlTest(void);
void attitudeRatePID(Axis3f* actualRate, attitude_t* desiredRate, control_t* output);
void attitudeAnglePID(attitude_t* actualAngle, attitude_t* desiredAngle, attitude_t* outRate);
void attitudeControllerResetRollAttitudePID(void);
void attitudeControllerResetPitchAttitudePID(void);
void attitudeResetAllPID(void);
void attitudePIDwriteToConfigParam(void);