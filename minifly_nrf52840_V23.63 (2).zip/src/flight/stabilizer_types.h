/**
 * @file    stabilizer_types.h
 * @brief   飞行控制数据类型完整定义
 *          对应: FLIGHT/interface/stabilizer_types.h + sensors_types.h (逐字对照)
 *
 * V7 修正:
 *   1. 合并 sensors_types.h (Axis3i16/32/64/Axis3f)
 *   2. sensorData_t 补充 point_t position / zRange_t zrange 字段
 *   3. state_t 补充 attitudeQuaternion / isRCLocked 字段
 *   4. control_t roll/pitch/yaw 为 int16_t (原始固件 s16)
 *   5. RATE_DO_EXECUTE 宏与原始固件完全一致
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>

/* ── sensors_types.h (合并) ── */
typedef union {
    struct { int16_t x, y, z; };
    int16_t axis[3];
} Axis3i16;

typedef union {
    struct { int32_t x, y, z; };
    int32_t axis[3];
} Axis3i32;

typedef union {
    struct { int64_t x, y, z; };
    int64_t axis[3];
} Axis3i64;

typedef union {
    struct { float x, y, z; };
    float axis[3];
} Axis3f;

/* ── 姿态 ── */
typedef struct {
    uint32_t timestamp;
    float roll, pitch, yaw;
} attitude_t;

/* ── 三维向量 (对应 struct vec3_s) ── */
struct vec3_s {
    uint32_t timestamp;
    float x, y, z;
};
typedef struct vec3_s point_t;
typedef struct vec3_s velocity_t;
typedef struct vec3_s acc_t;

/* ── 四元数 ── */
typedef struct {
    uint32_t timestamp;
    union {
        struct { float q0, q1, q2, q3; };
        struct { float x,  y,  z,  w;  };
    };
} quaternion_t;

/* ── 气压计 ── */
typedef struct {
    float pressure;
    float temperature;
    float asl;          /* 海拔高度 m */
} baro_t;

/* ── 激光测距 (zRange, 对应原始 zRange_t) ── */
typedef struct {
    uint32_t timestamp;
    float    distance;  /* 测量距离 cm */
    float    quality;   /* 可信度 0~1 */
} zRange_t;

/* ── 光流 ── */
typedef struct {
    uint32_t timestamp;
    union {
        struct { float dpixelx, dpixely; };
        float dpixel[2];
    };
    float stdDevX, stdDevY, dt;
} flowMeasurement_t;

/* ── 传感器数据 (对应原始 sensorData_t 完整定义) ── */
typedef struct {
    Axis3f  acc;
    Axis3f  gyro;
    Axis3f  mag;       /* AK8963 磁力计 */
    baro_t  baro;
    point_t position;  /* 位置估测 (光流/激光)  */
    zRange_t zrange;   /* 激光测距 */
} sensorData_t;

/* ── 飞行器状态 (对应原始 state_t) ── */
typedef struct {
    attitude_t   attitude;            /* 欧拉角 deg */
    quaternion_t attitudeQuaternion;  /* 四元数 */
    point_t      position;            /* 位置 cm */
    velocity_t   velocity;            /* 速度 cm/s */
    acc_t        acc;                 /* 加速度 cm/s/s */
    bool         isRCLocked;
} state_t;

/* ── 飞行模式 ── */
typedef enum {
    modeDisable  = 0,
    modeAbs      = 1,
    modeVelocity = 2,
} mode_e;

typedef struct {
    mode_e x, y, z;
    mode_e roll, pitch, yaw;
} flt_mode_t;  /* V11: renamed from mode_t to avoid POSIX conflict */

/* ── 翻滚方向 (对应 enum dir_e) ── */
enum dir_e { CENTER=0, FORWARD, BACK, LEFT, RIGHT };

/* ── 控制量 (对应原始 control_t) ── */
typedef struct {
    int16_t     roll;      /* int16 (原始 s16) */
    int16_t     pitch;
    int16_t     yaw;
    float       thrust;
    enum dir_e  flipDir;
} control_t;

/* ── 目标设定 (对应原始 setpoint_t) ── */
typedef struct {
    attitude_t  attitude;      /* deg */
    attitude_t  attitudeRate;  /* deg/s */
    point_t     position;      /* cm */
    velocity_t  velocity;      /* cm/s */
    flt_mode_t  mode;   /* V11 */
    float       thrust;
} setpoint_t;

/* ── 速率宏 (与原始 stabilizer_types.h 完全一致) ── */
#define RATE_5_HZ    5
#define RATE_10_HZ   10
#define RATE_25_HZ   25
#define RATE_50_HZ   50
#define RATE_100_HZ  100
#define RATE_200_HZ  200
#define RATE_250_HZ  250
#define RATE_500_HZ  500
#define RATE_1000_HZ 1000

#define MAIN_LOOP_RATE   RATE_1000_HZ
#define MAIN_LOOP_DT_MS  1u   /* ms */

#define RATE_DO_EXECUTE(RATE_HZ, TICK) \
    (((TICK) % (MAIN_LOOP_RATE / (RATE_HZ))) == 0)

/* ── 时间常数 (对应原始 stabilizer.h) ── */
#define ATTITUDE_ESTIMAT_RATE  RATE_250_HZ
#define ATTITUDE_ESTIMAT_DT    (1.0f/RATE_250_HZ)
#define POSITION_ESTIMAT_RATE  RATE_250_HZ
#define POSITION_ESTIMAT_DT    (1.0f/RATE_250_HZ)
#define RATE_PID_RATE          RATE_500_HZ
#define RATE_PID_DT            (1.0f/RATE_500_HZ)
#define ANGEL_PID_RATE         RATE_250_HZ
#define ANGEL_PID_DT           (1.0f/RATE_250_HZ)
#define VELOCITY_PID_RATE      RATE_250_HZ
#define VELOCITY_PID_DT        (1.0f/RATE_250_HZ)
#define POSITION_PID_RATE      RATE_250_HZ
#define POSITION_PID_DT        (1.0f/RATE_250_HZ)