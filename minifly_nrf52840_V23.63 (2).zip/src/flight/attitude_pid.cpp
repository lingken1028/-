/**
 * @file    attitude_pid.cpp
 * @brief   姿态双环 PID 实现
 *          对应: FLIGHT/src/attitude_pid.c (V1.3 逐字对照)
 *
 * V7 修正:
 *   积分限幅完全对照原始:
 *     角度环: roll/pitch=30.0, yaw=180.0
 *     角速度环: roll/pitch=500.0, yaw=50.0
 *   attitudePIDwriteToConfigParam: 全部9个 PID 参数写回
 */
#include "attitude_pid.h"
#include "../config_param.h"
#include <stdint.h>
#include <limits.h>

/* 积分限幅 (对应原始宏, 逐字对照) */
#define PID_ANGLE_ROLL_INTEGRATION_LIMIT    30.0f
#define PID_ANGLE_PITCH_INTEGRATION_LIMIT   30.0f
#define PID_ANGLE_YAW_INTEGRATION_LIMIT    180.0f
#define PID_RATE_ROLL_INTEGRATION_LIMIT    500.0f
#define PID_RATE_PITCH_INTEGRATION_LIMIT   500.0f
#define PID_RATE_YAW_INTEGRATION_LIMIT      50.0f

PidObject pidAngleRoll, pidAnglePitch, pidAngleYaw;
PidObject pidRateRoll,  pidRatePitch,  pidRateYaw;

/* 对应原始 pidOutLimit() */
static inline int16_t pidOutLimit(float in) {
    if (in > (float)INT16_MAX) return  INT16_MAX;
    if (in < -(float)INT16_MAX) return -INT16_MAX;
    return (int16_t)in;
}

/* 对应原始 attitudeControlInit(ratePidDt, anglePidDt) */
void attitudeControlInit(float ratePidDt, float anglePidDt) {
    pidInit(&pidAngleRoll,  0, configParam.pidAngle.roll,  anglePidDt);
    pidInit(&pidAnglePitch, 0, configParam.pidAngle.pitch, anglePidDt);
    pidInit(&pidAngleYaw,   0, configParam.pidAngle.yaw,   anglePidDt);
    pidSetIntegralLimit(&pidAngleRoll,  PID_ANGLE_ROLL_INTEGRATION_LIMIT);
    pidSetIntegralLimit(&pidAnglePitch, PID_ANGLE_PITCH_INTEGRATION_LIMIT);
    pidSetIntegralLimit(&pidAngleYaw,   PID_ANGLE_YAW_INTEGRATION_LIMIT);

    pidInit(&pidRateRoll,  0, configParam.pidRate.roll,  ratePidDt);
    pidInit(&pidRatePitch, 0, configParam.pidRate.pitch, ratePidDt);
    pidInit(&pidRateYaw,   0, configParam.pidRate.yaw,   ratePidDt);
    pidSetIntegralLimit(&pidRateRoll,  PID_RATE_ROLL_INTEGRATION_LIMIT);
    pidSetIntegralLimit(&pidRatePitch, PID_RATE_PITCH_INTEGRATION_LIMIT);
    pidSetIntegralLimit(&pidRateYaw,   PID_RATE_YAW_INTEGRATION_LIMIT);
    /* V22.93: 给速率环设输出限幅=32767 — 下游 pidOutLimit 本来就钳在±32767, 所以【行为零改变】;
     * 唯一作用是让 V22.36 的条件抗积分饱和真正生效(原 outputLimit=0 → (outputLimit!=0)恒假 → 休眠)。
     * 受益者主要是偏航速率(唯一 ki≠0 的姿态PID): 高油门电机饱和时偏航积分不再windup → 油门降下来不过冲打转。 */
    pidSetOutputLimit(&pidRateRoll,  32767.0f);
    pidSetOutputLimit(&pidRatePitch, 32767.0f);
    pidSetOutputLimit(&pidRateYaw,   32767.0f);
}

bool attitudeControlTest(void) { return true; }

/* 角速度环 (内环, 500Hz) */
void attitudeRatePID(Axis3f* actualRate, attitude_t* desiredRate, control_t* out) {
    /* V22.44: 用 pidUpdateFull(设定点, 测量) → D-on-measurement 除微分踢 + 可选前馈 */
    out->roll  = pidOutLimit(pidUpdateFull(&pidRateRoll,  desiredRate->roll,  actualRate->x));
    out->pitch = pidOutLimit(pidUpdateFull(&pidRatePitch, desiredRate->pitch, actualRate->y));
    out->yaw   = pidOutLimit(pidUpdateFull(&pidRateYaw,   desiredRate->yaw,   actualRate->z));
}

/* 角度环 (外环, 250Hz) */
void attitudeAnglePID(attitude_t* actualAngle, attitude_t* desiredAngle, attitude_t* outRate) {
    outRate->roll  = pidUpdate(&pidAngleRoll,  desiredAngle->roll  - actualAngle->roll);
    outRate->pitch = pidUpdate(&pidAnglePitch, desiredAngle->pitch - actualAngle->pitch);

    float yawErr = desiredAngle->yaw - actualAngle->yaw;
    if (yawErr >  180.0f) yawErr -= 360.0f;
    if (yawErr < -180.0f) yawErr += 360.0f;
    outRate->yaw = pidUpdate(&pidAngleYaw, yawErr);
}

void attitudeControllerResetRollAttitudePID(void)  { pidReset(&pidAngleRoll); }
void attitudeControllerResetPitchAttitudePID(void) { pidReset(&pidAnglePitch); }

void attitudeResetAllPID(void) {
    pidReset(&pidAngleRoll);  pidReset(&pidRateRoll);
    pidReset(&pidAnglePitch); pidReset(&pidRatePitch);
    pidReset(&pidAngleYaw);   pidReset(&pidRateYaw);
}

/* 将当前 PID 参数写回 configParam (对应原始, 全部9个) */
void attitudePIDwriteToConfigParam(void) {
    configParam.pidAngle.roll.kp=pidAngleRoll.kp; configParam.pidAngle.roll.ki=pidAngleRoll.ki; configParam.pidAngle.roll.kd=pidAngleRoll.kd;
    configParam.pidAngle.pitch.kp=pidAnglePitch.kp; configParam.pidAngle.pitch.ki=pidAnglePitch.ki; configParam.pidAngle.pitch.kd=pidAnglePitch.kd;
    configParam.pidAngle.yaw.kp=pidAngleYaw.kp; configParam.pidAngle.yaw.ki=pidAngleYaw.ki; configParam.pidAngle.yaw.kd=pidAngleYaw.kd;
    configParam.pidRate.roll.kp=pidRateRoll.kp; configParam.pidRate.roll.ki=pidRateRoll.ki; configParam.pidRate.roll.kd=pidRateRoll.kd;
    configParam.pidRate.pitch.kp=pidRatePitch.kp; configParam.pidRate.pitch.ki=pidRatePitch.ki; configParam.pidRate.pitch.kd=pidRatePitch.kd;
    configParam.pidRate.yaw.kp=pidRateYaw.kp; configParam.pidRate.yaw.ki=pidRateYaw.ki; configParam.pidRate.yaw.kd=pidRateYaw.kd;
}