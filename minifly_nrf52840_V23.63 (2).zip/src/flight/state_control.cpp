/**
 * @file    state_control.cpp
 * @brief   飞行状态控制
 *          对应: FLIGHT/src/state_control.c (V1.3 逐字对照)
 *
 * V7 精确修正:
 *   YAW 期望: attitudeDesired.yaw += setpoint->attitude.yaw / ANGEL_PID_RATE
 *   微调: attitudeDesired.roll += configParam.trimR (在 attitudeAnglePID 之前)
 *         attitudeDesired.pitch += configParam.trimP
 *   thrust < 5: 清空 roll/pitch/yaw, 复位所有PID, 复位 yaw,
 *               每 1500 次触发 configParamGiveSemaphore()
 *   空翻支持: control->flipDir!=CENTER && fstate==4 → 内环直接用 setpoint
 */
#include "state_control.h"
#include "attitude_pid.h"
#include "position_pid.h"
#include "../config.h"
#include "../config_param.h"
#include "../communicate/commander.h"   /* V22.75: commanderGetRcTrimR/P — 遥控器实时trim */

/* V22.90: 前置声明 — 6DOF(板载LSM6单用)用独立trim(装的位置和GY-91不同) */
bool sensorsUsingOnboardIMU(void);
uint16_t powerGetLastThrust(void);   /* V23.03: 油门补偿用真实油门 */

/* 声明 flip 状态变量 (定义在 flip.cpp) */
extern uint8_t fstate;

static float     s_actualThrust  = 0.0f;
static attitude_t s_attDes       = {0};
static attitude_t s_rateDes      = {0};

void stateControlInit(void) {
    attitudeControlInit(RATE_PID_DT, ANGEL_PID_DT);
    positionControlInit(VELOCITY_PID_DT, POSITION_PID_DT);
}

bool stateControlTest(void) { return attitudeControlTest(); }

/* ══════════════════════════════════════════════════════════════
 * 【段落】stateControl — 串级三环的调度台
 *   这段做了什么: ① 位置环250Hz(任一轴mode非Disable才跑, 产出油门+期望姿态)
 *   ② 角度环250Hz: modeDisable时油门=摇杆直通; yaw期望按速率积分±180回绕;
 *      trim叠加(V23.22统一configParam+遥控实时); 油门-姿态线性补偿(V22.78);
 *      → 角度PID产出期望角速度  ③ 角速度环500Hz(空翻期只用内环) → 力矩
 *   ④ thrust<5 落地复位块: 清力矩+全PID复位+期望yaw对齐+1500拍触发参数保存
 *   — 这就是"落地后一切归位"的生态源头。
 * ══════════════════════════════════════════════════════════════ */
void stateControl(control_t* ctrl, sensorData_t* sensors,
                  state_t* state, setpoint_t* sp, uint32_t tick) {
    static uint16_t cnt = 0;

    /* 位置环 250Hz */
    if (RATE_DO_EXECUTE(POSITION_PID_RATE, tick)) {
        if (sp->mode.x!=modeDisable || sp->mode.y!=modeDisable || sp->mode.z!=modeDisable) {
            positionController(&s_actualThrust, &s_attDes, sp, state, POSITION_PID_DT);
        }
    }

    /* 角度环 (外环) 250Hz */
    if (RATE_DO_EXECUTE(ANGEL_PID_RATE, tick)) {
        if (sp->mode.z == modeDisable) s_actualThrust = sp->thrust;

        if (sp->mode.x==modeDisable || sp->mode.y==modeDisable) {
            s_attDes.roll  = sp->attitude.roll;
            s_attDes.pitch = sp->attitude.pitch;
        }

        /* YAW 速率模式: 期望 yaw 累积积分 */
        if (ctrl->flipDir == CENTER) {
            s_attDes.yaw += sp->attitude.yaw / (float)ANGEL_PID_RATE;
            if (s_attDes.yaw >  180.0f) s_attDes.yaw -= 360.0f;
            if (s_attDes.yaw < -180.0f) s_attDes.yaw += 360.0f;
        }

        /* 微调叠加 (在 anglePID 之前) — V23.22: 删除6DOF独立trim分支, 统一用 configParam.trim。
         * 原因: 原分支按"是否纯LSM6"切两套trim, 但① 融合模式(GY-91主)与纯LSM6会用不同trim源 →
         * 换模式姿态跳; ② 用户上位机校准的trim存进configParam, 纯LSM6时却被独立trim(=0)覆盖 → "校准没用"。
         * 统一后: 所有模式都用 configParam.trim + 遥控器实时trim, 行为一致、校准一定生效。 */
        s_attDes.roll  += configParam.trimR + commanderGetRcTrimR();
        s_attDes.pitch += configParam.trimP + commanderGetRcTrimP();

#if THROTTLE_TRIM_ENABLE
        /* V22.78: 油门-姿态补偿 — 抵消"水平漂移随油门变"(姿态估计的水平参考随油门线性偏移)。
         * 补偿量 = 斜率 × (当前油门 - 悬停参考)/10000。默认斜率0 = 不改变行为。
         * 只补线性分量; 非线性/气流那部分仍需光流才能根治。 */
        {
            float thrD = ((float)powerGetLastThrust() - (float)THROTTLE_TRIM_REF) / 10000.0f;   /* V23.03: 真实油门(定高档摇杆中位≠油门) */
            s_attDes.roll  += THROTTLE_TRIM_SLOPE_R * thrD;
            s_attDes.pitch += THROTTLE_TRIM_SLOPE_P * thrD;
        }
#endif

        attitudeAnglePID(&state->attitude, &s_attDes, &s_rateDes);
    }

    /* 角速度环 (内环) 500Hz */
    if (RATE_DO_EXECUTE(RATE_PID_RATE, tick)) {
        if (sp->mode.roll == modeVelocity) {
            s_rateDes.roll = sp->attitudeRate.roll;
            attitudeControllerResetRollAttitudePID();
        }
        if (sp->mode.pitch == modeVelocity) {
            s_rateDes.pitch = sp->attitudeRate.pitch;
            attitudeControllerResetPitchAttitudePID();
        }

        /* 空翻过程 (fstate==4=FLIP_PERIOD) 只用内环 */
        if (ctrl->flipDir != CENTER && fstate == 4) {
            s_rateDes.pitch = sp->attitude.pitch;
            s_rateDes.roll  = sp->attitude.roll;
        }

        attitudeRatePID(&sensors->gyro, &s_rateDes, ctrl);
    }

    ctrl->thrust = s_actualThrust;

    /* thrust < 5: 清零, 复位所有PID */
    if (ctrl->thrust < 5.0f) {
        ctrl->roll = ctrl->pitch = ctrl->yaw = 0;
        attitudeResetAllPID();
        positionResetAllPID();
        s_attDes.yaw = state->attitude.yaw;   /* 复位期望 yaw */

        if (++cnt > 1500) {
            cnt = 0;
            configParamGiveSemaphore();   /* 触发参数保存 */
        }
    } else {
        cnt = 0;
    }
}