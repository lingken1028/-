/**
 * @file    state_estimator.cpp
 * @brief   INAV 位置/高度估测
 *          对应: FLIGHT/src/state_estimator.c (V1.3)
 *
 * ╔══════════════════════════════════════════════════════════╗
 * ║  V13 CLEAN VERSION — NO position PID functions          ║
 * ║  本文件只包含高度/位置估测, 不含任何 PID 控制器         ║
 * ║  positionControlInit / positionController / pidZ 等      ║
 * ║  均已移入 src/flight/position_pid.cpp                   ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * 本文件只包含:
 *   positionEstimate()  — INAV Z轴气压高度估测 + XY加速积分
 *   getFusedHeight()    — 获取融合后海拔
 *   estRstHeight()      — 复位高度
 *   estRstAll()         — 复位全部估测状态
 *
 * 如果仍报 multiple definition of positionControlInit:
 *   您磁盘上的 state_estimator.cpp 是旧版 (包含 position PID 代码)
 *   请用此文件完整覆盖 src/flight/state_estimator.cpp 后重建
 */
#include "state_estimator.h"
#include "sensors.h"
#include "sensfusion6.h"
#include "../communicate/commander.h"
#include "../config.h"
#include "../common/filter.h"   /* V22.27 #4: 垂直速度 LPF */
#include <math.h>

/* ── INAV 参数 ── */
#define ACC_LIMIT             1000.0f
#define ACC_LIMIT_MAX         1800.0f
#define VELOCITY_LIMIT         130.0f
#define VELOCITY_LIMIT_MAX     500.0f
#define INAV_ACC_BIAS_ACCEPTANCE_VALUE (GRAVITY_CMSS * 0.25f)

uint16_t powerGetLastThrust(void);   /* V23.17: ZUPT需判电机是否停 */

static float wBaro    = BARO_FUSE_WEIGHT;   /* V22.48: 可配置(config.h), 位置校正权重 Kp */
static float wAccBias = 0.01f;
/* V22.72: 速度校正权重 Kv, 由阻尼比 ζ 解耦算出 Kv = wBaro²/(4ζ²)。
 * ζ=0.5 → Kv=wBaro²(旧行为); ζ=0.7 → 近临界, 振铃更少。编译期常量。 */
static float wBaroVel = BARO_FUSE_WEIGHT * BARO_FUSE_WEIGHT
                        / (4.0f * BARO_FUSE_DAMPING * BARO_FUSE_DAMPING);

static bool  s_isRstHeight  = false;
static bool  s_isRstAll     = true;
static float s_fusedHeight  = 0.0f;
static float s_fusedHLpf    = 0.0f;
static float s_startBaroAsl = 0.0f;

/* estimator_t: 在 state_estimator.h 中定义 (已通过 #include 引入) */

static estimator_t est = { .vAccDeadband = 4.0f };

#define AXIS_X 0
#define AXIS_Y 1
#define AXIS_Z 2

static float applyDeadbandF(float v, float db) {
    return (v > db) ? (v - db) : (v < -db) ? (v + db) : 0.0f;
}
static float constrainF(float v, float lo, float hi) {
    return v < lo ? lo : v > hi ? hi : v;
}

static void inavFilterPredict(int ax, float dt, float acc) {
    est.pos[ax] += est.vel[ax] * dt + acc * dt * dt * 0.5f;
    est.vel[ax] += acc * dt;
}
static void inavFilterCorrectPos(int ax, float dt, float e, float wPos, float wVel) {
    est.pos[ax] += e * wPos * dt;   /* 位置校正: Kp */
    est.vel[ax] += e * wVel * dt;   /* 速度校正: Kv(解耦, 控阻尼) */
}

/**
 * positionEstimate — INAV 高度/位置估测
 * 无气压计时清零并直接返回 (getIsBaroPresent() == false)
 */
/* ══════════════════════════════════════════════════════════════
 * 【段落】positionEstimate — INAV 高度融合(气压+加速度互补)
 *   这段做了什么: ① 无气压→全清零返回; 坏读数(NaN)跳过绝不进积分器
 *   ② 3点中值杀单拍尖峰(V23.17) ③ 首个有效asl建基线(V22.38: 防"刚上线
 *   relH≈绝对海拔4万cm"暴冲) ④ 加速度预测(pos+=v·dt+½a·dt²) + 气压误差
 *   双权重校正(Kp位置/Kv速度, V22.72按阻尼比ζ解耦, 减振铃) + 加速度
 *   零偏在线估计 ⑤ ZUPT(电机停时速度钳零) ⑥ 非有限值兜底复位
 *   ⑦ kfl(飞行中)切换限幅档 → velz再过LPF喂给pidVZ。
 * ══════════════════════════════════════════════════════════════ */
void positionEstimate(sensorData_t* sd, state_t* state, float dt) {
    static float accLpf[3] = {0};
    static bool  s_baroBaselineSet = false;   /* V22.38: 气压基线是否已用有效读数建立 */

    if (!getIsBaroPresent()) {
        s_baroBaselineSet = false;            /* 气压丢失 → 回来时用首个有效 asl 重建基线 */
        state->acc.x = state->acc.y = state->acc.z = 0;
        state->velocity.x = state->velocity.y = state->velocity.z = 0;
        state->position.x = state->position.y = state->position.z = 0;
        return;
    }

    /* V22.38: 坏读数(NaN/未就绪)直接跳过本周期, 绝不进积分器, 否则 alt 永久 NaN */
    float asl = sd->baro.asl;
    if (!isfinite(asl)) return;

#if BARO_MEDIAN_ENABLE
    /* V23.17①: 3点中值 — 杀单拍尖峰(GS静置±1m快跳的第一嫌疑; GS显示的s_fusedHLpf是纯气压LPF,
     * 尖峰会直通显示)。延迟=1拍, 对定高动态无感。 */
    {
        static float   s_mbuf[3];
        static uint8_t s_mi = 0, s_mn = 0;
        s_mbuf[s_mi] = asl; s_mi = (uint8_t)((s_mi + 1u) % 3u);
        if (s_mn < 3) s_mn++;
        if (s_mn == 3) {
            float a = s_mbuf[0], b = s_mbuf[1], c = s_mbuf[2];
            asl = (a > b) ? ((b > c) ? b : (a > c ? c : a))
                          : ((a > c) ? a : (b > c ? c : b));
        }
    }
#endif

    /* V22.38: 气压刚上线(开机晚认到/重探/重插)时, 基线还是缺失时的旧值,
     * relH 会瞬间≈绝对海拔(4万多 cm)→ 高度暴冲/积分发散。用首个有效 asl 重建基线, 从 0 起。*/
    if (!s_baroBaselineSet) {
        s_baroBaselineSet   = true;
        s_startBaroAsl      = asl;
        s_fusedHeight       = s_fusedHLpf = 0.0f;
        est.pos[AXIS_Z]     = est.vel[AXIS_Z] = 0.0f;
        est.accBias[AXIS_Z] = 0.0f;
        accLpf[AXIS_Z]      = 0.0f;
    }

    float relH = asl - s_startBaroAsl;
    s_fusedHeight = relH;
    s_fusedHLpf  += (s_fusedHeight - s_fusedHLpf) * 0.1f;

    if (s_isRstHeight) {
        s_isRstHeight  = false;
        s_startBaroAsl = asl;
        s_fusedHeight  = s_fusedHLpf = 0.0f;   /* V22.45 修: 必须归零, 否则下面 pos.z 被设成旧值 → 校准看着没反应 */
        est.pos[AXIS_Z] = 0.0f;                /* V22.45 修: 原为 = s_fusedHeight(校准前的旧 relH) → 高度不归零 */
    } else if (s_isRstAll) {
        s_isRstAll     = false;
        accLpf[AXIS_Z] = 0;
        s_fusedHeight  = s_fusedHLpf = 0;
        s_startBaroAsl = asl;
        est.vel[AXIS_Z] = est.pos[AXIS_Z] = 0;
    }

    Axis3f accelBF;
    accelBF.x = sd->acc.x * GRAVITY_CMSS - est.accBias[AXIS_X];
    accelBF.y = sd->acc.y * GRAVITY_CMSS - est.accBias[AXIS_Y];
    accelBF.z = sd->acc.z * GRAVITY_CMSS - est.accBias[AXIS_Z];
    imuTransformVectorBodyToEarth(&accelBF);

    bool zupt = false;
#if ZUPT_ENABLE
    /* V23.17②: ZUPT静置零速+偏置快学 — 电机停(真实油门=0)且三轴陀螺|ω|<5°/s 持续0.3s判静置:
     * · est.vel[Z] 每拍×0.95 强拉向0(治静置vz=-1..-10踢腿→alt积分漂移);
     * · 用地球系垂直加计残差 accelBF.z 直接快学偏置(0.5/s, 比常规wAccBias=0.01快50倍;
     *   注意用deadband之前的原始残差 — deadband会把小偏置藏起来学不到), 限幅±60cm/s²(≈0.06g)。 */
    {
        static uint16_t s_zuptCnt = 0;
        if (powerGetLastThrust() == 0 &&
            fabsf(sd->gyro.x) < 5.0f && fabsf(sd->gyro.y) < 5.0f && fabsf(sd->gyro.z) < 5.0f) {
            if (s_zuptCnt < 60000u) s_zuptCnt++;
        } else s_zuptCnt = 0;
        if (s_zuptCnt > 75u) {
            zupt = true;
            est.vel[AXIS_Z] *= 0.95f;
            /* V23.20 修: ZUPT只学【垂直】偏置。原来把地球系垂直残差变换回body系后, X/Y/Z三轴都学 →
             * 若静置时机身略倾斜(没放平), 姿态变换的微小误差会让水平残差非零 → 污染X/Y偏置 →
             * 起飞后水平位置带偏置漂移(往一个方向溜)。ZUPT本意只治高度, 只动Z轴偏置最干净。
             * 直接用地球系垂直残差 accelBF.z(静置该≈0, 非0即Z偏置)以0.5/s快学。 */
            est.accBias[AXIS_Z] = constrainF(est.accBias[AXIS_Z] + accelBF.z * 0.5f * dt, -60.0f, 60.0f);
        }
    }
#endif

    est.acc[AXIS_X] = applyDeadbandF(accelBF.x, est.vAccDeadband);
    est.acc[AXIS_Y] = applyDeadbandF(accelBF.y, est.vAccDeadband);
    est.acc[AXIS_Z] = applyDeadbandF(accelBF.z, est.vAccDeadband);
    for (int i = 0; i < 3; i++) accLpf[i] += (est.acc[i] - accLpf[i]) * 0.1f;

    bool kfl = getCommanderKeyFlight() || getCommanderKeyland();
    state->acc.x = constrainF(kfl ? accLpf[AXIS_X] : est.acc[AXIS_X], -ACC_LIMIT_MAX, ACC_LIMIT_MAX);
    state->acc.y = constrainF(kfl ? accLpf[AXIS_Y] : est.acc[AXIS_Y], -ACC_LIMIT_MAX, ACC_LIMIT_MAX);
    state->acc.z = constrainF(kfl ? accLpf[AXIS_Z] : est.acc[AXIS_Z], -ACC_LIMIT_MAX, ACC_LIMIT_MAX);

    float errZ = s_fusedHeight - est.pos[AXIS_Z];
    inavFilterPredict(AXIS_Z, dt, est.acc[AXIS_Z]);
    {
        float wB = wBaro, wV = wBaroVel;
        if (zupt) { wB *= 2.0f; wV *= 4.0f; }   /* V23.17②: 静置贴合加倍(地面快速收敛, 飞行零影响) */
        inavFilterCorrectPos(AXIS_Z, dt, errZ, wB, wV);
    }
    inavFilterPredict(AXIS_X, dt, est.acc[AXIS_X]);
    inavFilterPredict(AXIS_Y, dt, est.acc[AXIS_Y]);

    /* 加速度偏置校正 */
    Axis3f biasCorr = {{0, 0, 0}};
    biasCorr.z -= errZ * (wBaro * wBaro);
    float mag2 = biasCorr.x*biasCorr.x + biasCorr.y*biasCorr.y + biasCorr.z*biasCorr.z;
    if (mag2 < (INAV_ACC_BIAS_ACCEPTANCE_VALUE * INAV_ACC_BIAS_ACCEPTANCE_VALUE)) {
        imuTransformVectorEarthToBody(&biasCorr);
        est.accBias[AXIS_X] += biasCorr.x * wAccBias * dt;
        est.accBias[AXIS_Y] += biasCorr.y * wAccBias * dt;
        est.accBias[AXIS_Z] += biasCorr.z * wAccBias * dt;
    }

    /* V22.38: 兜底 — 万一 Z 积分器出非有限值(理论上已被上面挡住), 复位避免 alt/vz 卡死 */
    if (!isfinite(est.pos[AXIS_Z]) || !isfinite(est.vel[AXIS_Z])) {
        est.pos[AXIS_Z] = est.vel[AXIS_Z] = 0.0f;
        est.accBias[AXIS_Z] = 0.0f;
        s_baroBaselineSet = false;
    }

    float vlim = kfl ? VELOCITY_LIMIT : VELOCITY_LIMIT_MAX;
    state->velocity.x = constrainF(est.vel[AXIS_X], -vlim, vlim);
    state->velocity.y = constrainF(est.vel[AXIS_Y], -vlim, vlim);
    state->velocity.z = constrainF(est.vel[AXIS_Z], -vlim, vlim);
#if ALT_VELZ_LPF_ENABLE
    /* V22.27 #4: 给 pidVZ 更平滑的垂直速度(减少气压噪声驱动的油门抖) */
    {
        static lpf2pData s_velzLpf;
        static bool s_velzInit = false;
        if (!s_velzInit && dt > 0.0f) {
            lpf2pInit(&s_velzLpf, 1.0f / dt, ALT_VELZ_LPF_HZ);
            lpf2pReset(&s_velzLpf, state->velocity.z);
            s_velzInit = true;
        }
        if (s_velzInit) state->velocity.z = lpf2pApply(&s_velzLpf, state->velocity.z);
    }
#endif
    state->position.x = est.pos[AXIS_X];
    state->position.y = est.pos[AXIS_Y];
    state->position.z = est.pos[AXIS_Z];
}

float getFusedHeight(void)  { return s_fusedHLpf; }
void  estRstHeight(void)    { s_isRstHeight = true; }
void  estRstAll(void)       { s_isRstAll    = true; }