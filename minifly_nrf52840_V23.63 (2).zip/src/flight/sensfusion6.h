/**
 * @file    sensfusion6.h
 * @brief   6轴姿态融合 (Mahony 互补滤波)
 *          原文件: FLIGHT/interface/sensfusion6.h
 *          V1.3: 移植自 inav-1.9.0
 */
#pragma once
#include "stabilizer_types.h"
#include <stdbool.h>

extern float Kp;   /* 比例增益 0.4 */
extern float Ki;   /* 积分增益 0.001 */

void imuUpdate(Axis3f acc, Axis3f gyro, Axis3f mag, state_t* state, float dt);
float getMagHeading(void);   /* V22.24: 磁航向(deg) 供验证 */
bool getIsCalibrated(void);
void sensfusionStartLevelCal(void);   /* V22.16: 地面站加速度/6面校准 → 采集静止姿态零偏 */
void sensfusionZeroYaw(void);         /* V22.30: 把当前偏航设为0(保留roll/pitch), USE_MAG_YAW=0时持久 */
void imuTransformVectorBodyToEarth(Axis3f* v);
void imuTransformVectorEarthToBody(Axis3f* v);