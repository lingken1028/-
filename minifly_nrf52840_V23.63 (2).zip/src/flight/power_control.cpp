/**
 * @file    power_control.cpp
 * @brief   功率输出控制
 *          对应: FLIGHT/src/power_control.c (逐字对照)
 *
 * 混控公式 (对应原始):
 *   s16 r = control->roll/2, p = control->pitch/2
 *   m1 = thrust - r - p + yaw
 *   m2 = thrust - r + p - yaw
 *   m3 = thrust + r + p + yaw
 *   m4 = thrust + r - p - yaw
 *   limitThrust(int) → clamp [0, 65535] → u16
 */
#include "power_control.h"
#include "../hardware/motors.h"
#include "../communicate/pm.h"   /* V22.54: pmGetBatteryVoltage 低电压补偿 */
#include "../config_param.h"     /* V22.60: configParam.thrustBase 推力线性化参考 */
#include "../config.h"
#include <stdint.h>

/* V22.88: 前置声明(避免头依赖)。用板载LSM6(无GY-91)时关掉VBAT_COMP/AIRMODE:
 * 这俩会放大姿态修正, 而LSM6无硬件陀螺DLPF、姿态更吵 → 放大后抖。GY-91(主)干净则照常开。 */
bool sensorsUsingOnboardIMU(void);

/* V23.03: 真实电机油门(混控入口的 control->thrust) — 供"在飞/负载/落地/门控"判定统一使用。
 * 病根: 多处拿【摇杆值】当油门代理, 而定高档摇杆中位≠真实油门, 已咬过多次(V22.80/89/23.02)。 */
static uint16_t s_lastCmdThrust = 0;
uint16_t powerGetLastThrust(void) { return s_lastCmdThrust; }

static bool       s_motorSetEnable = false;
static motorPWM_t s_motorPWM;
static motorPWM_t s_motorPWMSet = {0,0,0,0};

void powerControlInit(void) { motorsInit(); }

bool powerControlTest(void) { return motorsTest(); }

/* 对应原始 limitThrust(int value) → u16 */
static uint16_t limitThrust(int value) {
    if (value > 65535) value = 65535;
    if (value < 0)     value = 0;
    return (uint16_t)value;
}

/* powerControl — 对应原始逐字对照 */
/* ══════════════════════════════════════════════════════════════
 * 【段落】powerControl — 力矩到四电机的最后一公里
 *   这段做了什么: ① 记录真实油门(powerGetLastThrust唯一源, V23.03:
 *   全系统"在飞/落地"判定的统一基准) ② r/p/y用int32(V23.21: 两级放大
 *   叠加后int16会溢出反号→电机错乱) ③ VBAT_COMP低压按额定/实压放大
 *   修正(只放大不缩小, 慢滤波) ④ THRUST_LIN推力线性化(参考=自整定base,
 *   低油门放大修正补duty²非线性) ⑤ X型混控 m1..m4 ⑥ AIRMODE缩放式
 *   (修正撞怠速/满幅时按比例缩, 平均油门不变→不扰定高) → 输出PWM。
 * ══════════════════════════════════════════════════════════════ */
void powerControl(control_t* c) {
    s_lastCmdThrust = (uint16_t)c->thrust;   /* V23.03: 记录真实油门 */
    /* V23.21: r/p/y 用 int32 — 原 int16 在 VBAT_COMP(×1.35)+THRUST_LIN(×1.5)叠加放大后, 满舵可能
     * 超 int16 范围(±32767)→ 溢出回绕成反号 → 混控瞬间反向、电机错乱。int32 容纳放大后的值。 */
    int32_t r = (int32_t)(c->roll  / 2.0f);
    int32_t p = (int32_t)(c->pitch / 2.0f);
    int32_t y = (int32_t)c->yaw;

#if VBAT_COMP_ENABLE
    /* V22.54: 低电压姿态权威补偿 — 电池下垂时按 V_NOMINAL/vbat 放大 roll/pitch/yaw 修正,
     * 维持姿态权威。只放大不缩小(满电不动)、只动修正不动油门(不扰定高)、慢滤波vbat(忽略纹波)。 */
    {
        static float s_vb = 0.0f;
        float vb = pmGetBatteryVoltage();
        if (s_vb < 0.5f) s_vb = vb;                  /* 首帧直接置 */
        s_vb += (vb - s_vb) * VBAT_COMP_LPF;         /* 慢LPF, 只跟下垂 */
        if (s_vb > 0.5f) {   /* V22.99: LSM6 恢复补偿 — 你实测无GY-91低压时trim顶满仍持续前飞=权威不够;
                              * 当年关它是为压抖(V22.88), 现噪声已在源头修好(LSM 416Hz+42Hz低通) → 恢复。
                              * 若LSM又抖: 先降 LSM_GYRO_LPF_HZ 42→30, 别再关这个(低压会前飘)。AIRMODE仍按IMU门控。 */
            float vcomp = VBAT_COMP_NOMINAL / s_vb;
            if (vcomp < 1.0f)          vcomp = 1.0f;            /* 只放大 */
            if (vcomp > VBAT_COMP_MAX) vcomp = VBAT_COMP_MAX;   /* 限幅防过补 */
            r = (int32_t)(r * vcomp);
            p = (int32_t)(p * vcomp);
            y = (int32_t)(y * vcomp);
        }
    }
#endif

#if THRUST_LIN_ENABLE
    /* V22.59 算法优化①: 推力线性化 — thrust∝duty², 低油门同PWM修正产生的推力差更小→低油门姿态发软。
     * 按 (参考油门/当前油门) 缩放修正: 低油门放大、高油门缩小 → 各油门段姿态权威一致。
     * 限幅防低油门过放大振荡。只动修正不动油门→不扰定高。与电压补偿独立叠加(各补一种非线性)。 */
    if ((int)c->thrust > 1000) {
        /* V22.60: 参考油门用【自整定悬停油门 thrustBase】而非固定值 → 自动适配电压。
         * 低压时 thrustBase 自动升高, 故低压悬停处 tscale≈1(不再误缩小修正→不削弱低压偏航权威)。 */
        float ref = (float)configParam.thrustBase;
        if (ref < 10000.0f) ref = THRUST_LIN_REF;   /* 未整定时回退固定值 */
        float tscale = ref / (float)c->thrust;
        if (tscale < THRUST_LIN_MIN_SCALE) tscale = THRUST_LIN_MIN_SCALE;
        if (tscale > THRUST_LIN_MAX_SCALE) tscale = THRUST_LIN_MAX_SCALE;
        r = (int32_t)(r * tscale);
        p = (int32_t)(p * tscale);
        y = (int32_t)(y * tscale);
    }
#endif

    int m1 = (int)c->thrust - r - p + y;
    int m2 = (int)c->thrust - r + p - y;
    int m3 = (int)c->thrust + r + p + y;
    int m4 = (int)c->thrust + r - p - y;

#if AIRMODE_ENABLE
    /* V22.58: Air Mode【缩放式】— 修正会把某电机压到怠速以下/顶到满时, 按比例缩小姿态修正,
     * 让电机落进 [怠速, 满]。关键: 【平均油门 = c->thrust 保持不变】→ 不扰定高高度。
     * (旧版"整体平移"会改变平均油门 → 扰高度 → 你反馈不如不开稳, 故改缩放式。)
     * 姿态方向(roll/pitch/yaw 比值)始终保持, 仅在饱和时整体减小幅度。低于门槛(落地/解锁)旁路。 */
    if ((int)c->thrust > AIRMODE_MIN_THRUST && !sensorsUsingOnboardIMU()) {  /* V22.88: LSM6单用时旁路(避免噪声经退饱和缩放抖) */
        int t  = (int)c->thrust;
        int x1 = -r - p + y;          /* 各电机修正分量(不含油门) */
        int x2 = -r + p - y;
        int x3 =  r + p + y;
        int x4 =  r - p - y;
        int loX = x1; if (x2<loX) loX=x2; if (x3<loX) loX=x3; if (x4<loX) loX=x4;
        int hiX = x1; if (x2>hiX) hiX=x2; if (x3>hiX) hiX=x3; if (x4>hiX) hiX=x4;

        /* V22.60 修复低压大旋转: 【顶部(高油门/低压)→ 降油门保住修正】。
         * 低压时悬停油门顶很高→修正会把电机顶到满→偏航(最弱)被钳没→打转。
         * 这里改为降低油门(整体下移)让最高电机=满, 修正幅度全保留→偏航权威不丢。
         * 此时本就是电压不够、该降落, 牺牲高度保姿态最安全。正常油门段不触发(t远低于此)。 */
        if (hiX > 0) {
            int highBound = 65535 - hiX;
            if (t > highBound) {
                t = highBound;
                if (t < AIRMODE_MIN_THRUST) t = AIRMODE_MIN_THRUST;
            }
        }
        /* 底部(低油门)→ 缩放修正(不加油门, 保持下降/不扰高度, 即你认可的V22.58行为)。 */
        int headLo = t - AIRMODE_MOTOR_IDLE;
        if (loX < 0 && (-loX) > headLo && headLo > 0) {
            float scale = (float)headLo / (float)(-loX);
            x1=(int)(x1*scale); x2=(int)(x2*scale); x3=(int)(x3*scale); x4=(int)(x4*scale);
        }
        m1 = t + x1; m2 = t + x2; m3 = t + x3; m4 = t + x4;
    }
#endif

    s_motorPWM.m1 = limitThrust(m1);
    s_motorPWM.m2 = limitThrust(m2);
    s_motorPWM.m3 = limitThrust(m3);
    s_motorPWM.m4 = limitThrust(m4);

    /* ── 电机一致性测试模式 (二者等效, 任一为1即生效) ──
     * ⚠ 卸桨! 绕过混控/自稳, 四个电机一律=油门值, 仅地面验证四电机/接线是否平衡。
     * V22.13: 测试覆盖必须放在软启动之前, 否则会把软启动的渐增结果冲掉。*/
#if (MOTOR_TEST_EQUAL || MOTOR_TEST_EQUAL_MODE)
    {
        uint16_t t = limitThrust((int)c->thrust);
        s_motorPWM.m1 = s_motorPWM.m2 = s_motorPWM.m3 = s_motorPWM.m4 = t;
    }
#endif

#if MOTOR_SOFTSTART_ENABLE
    /* V22.4/13: 全停→上桨 的过渡渐增, 削启动浪涌电流(缓解掉压重启); 转起来后增益=1不影响控制。
     * 放在测试覆盖之后, 这样台架测试模式也能享受软启动。*/
    static float s_soft = 0.0f;
    if (s_motorPWM.m1 == 0 && s_motorPWM.m2 == 0 &&
        s_motorPWM.m3 == 0 && s_motorPWM.m4 == 0) {
        s_soft = 0.0f;                      /* 停桨 → 复位, 为下次上桨做准备 */
    } else if (s_soft < 1.0f) {
        s_soft += MOTOR_SOFTSTART_STEP;
        if (s_soft > 1.0f) s_soft = 1.0f;
        s_motorPWM.m1 = (uint16_t)(s_motorPWM.m1 * s_soft);
        s_motorPWM.m2 = (uint16_t)(s_motorPWM.m2 * s_soft);
        s_motorPWM.m3 = (uint16_t)(s_motorPWM.m3 * s_soft);
        s_motorPWM.m4 = (uint16_t)(s_motorPWM.m4 * s_soft);
    }
#endif

    if (s_motorSetEnable) s_motorPWM = s_motorPWMSet;

    motorsSetRatio(MOTOR_M1, (uint16_t)s_motorPWM.m1);
    motorsSetRatio(MOTOR_M2, (uint16_t)s_motorPWM.m2);
    motorsSetRatio(MOTOR_M3, (uint16_t)s_motorPWM.m3);
    motorsSetRatio(MOTOR_M4, (uint16_t)s_motorPWM.m4);
}

void getMotorPWM(motorPWM_t* get) { *get = s_motorPWM; }

void setMotorPWM(bool en, uint32_t m1, uint32_t m2, uint32_t m3, uint32_t m4) {
    s_motorSetEnable=en;
    s_motorPWMSet.m1=m1; s_motorPWMSet.m2=m2;
    s_motorPWMSet.m3=m3; s_motorPWMSet.m4=m4;
}