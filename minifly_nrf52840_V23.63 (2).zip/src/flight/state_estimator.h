/**
 * @file    state_estimator.h
 * @brief   状态估测
 *          对应: FLIGHT/interface/state_estimator.h (逐字对照)
 */
#pragma once
#include "stabilizer_types.h"

typedef struct {
    float vAccDeadband;
    float accBias[3];
    float acc[3];
    float vel[3];
    float pos[3];
} estimator_t;

void  positionEstimate(sensorData_t* sensorData, state_t* state, float dt);
float getFusedHeight(void);
void  estRstHeight(void);
void  estRstAll(void);