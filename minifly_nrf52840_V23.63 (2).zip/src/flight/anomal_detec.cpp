/**
 * @file    anomal_detec.cpp
 * @brief   异常检测 (自由落体 + 翻倒)
 *          对应: FLIGHT/src/anomal_detec.c (逐字对照)
 *
 * V9: 使用 config.h 的 GRAVITY_CMSS (原来在 state_estimator.cpp 内部定义)
 *
 * detecFreeFall: accZ ≈ -1g 且 accMAG ≈ 0 → 连续50次 → 自由落体
 * detecTumbled:  |roll|或|pitch| > 60° → 连续100次 → 翻倒
 */
#include "anomal_detec.h"
#include "../communicate/commander.h"
#include "stabilizer.h"
#include "../config.h"    /* GRAVITY_CMSS — V9 */
#include <math.h>
#include <stdint.h>

#if defined(DETEC_ENABLED)

static uint16_t s_outFlipCnt = 0;

#if ENABLE_FREEFALL_LAUNCH   /* V22.16: 仅在启用抛飞时才定义, 否则 -Wunused-function 警告 */
static bool detecFreeFall(float accZ, float accMAG) {
    static uint16_t cnt = 0;
    if (fabsf(accMAG) < DETEC_FF_THRESHOLD &&
        fabsf(accZ + 1.0f) < DETEC_FF_THRESHOLD) {
        if (++cnt >= DETEC_FF_COUNT) return true;
    } else cnt = 0;
    return false;
}
#endif

static bool detecTumbled(const state_t* state) {
    static uint16_t cnt = 0;
    float absR = fabsf(state->attitude.roll);
    float absP = fabsf(state->attitude.pitch);
    float fMax = absR >= absP ? absR : absP;
    if (fMax > DETEC_TU_THRESHOLD) {
        if (++cnt >= DETEC_TU_COUNT) return true;
    } else cnt = 0;
    return false;
}
#endif

/* ══【段落】anomalDetec — 每拍安全哨兵: 抛飞检测(编译关)+ 翻倒切电
 * 这段做了什么: flip动作期豁免1000拍; 翻倒判据 |roll|或|pitch|>60°连续
 * 100拍 → 走【裸急停】setCommanderEmerStop(不经缓判, 立即切电, 所有模式
 * 含手动)+清起降键 — 摔机后螺旋桨不空转的保命线。 ══ */
void anomalDetec(const sensorData_t* sd, const state_t* state, const control_t* ctrl) {
#if defined(DETEC_ENABLED)
    if (ctrl->flipDir != CENTER) { s_outFlipCnt = 1000; return; }

#if ENABLE_FREEFALL_LAUNCH
    if (state->isRCLocked == false && getCommanderKeyFlight() == false &&   /* V23.15: 复原V23.14误砍行(在ENABLE_FREEFALL_LAUNCH=0内=死代码无行为影响; 翻倒保护本就无锁定门) */
        (getCommanderCtrlMode() & 0x01) == 0x01) {

        float accMAG = sd->acc.x*sd->acc.x + sd->acc.y*sd->acc.y + sd->acc.z*sd->acc.z;
        /* V9: 使用 GRAVITY_CMSS (来自 config.h), 原来固化 980 */
        if (detecFreeFall(state->acc.z / GRAVITY_CMSS, accMAG)) {
            setCommanderKeyFlight(true);
            setFastAdjustPosParam(35, 10, 0.0f);
        }
    }
#endif

    if (s_outFlipCnt > 0) s_outFlipCnt--;
#if ENABLE_TUMBLE_DISARM
    if (s_outFlipCnt == 0 && detecTumbled(state)) {
        setCommanderEmerStop(true);          /* V22.22: 翻倒→强制切电机(所有模式, 含手动) */
        setCommanderKeyFlight(false);
        setCommanderKeyland(false);
    }
#else
    (void)detecTumbled;
#endif
#else
    (void)sd; (void)state; (void)ctrl;
#endif
}