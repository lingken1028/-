/**
 * @file    sensfusion6.cpp
 * @brief   6轴姿态融合 — Mahony 互补滤波
 *          对应: FLIGHT/src/sensfusion6.c (逐字对照, 移植自 inav-1.9.0)
 *
 * V7 精确修正 (对照原始 sensfusion6.c):
 *   1. calBaseAcc(): 使用 earth-frame Z 分量 accBuf[2] 校准
 *      (原始: accBuf[2] = tempacc.x*rMat[2][0]+tempacc.y*rMat[2][1]+tempacc.z*rMat[2][2])
 *   2. imuTransformVectorBodyToEarth():
 *      步骤: 旋转矩阵变换 → YAW旋转 → v->y 取反 → v->z 减去重力(baseAcc[2]*980)
 *   3. imuTransformVectorEarthToBody():
 *      步骤: 先 v->y=-v->y → 用旋转矩阵转置(行列互换)变换
 *   4. Kp=0.4, Ki=0.001, ACCZ_SAMPLE=350, maxError<0.015
 *   5. 快速开平方 invSqrt (0x5f3759df)
 */
#include "sensfusion6.h"
#include "../communicate/ledseq.h"
#include "../communicate/commander.h"  /* V22.34: commanderGetThrust — 磁修正按油门降增益 */
#include "../config.h"
#include "sensors.h"   /* V22.49: sensorsIsMagCalibrated — 磁偏航融合仅在校准后生效 */
#include <math.h>
uint16_t powerGetLastThrust(void);   /* V23.03: 磁门控用真实油门(摇杆在定高档中位会卡死门控) */
#include <stdint.h>

#define ACCZ_SAMPLE 350

float Kp = MAHONY_KP;     /* V22.56: 暴露到 config.h (悬停慢晃可调) */
float Ki = MAHONY_KI;

static float exInt=0.0f, eyInt=0.0f, ezInt=0.0f;
static float q0=1.0f, q1=0.0f, q2=0.0f, q3=0.0f;
static float rMat[3][3];

static float maxError     = 0.0f;
bool isGravityCalibrated  = false;
static float baseAcc[3]   = {0.0f, 0.0f, 1.0f};

/* V22.16: 水平校准 (消除安装/传感器倾斜偏置, 如"放平却显示PIT=-5.1") */
static float s_pitchOff = 0.0f, s_rollOff = 0.0f;  /* 静止零偏, 从姿态里减掉 */
static int   s_levelCalCnt = -1;                   /* -1=空闲, >=0=正在采集 */
static float s_pSum = 0.0f, s_rSum = 0.0f;
void sensfusionStartLevelCal(void) { s_pSum=0.0f; s_rSum=0.0f; s_levelCalCnt=0; }

/* V22.24: 磁力计算出的水平磁航向(deg), 供心跳显示验证 */
static float s_magHeadingDeg = 0.0f;
float getMagHeading(void) { return s_magHeadingDeg; }

/* 快速开平方倒数 (对应原始 invSqrt) */
static float invSqrt(float x) {
    union { float f; uint32_t i; } u;
    u.f = x;
    u.i = 0x5f3759df - (u.i >> 1);
    u.f *= 1.5f - (x * 0.5f * u.f * u.f);
    return u.f;
}

/* 计算旋转矩阵 (对应 imuComputeRotationMatrix) */
static void computeRotMat(void) {
    float q1q1=q1*q1, q2q2=q2*q2, q3q3=q3*q3;
    float q0q1=q0*q1, q0q2=q0*q2, q0q3=q0*q3;
    float q1q2=q1*q2, q1q3=q1*q3, q2q3=q2*q3;
    rMat[0][0]=1.0f-2.0f*q2q2-2.0f*q3q3; rMat[0][1]=2.0f*(q1q2+-q0q3);  rMat[0][2]=2.0f*(q1q3- -q0q2);
    rMat[1][0]=2.0f*(q1q2- -q0q3);        rMat[1][1]=1.0f-2.0f*q1q1-2.0f*q3q3; rMat[1][2]=2.0f*(q2q3+-q0q1);
    rMat[2][0]=2.0f*(q1q3+ -q0q2);        rMat[2][1]=2.0f*(q2q3- -q0q1);  rMat[2][2]=1.0f-2.0f*q1q1-2.0f*q2q2;
}

/* V22.30: 把当前偏航设为 0(只绕 Z 旋转, 保留 roll/pitch)。
 * 用途: 地面站\"陀螺仪校准\"时一并调用 → 让 yaw 当场归零(你要的\"归零\")。
 * 注意: 仅在 USE_MAG_YAW=0 时持久; 有磁融合时会被磁航向慢慢拉回, 归零不持久。 */
void sensfusionZeroYaw(void) {
    float yaw = atan2f(2.0f*(q1*q2 + q0*q3), q0*q0 + q1*q1 - q2*q2 - q3*q3);
    float c = cosf(yaw * 0.5f), s = sinf(yaw * 0.5f);
    /* q_new = Rz(-yaw) ⊗ q  (左乘地球系 -yaw 旋转, 抵消当前航向) */
    float n0 = c*q0 + s*q3;
    float n1 = c*q1 + s*q2;
    float n2 = c*q2 - s*q1;
    float n3 = c*q3 - s*q0;
    float recip = invSqrt(n0*n0 + n1*n1 + n2*n2 + n3*n3);
    q0 = n0*recip; q1 = n1*recip; q2 = n2*recip; q3 = n3*recip;
    computeRotMat();
    s_magHeadingDeg = 0.0f;
}

/**
 * calBaseAcc — 对应原始 calBaseAcc()
 * 输入 acc[3] 是 earth-frame Z 分量 accBuf[2]（标量，包装成数组传入）
 * 实际只用 acc[2]
 */
static void calBaseAcc(float* acc) {
    static uint16_t cnt = 0;
    static float accZMin = 1.5f, accZMax = 0.5f;
    static float sumAcc[3] = {0.0f};

    for (int i=0;i<3;i++) sumAcc[i] += acc[i];
    if (acc[2] < accZMin) accZMin = acc[2];
    if (acc[2] > accZMax) accZMax = acc[2];

    if (++cnt >= ACCZ_SAMPLE) {
        cnt = 0;
        maxError = accZMax - accZMin;
        accZMin = 1.5f; accZMax = 0.5f;

        if (maxError < 0.015f) {
            for (int i=0;i<3;i++) baseAcc[i] = sumAcc[i] / ACCZ_SAMPLE;
            isGravityCalibrated = true;
            ledseqRun(SYS_LED, seq_calibrated);
        }
        for (int i=0;i<3;i++) sumAcc[i] = 0.0f;
    }
}

/**
 * imuUpdate — 对应原始 imuUpdate()
 * Mahony 互补滤波, 四元数积分, 旋转矩阵计算, 欧拉角输出
 */
void imuUpdate(Axis3f acc, Axis3f gyro, Axis3f mag, state_t* state, float dt) {
    float halfT = 0.5f * dt;
    Axis3f tempacc = acc;

#if BOOT_AUTO_LEVEL_ENABLE
    /* V22.53: 开机自动水平校平 — 等滤波收敛(DELAY秒)+飞机静止后, 自动触发一次水平校准。
     * 复用手动校准入口, 对当前激活的IMU生效 → 换GY-91重启即自动重校 = 自适应。
     * 此处 gyro 还是 deg/s(下面才转rad), 正好用原始角速度判静止。 */
    {
        static float s_bootT = 0.0f;
        static bool  s_bootLvlDone = false;
        if (!s_bootLvlDone) {
            s_bootT += dt;
            if (s_bootT > BOOT_AUTO_LEVEL_DELAY && s_levelCalCnt < 0) {
                float gM = sqrtf(gyro.x*gyro.x + gyro.y*gyro.y + gyro.z*gyro.z);
                if (gM < BOOT_AUTO_LEVEL_STILL_DPS) {   /* 静止 → 触发, 只触发一次 */
                    sensfusionStartLevelCal();
                    s_bootLvlDone = true;
                }
            }
        }
    }
#endif

    gyro.x *= DEG2RAD;
    gyro.y *= DEG2RAD;
    gyro.z *= DEG2RAD;

    if (acc.x!=0.0f || acc.y!=0.0f || acc.z!=0.0f) {
        float accMagSq = acc.x*acc.x + acc.y*acc.y + acc.z*acc.z;  /* 静止≈1.0(g, 已归一) */
        float n = invSqrt(accMagSq);
        acc.x*=n; acc.y*=n; acc.z*=n;

        float kpU = Kp, kiU = Ki;
#if BOOT_KP_BOOST_ENABLE
        /* V22.65: 开机Kp提升 — 滤波器从单位四元数(绝对水平0)起步, 正常Kp(0.3)要~14s才收敛到
         * 加计真实倾角, 导致开机自动校平(3s)抓偏移时还没收敛→等于没校平→pitch显示残留板子倾角。
         * 开机头几秒用高Kp快速收敛到加计水平, 之后降回正常Kp(飞行平滑/抗扰不变)。
         * 只影响roll/pit(加计纠偏), 不动yaw。静止时加计=纯重力, 高Kp安全。 */
        {
            static float s_kpBoostT = 0.0f;
            if (s_kpBoostT < BOOT_KP_BOOST_TIME) {
                s_kpBoostT += dt;
                kpU = BOOT_KP_BOOST_KP;
                kiU = 0.0f;   /* 提升期不积分, 防高Kp下I项超调 */
            }
        }
#endif
#if ACC_REJECT_ENABLE
        /* V22.57: 加速度拒绝 — 合加速度偏离1g(=正在加速/移动)时按比例降低加速度修正,
         * 防"加速度污染姿态"导致【移动时前后/左右晃】。静止(≈1g)时全权重纠偏不受影响。
         * dev≈水平加速度的平方(g²): 0.2g→0.04, 0.3g→0.09, 0.4g→0.16。 */
        float dev = accMagSq - 1.0f; if (dev < 0.0f) dev = -dev;
        float trust = 1.0f - dev * (1.0f / ACC_REJECT_RANGE);
        if (trust < ACC_REJECT_MIN) trust = ACC_REJECT_MIN;
        if (trust > 1.0f)           trust = 1.0f;
        kpU *= trust;   /* V22.65: 改为 *= (在开机提升基础上再按拒绝缩放); 原为 = Kp*trust */
        kiU *= trust;
#endif

        float ex = acc.y*rMat[2][2] - acc.z*rMat[2][1];
        float ey = acc.z*rMat[2][0] - acc.x*rMat[2][2];
        float ez = acc.x*rMat[2][1] - acc.y*rMat[2][0];

        exInt += kiU * ex * dt;
        eyInt += kiU * ey * dt;
        ezInt += kiU * ez * dt;
        /* V22.92: 积分限幅 — 防持续机动/异常时积分windup把姿态推歪(原来无任何限幅)。 */
        if (exInt >  MAHONY_KI_LIMIT) exInt =  MAHONY_KI_LIMIT; else if (exInt < -MAHONY_KI_LIMIT) exInt = -MAHONY_KI_LIMIT;
        if (eyInt >  MAHONY_KI_LIMIT) eyInt =  MAHONY_KI_LIMIT; else if (eyInt < -MAHONY_KI_LIMIT) eyInt = -MAHONY_KI_LIMIT;
        if (ezInt >  MAHONY_KI_LIMIT) ezInt =  MAHONY_KI_LIMIT; else if (ezInt < -MAHONY_KI_LIMIT) ezInt = -MAHONY_KI_LIMIT;

        gyro.x += kpU*ex + exInt;
        gyro.y += kpU*ey + eyInt;
        gyro.z += kpU*ez + ezInt;
    }

#if USE_MAG_YAW
    /* ── 磁力计偏航校正 (V22.24) ──
     * 仅 GY-91(有AK8963)时 mag 非零。用【上一周期 rMat 的 roll/pitch】做倾斜补偿求磁航向,
     * 把估计偏航(estYaw)往磁航向(magYaw)拉 → 绝对航向、消除 yaw 漂移。
     * ★只改 gyro.z, 完全不动 roll/pitch 的加速度融合(保护已调好的姿态)。
     * 符号(MAG_YAW_SIGN)若反 → 静止时 yaw 会自己跑飞, 卸桨看 magYaw=/Y= 验证后改。 */
    if (mag.x!=0.0f || mag.y!=0.0f || mag.z!=0.0f) {
        float spv = rMat[2][0]; if (spv>1.0f) spv=1.0f; if (spv<-1.0f) spv=-1.0f;
        float pitchR = -asinf(spv);
        float rollR  =  atan2f(rMat[2][1], rMat[2][2]);
        float cr=cosf(rollR), sr=sinf(rollR), cpc=cosf(pitchR), spc=sinf(pitchR);
        /* 倾斜补偿到水平面 */
        float hX = mag.x*cpc + mag.y*sr*spc + mag.z*cr*spc;
        float hY = mag.y*cr - mag.z*sr;
        float magYaw = atan2f(-hY, hX);
        float estYaw = atan2f(rMat[1][0], rMat[0][0]);
        float yerr = magYaw - estYaw;
        while (yerr >  3.14159265f) yerr -= 6.28318531f;
        while (yerr < -3.14159265f) yerr += 6.28318531f;
        s_magHeadingDeg = magYaw * RAD2DEG;   /* 始终更新航向显示 */
        /* V22.64: 磁偏航修正只要【已校准】就生效(不再限无头模式) —— 用户要求有磁力计就启用绝对航向消yaw漂。
         *  · 已校准: 用磁航向修正 yaw(各模式都生效)。命令偏航转动时磁航向跟着转, yerr仍小→不打架; 仅消静态漂移。
         *  · 未校准: 退回纯陀螺(硬磁偏置会让magYaw恒定锁死yaw, 故必须先校准; magcal≠100 提示去校准)。
         *  · 油门门控(下行)在高油门时降低磁修正权重, 抗电机磁场干扰。 */
        if (sensorsIsMagCalibrated()) {
            /* V22.34: 油门越高电机磁场干扰越大 → 降低磁修正增益(多信陀螺)。*/
            float thrFrac = (float)powerGetLastThrust() / 65535.0f;
            float gate = 1.0f - thrFrac * MAG_YAW_THR_GATE;
            if (gate < MAG_YAW_GATE_MIN) gate = MAG_YAW_GATE_MIN;   /* V22.76: 地板改宏(0.1), 让高油门磁权重能压到15% */
            gyro.z += (float)(MAG_YAW_SIGN) * MAG_YAW_KP * gate * yerr;
        }
    }
#else
    (void)mag;
#endif

    float q0L=q0, q1L=q1, q2L=q2, q3L=q3;
    q0 += (-q1L*gyro.x - q2L*gyro.y - q3L*gyro.z)*halfT;
    q1 += ( q0L*gyro.x + q2L*gyro.z - q3L*gyro.y)*halfT;
    q2 += ( q0L*gyro.y - q1L*gyro.z + q3L*gyro.x)*halfT;
    q3 += ( q0L*gyro.z + q1L*gyro.y - q2L*gyro.x)*halfT;

    float n = invSqrt(q0*q0+q1*q1+q2*q2+q3*q3);
    q0*=n; q1*=n; q2*=n; q3*=n;

    computeRotMat();

    /* 欧拉角 (对应原始) */
    float sp = rMat[2][0];
    if (sp >  1.0f) sp =  1.0f;
    if (sp < -1.0f) sp = -1.0f;
    /* V22.16: 水平校准 — 采集静止时的 pitch/roll 做零偏, 之后从姿态里减掉。
     * 修"放平却显示PIT=-5.1"造成的角度环偏置 (M1/M3 在定高被拉到MIN以下而不转)。 */
    float rawYaw   =  atan2f(rMat[1][0], rMat[0][0]) * RAD2DEG;
    float rawPitch = -asinf(sp) * RAD2DEG;
    float rawRoll  =  atan2f(rMat[2][1], rMat[2][2]) * RAD2DEG;

    /* V22.79: NaN 护栏 — 万一四元数/rMat 异常导致欧拉角非有限, 保持上次姿态, 绝不把 NaN
     * 传给控制器(否则电机指令变垃圾)。正常运行欧拉角永远 finite → 无副作用。 */
    if (isfinite(rawYaw) && isfinite(rawPitch) && isfinite(rawRoll)) {
        state->attitude.yaw = rawYaw;
        if (s_levelCalCnt >= 0) {
            s_pSum += rawPitch; s_rSum += rawRoll;
            if (++s_levelCalCnt >= 200) {
                float po = s_pSum / (float)s_levelCalCnt;
                float ro = s_rSum / (float)s_levelCalCnt;
                s_levelCalCnt = -1;
                /* V22.53: 倾斜保护 — 零偏过大说明开机/校准时没放平, 放弃避免学进歪零点 */
                if (po <= BOOT_AUTO_LEVEL_MAX_TILT && po >= -BOOT_AUTO_LEVEL_MAX_TILT &&
                    ro <= BOOT_AUTO_LEVEL_MAX_TILT && ro >= -BOOT_AUTO_LEVEL_MAX_TILT) {
                    s_pitchOff = po;
                    s_rollOff  = ro;
                    ledseqRun(SYS_LED, seq_calibrated);
                }
            }
        }
        state->attitude.pitch = rawPitch - s_pitchOff;
        state->attitude.roll  = rawRoll  - s_rollOff;
    }

    /* 姿态速率 (deg/s) */
    state->attitudeQuaternion.q0 = q0;
    state->attitudeQuaternion.q1 = q1;
    state->attitudeQuaternion.q2 = q2;
    state->attitudeQuaternion.q3 = q3;

    /* calBaseAcc: 使用 earth-frame Z 分量 (对应原始 accBuf[2]) */
    if (!isGravityCalibrated) {
        float accBuf[3] = {0.0f};
        /* accBuf[2] = tempacc · rMat[2] */
        accBuf[2] = tempacc.x*rMat[2][0] + tempacc.y*rMat[2][1] + tempacc.z*rMat[2][2];
        calBaseAcc(accBuf);
    }
}

bool getIsCalibrated(void) {
#if FORCE_CANFLY
    return true;   /* V22.11: 关键! 同时放行 stabilizer.cpp 第135行的 setpoint 门,
                    * 否则遥控器虽发了油门(thr 有值)但 commanderGetSetpoint 不执行
                    * → s_setpoint.thrust 一直 0 → 电机不转。真飞行改回 0。 */
#else
    return isGravityCalibrated;
#endif
}

/**
 * imuTransformVectorBodyToEarth — 对应原始 (含 YAW旋转 + 重力去除)
 *
 * 原始实现:
 *   x = rMat*v_body (全旋转矩阵)
 *   yawRad = atan2(rMat[1][0],rMat[0][0])
 *   vx = x_e*cosy + y_e*siny
 *   vy = y_e*cosy - x_e*siny
 *   v->x = vx
 *   v->y = -vy   ← 取反!
 *   v->z = z_e - baseAcc[2]*980  ← 减重力加速度(单位cm/s/s)
 */
void imuTransformVectorBodyToEarth(Axis3f* v) {
    const float x_e = rMat[0][0]*v->x + rMat[0][1]*v->y + rMat[0][2]*v->z;
    const float y_e = rMat[1][0]*v->x + rMat[1][1]*v->y + rMat[1][2]*v->z;
    const float z_e = rMat[2][0]*v->x + rMat[2][1]*v->y + rMat[2][2]*v->z;

    float yawRad = atan2f(rMat[1][0], rMat[0][0]);
    float cosy = cosf(yawRad), siny = sinf(yawRad);

    float vx =  x_e*cosy + y_e*siny;
    float vy =  y_e*cosy - x_e*siny;

    v->x =  vx;
    v->y = -vy;            /* 取反 (对应原始 v->y = -vy) */
    v->z =  z_e - baseAcc[2] * 980.0f;  /* 去除重力加速度 cm/s/s */
}

/**
 * imuTransformVectorEarthToBody — 对应原始
 * 先 v->y=-v->y, 再用旋转矩阵转置乘
 */
void imuTransformVectorEarthToBody(Axis3f* v) {
    v->y = -v->y;   /* 对应原始第一行 */
    const float x = rMat[0][0]*v->x + rMat[1][0]*v->y + rMat[2][0]*v->z;
    const float y = rMat[0][1]*v->x + rMat[1][1]*v->y + rMat[2][1]*v->z;
    const float z = rMat[0][2]*v->x + rMat[1][2]*v->y + rMat[2][2]*v->z;
    v->x=x; v->y=y; v->z=z;
}