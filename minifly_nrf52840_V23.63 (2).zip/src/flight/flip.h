/**
 * @file    flip.h
 * @brief   4D 空翻控制
 *          对应: FLIGHT/interface/flip.h (逐字对照)
 *
 * isExitFlip: 定义在 flip.cpp, 被 motors.cpp 引用
 *             true = 已退出空翻 → 电池补偿激活
 *             false = 空翻中 → 关闭电池补偿
 */
#pragma once
#include "stabilizer_types.h"

extern bool     isExitFlip;
extern uint8_t  fstate;

void flyerFlipCheck(setpoint_t* setpoint, control_t* control, state_t* state);
void setFlipDir(uint8_t dir);