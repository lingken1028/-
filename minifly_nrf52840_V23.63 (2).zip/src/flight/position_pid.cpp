/**
 * @file    position_pid.cpp
 * @brief   位置/速度 PID 实现
 *          对应: FLIGHT/src/position_pid.c (V1.3 逐字对照)
 *
 * V7 精确修正:
 *   THRUST_BASE = 20000 (本地常量, 非 configParam.thrustBase)
 *   velocityController:
 *     attitude.pitch = 0.15 * pidUpdate(pidVX, vx_err)  ← 0.15 系数
 *     attitude.roll  = 0.15 * pidUpdate(pidVY, vy_err)  ← 0.15 系数
 *     thrust = constrainf(pidVZ_out + THRUST_BASE, 1000, 60000)
 *     thrustLpf 低通 α=0.003
 *     当 keyFlight==true && |accZ|<35 持续 1000 次 → 更新 configParam.thrustBase
 *   positionController:
 *     velocity.x = 0.1 * pidUpdate(pidX, x_err)  ← 0.1 系数
 *     velocity.y = 0.1 * pidUpdate(pidY, y_err)
 */
#include "position_pid.h"
#include "../config_param.h"
#include "../config.h"     /* V22.33: ALTHOLD_TAKEOFF_CLIMB / ALTHOLD_THRUST_SLEW */
#include "../communicate/commander.h"
#include <math.h>

/* 本地基础油门 (对应原始 #define THRUST_BASE 20000)
 * V22.15: 20000(≈30%)对原版小机够, 但你的机(XIAO+GY-91+机架)更重, 起飞时电机起转太慢
 *         → 定高"起不了飞"。提到 28000(≈43%)给更足的起飞底油门。
 * ★这是定高最关键的可调值★: 起飞还是上不去就加大(每次 +2000~3000);
 *   一上桨就猛窜就调小。手动模式不受此值影响。 */
#define THRUST_BASE_LOCAL  28000

/* 速度环输出限幅 */
#define PIDVX_OUTPUT_LIMIT  120.0f
#define PIDVY_OUTPUT_LIMIT  120.0f
#define PIDVZ_OUTPUT_LIMIT  40000.0f

/* 位置环输出限幅 */
#define PIDX_OUTPUT_LIMIT   1200.0f
#define PIDY_OUTPUT_LIMIT   1200.0f
#define PIDZ_OUTPUT_LIMIT   ALTHOLD_TAKEOFF_CLIMB  /* V22.33: 一键起飞爬升限速(原120, 改可配, 默认60更柔) */

static float thrustLpf = THRUST_BASE_LOCAL;
static float thrustLpfFast = THRUST_BASE_LOCAL;   /* V22.26: 快速油门LPF, 供一键降落快速判停 */

PidObject pidVX, pidVY, pidVZ;
PidObject pidX,  pidY,  pidZ;

/* 对应原始 constrainf */
static inline float constrainf(float v, float lo, float hi) {
    return v < lo ? lo : v > hi ? hi : v;
}

void positionControlInit(float velDt, float posDt) {
    pidInit(&pidVX, 0, configParam.pidPos.vx, velDt);
    pidInit(&pidVY, 0, configParam.pidPos.vy, velDt);
    pidInit(&pidVZ, 0, configParam.pidPos.vz, velDt);
    pidSetOutputLimit(&pidVX, PIDVX_OUTPUT_LIMIT);
    pidSetOutputLimit(&pidVY, PIDVY_OUTPUT_LIMIT);
    pidSetOutputLimit(&pidVZ, PIDVZ_OUTPUT_LIMIT);

    pidInit(&pidX, 0, configParam.pidPos.x, posDt);
    pidInit(&pidY, 0, configParam.pidPos.y, posDt);
    pidInit(&pidZ, 0, configParam.pidPos.z, posDt);
    pidSetOutputLimit(&pidX, PIDX_OUTPUT_LIMIT);
    pidSetOutputLimit(&pidY, PIDY_OUTPUT_LIMIT);
    pidSetOutputLimit(&pidZ, PIDZ_OUTPUT_LIMIT);
}

/* velocityController — 对应原始 (逐行对照) */
/* ══════════════════════════════════════════════════════════════
 * 【段落】velocityController — 速度环: 定高油门的产房
 *   这段做了什么: 水平速度→期望姿态(0.15系数); 垂直速度PID+加速度前馈
 *   (V22.62干净阻尼)+自整定悬停基准 → 钳位[1000,60000] → slew限变率
 *   (磨平突变) → 双LPF(慢α=0.003=自整定学习源 / 快α=0.05=baroLoss开环起点)
 *   → thrustBase四重闸自整定(V23.19: 在飞+垂直近静+速度近静+值域合理,
 *   防冲天极端油门被学进base的正反馈污染) → 【双零门】keyFlight=0且
 *   keyLand=0时油门强制0(九版战役"立即掉落"的机械死因即此门, 失联保护
 *   必须走keyFlight/keyLand通道才能绕开)。
 * ══════════════════════════════════════════════════════════════ */
static void velocityController(float* thrust, attitude_t* attitude,
                                setpoint_t* setpoint, const state_t* state) {
    static uint16_t altholdCount = 0;
#if ALTHOLD_THRUST_SLEW_ENABLE
    static float s_thrustSlew = 0.0f;   /* V22.33: slew后的油门(限变化率) */
#endif

    /* 水平速度 → 期望姿态 (0.15 系数) */
    attitude->pitch = 0.15f * pidUpdate(&pidVX, setpoint->velocity.x - state->velocity.x);
    attitude->roll  = 0.15f * pidUpdate(&pidVY, setpoint->velocity.y - state->velocity.y);

    /* 垂直速度 → 油门
     * V22.15: 基准油门改用 configParam.thrustBase(默认34000≈52%, 起飞后悬停自整定),
     *   对应原版 altholdPID 的 posPid.thrustBase。之前用本地 28000(≈43%) 偏低, 一键起飞推力
     *   不足以离地 → "定高起不了飞"。 */
    float thrustRaw    = pidUpdate(&pidVZ, setpoint->velocity.z - state->velocity.z);
#if ALTHOLD_ACC_FF_ENABLE
    /* V22.62 算法③: 直接垂直加速度前馈(干净阻尼)。与VZ的D项同号(已验证稳定的阻尼方向):
     * acc.z>0(向上加速)→减油门; acc.z<0(向下加速/被往下压)→加油门 → 抑制垂直运动 = 更稳的定高、更快抗扰。
     * 用估计器已滤波的 acc.z(cm/s²), 比差分含气压噪声的vz更干净。 */
    thrustRaw += -ALTHOLD_ACC_FF_GAIN * state->acc.z;
#endif
    float thrustTarget = constrainf(thrustRaw + (float)configParam.thrustBase, 1000.0f, 60000.0f);

#if ALTHOLD_THRUST_SLEW_ENABLE
    /* V22.33: 限制油门每周期变化量 → 磨平突变(起飞从0平顺爬升, 减少俯仰瞬态)。 */
    float d = thrustTarget - s_thrustSlew;
    if (d >  ALTHOLD_THRUST_SLEW) d =  ALTHOLD_THRUST_SLEW;
    if (d < -ALTHOLD_THRUST_SLEW) d = -ALTHOLD_THRUST_SLEW;
    s_thrustSlew += d;
    *thrust = s_thrustSlew;
#else
    *thrust = thrustTarget;
#endif

    thrustLpf += (*thrust - thrustLpf) * 0.003f;
    thrustLpfFast += (*thrust - thrustLpfFast) * 0.05f;   /* V22.26: ~快10倍, 落地判停用 */

    /* 定高飞行时自动更新 configParam.thrustBase(悬停油门自整定)。
     * V23.19 加固: 只有【真正稳定悬停】才学 — 否则冲天/俯冲时的极端油门会被写进base → 下次起飞
     * 用错误高值更易冲天(正反馈污染, 与估计器基线中毒同型)。三重闸:
     *   ① keyFlight在飞 ② |acc.z|<35(垂直近静) ③ |vz|<15(速度近静, 真悬停不是路过)
     *   ④ 学到的值必须落在合理悬停区[20000,50000], 极端油门直接拒收。 */
    if (getCommanderKeyFlight()) {
        if (fabsf(state->acc.z) < 35.0f && fabsf(state->velocity.z) < 15.0f) {
            if (++altholdCount > 1000) {
                altholdCount = 0;
                if (thrustLpf > 20000.0f && thrustLpf < 50000.0f &&
                    fabsf((float)configParam.thrustBase - thrustLpf) > 1000.0f)
                    configParam.thrustBase = (uint16_t)thrustLpf;
            }
        } else altholdCount = 0;
    } else if (!getCommanderKeyland()) {
        *thrust = 0.0f;
#if ALTHOLD_THRUST_SLEW_ENABLE
        s_thrustSlew = 0.0f;   /* V22.33: 未飞行/降落 → 复位, 下次起飞从0平顺起 */
#endif
    }
}

/* positionController — 对应原始 (0.1 系数) */
void positionController(float* thrust, attitude_t* attitude,
                        setpoint_t* setpoint, const state_t* state, float dt) {
    if (setpoint->mode.x == modeAbs || setpoint->mode.y == modeAbs) {
        setpoint->velocity.x = 0.1f * pidUpdate(&pidX, setpoint->position.x - state->position.x);
        setpoint->velocity.y = 0.1f * pidUpdate(&pidY, setpoint->position.y - state->position.y);
    }
    if (setpoint->mode.z == modeAbs) {
        setpoint->velocity.z = pidUpdate(&pidZ, setpoint->position.z - state->position.z);
    }
    velocityController(thrust, attitude, setpoint, state);
}

float getAltholdThrust(void) { return thrustLpf; }
float getAltholdThrustFast(void) { return thrustLpfFast; }   /* V22.26 */

void positionResetAllPID(void) {
    pidReset(&pidVX); pidReset(&pidVY); pidReset(&pidVZ);
    pidReset(&pidX);  pidReset(&pidY);  pidReset(&pidZ);
}

void positionPIDwriteToConfigParam(void) {
    configParam.pidPos.vx.kp=pidVX.kp; configParam.pidPos.vx.ki=pidVX.ki; configParam.pidPos.vx.kd=pidVX.kd;
    configParam.pidPos.vy.kp=pidVY.kp; configParam.pidPos.vy.ki=pidVY.ki; configParam.pidPos.vy.kd=pidVY.kd;
    configParam.pidPos.vz.kp=pidVZ.kp; configParam.pidPos.vz.ki=pidVZ.ki; configParam.pidPos.vz.kd=pidVZ.kd;
    configParam.pidPos.x.kp=pidX.kp;   configParam.pidPos.x.ki=pidX.ki;   configParam.pidPos.x.kd=pidX.kd;
    configParam.pidPos.y.kp=pidY.kp;   configParam.pidPos.y.ki=pidY.ki;   configParam.pidPos.y.kd=pidY.kd;
    configParam.pidPos.z.kp=pidZ.kp;   configParam.pidPos.z.ki=pidZ.ki;   configParam.pidPos.z.kd=pidZ.kd;
}