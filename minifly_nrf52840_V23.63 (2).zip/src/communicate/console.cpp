/**
 * @file    console.cpp
 * @brief   调试打印通道实现
 *          对应: COMMUNICATE/src/console.c (逐字对照)
 *
 * 原始逻辑:
 *   consolePutchar(): 取信号量 → 写入 messageToPrint →
 *                     换行('\n')或缓冲区满(30字节)时:
 *                     if (radiolinkGetFreeTxQueuePackets()==1) 写入 fullMsg 标记
 *                     radiolinkSendPacket + usblinkSendPacket → 清空缓冲
 *   consolePutcharFromISR(): 中断版本，不发送 (只填缓冲)
 *   consolePuts(): while(*str) consolePutchar(*str++)
 *
 * 移植: isInInterrupt 检测 (SCB->ICSR) → 改为无中断版本
 */
#include "console.h"
#include "atkp.h"
#include "radiolink.h"
#include "usblink.h"
#include <string.h>
#include <FreeRTOS.h>
#include <semphr.h>

static const char fullMsg[] = "<F>\n";
static atkp_t    s_msg;
static SemaphoreHandle_t s_sem  = NULL;
static bool      s_isInit       = false;

void consoleInit(void) {
    if (s_isInit) return;
    s_msg.msgID   = UP_PRINTF;
    s_msg.dataLen = 0;
    s_sem = xSemaphoreCreateBinary();
    xSemaphoreGive(s_sem);
    s_isInit = true;
}

bool consoleTest(void) { return s_isInit; }

/* consolePutchar — 对应原始 consolePutchar() */
int consolePutchar(int ch) {
    if (!s_isInit) return 0;
    if (xSemaphoreTake(s_sem, portMAX_DELAY) != pdTRUE) return 0;

    if (s_msg.dataLen < ATKP_MAX_DATA_SIZE) {
        s_msg.data[s_msg.dataLen++] = (uint8_t)ch;
    }

    if (ch == 0x0A  /* '\n' */ || s_msg.dataLen >= ATKP_MAX_DATA_SIZE) {
        /* 如果 radiolink tx队列快满，插入溢出标记 */
        if (radiolinkGetFreeTxQueuePackets() == 1) {
            int fl = sizeof(fullMsg);
            for (int i=0; i<fl && s_msg.dataLen > 0; i++)
                s_msg.data[s_msg.dataLen-i] = (uint8_t)fullMsg[fl-i-1];
        }
        radiolinkSendPacket(&s_msg);
        usblinkSendPacket(&s_msg);
        s_msg.dataLen = 0;
    }

    xSemaphoreGive(s_sem);
    return (uint8_t)ch;
}

/* consolePutcharFromISR — 对应原始（简化：仅写缓冲，不发送）*/
int consolePutcharFromISR(int ch) {
    BaseType_t hp = pdFALSE;
    if (xSemaphoreTakeFromISR(s_sem, &hp) == pdTRUE) {
        if (s_msg.dataLen < ATKP_MAX_DATA_SIZE)
            s_msg.data[s_msg.dataLen++] = (uint8_t)ch;
        xSemaphoreGiveFromISR(s_sem, &hp);
    }
    return ch;
}

int consolePuts(char* str) {
    int ret = 0;
    while (*str) ret |= consolePutchar(*str++);
    return ret;
}