/**
 * @file    atkp.cpp
 * @brief   ATKP 协议 V15.22 — 对照原版 F411 atkp.c 重建
 *
 * 架构 (对应原版 PDF §2.2):
 *   atkpTxTask:   atkpSendPeriod → usblinkSendPacket(txQueue)
 *   atkpRxAnlTask: xQueueReceive(atkpRxQueue) → 处理 DOWN 包
 *   USB TX/RX:    完全由 usblink.cpp 的两个独立任务管理
 *
 * 原版 getusbConnectState() → V15: if(Serial) 直接判断
 * 连接后立刻发送 UP_STATUS (无需等 DOWN 包) — 对应原版行为
 */
#include "atkp.h"
#include "usblink.h"
#include "radiolink.h"
#include "commander.h"
#include "remoter_ctrl.h"
#include "../config.h"
#include "../config_param.h"
#include "../flight/stabilizer.h"
#include "../flight/sensors.h"
#include "../flight/state_estimator.h"   /* V22.18: estRstHeight (气压校准→当前高度清零) */
#include "../flight/sensfusion6.h"   /* V22.16: sensfusionStartLevelCal (地面站加速度/6面校准) */
#include "../flight/attitude_pid.h"
#include "../flight/position_pid.h"
#include "../flight/power_control.h"
#include "../flight/stabilizer_types.h"
#include "pm.h"
#include <string.h>
#include <stdint.h>
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

QueueHandle_t atkpRxQueue     = NULL;
QueueHandle_t radiolinkTxQueue = NULL;

/* joystickFlyui16_t: 对应原始 atkp.c 内部定义 */
typedef struct { uint16_t roll; uint16_t pitch; uint16_t yaw; uint16_t thrust; } joystickFlyui16_t;
static joystickFlyui16_t s_rcdata = {};

/* ── 内部工具 ─────────────────────────────────────────────── */

/* atkpSendPacket: 对应原版 atkpSendPacket
 * 同时发给无线(radio)和USB(usblink)
 * 原版条件: getusbConnectState() → V15: Serial */
static void atkpSendPacket(const atkp_t* p) {
    /* ══ V23.42: 无线ACK通道瘦身 ══
     * 手持遥控器只需要 电量(UP_POWER)/信号(UP_RADIO)/握手(UP_REMOTER)。
     * 重遥测(姿态UP_STATUS/传感器UP_SENSER/电机UP_MOTOR ≈150包/秒)只走USB给电脑地面站,
     * 不再挤占 ACK 带宽 —— 否则电压包(10/秒)被挤掉, 遥控器电量不显示;
     * 且后台点名(私有轮询频率低)时 ACK 队列拥堵会更严重。 */
    /* V23.46: 回传队列积压保护 ——
     * 广播点名时 ACK 约每秒才排空1个, 而 UP_POWER 每100ms入队(10/秒),
     * 30深队列约3秒填满; 之后遥控器每次点名取到的都是队首那包几十秒前的旧值
     * → 表现为"飞机电量更新极慢"。故队列已有积压时跳过本次电压入队,
     *   保证遥控器取到的永远是新鲜值(丢掉的旧值本来也没人要)。
     * 私有模式排空快(~91次/秒), 队列常空, 行为不变。 */
    bool skipRadio = (p->msgID == UP_POWER) && radiolinkTxQueue &&
                     (uxQueueMessagesWaiting(radiolinkTxQueue) >= 2);
    if (!skipRadio &&
        (p->msgID == UP_POWER || p->msgID == UP_REMOTER || p->msgID == UP_RADIO))
        radiolinkSendPacket(p);   /* 无线: 仅精简状态搭ACK回传 */
    usblinkSendPacket(p);         /* USB: 全部遥测(电脑地面站, 不受上面限流影响) */
}

/* ── sendPid: 对应原版 sendPid ─────────────────────────────── */
static void sendPid(uint8_t group,
    float p1p, float p1i, float p1d,
    float p2p, float p2i, float p2d,
    float p3p, float p3i, float p3d)
{
    atkp_t p; p.msgID = (upmsgID_e)(UP_PID1 + group - 1); p.dataLen = 18;
    auto put = [&](uint8_t* d, float v) {
        int16_t iv = (int16_t)(v * 10.0f);
        d[0] = iv>>8; d[1] = iv&0xFF;
    };
    put(p.data+ 0,p1p); put(p.data+ 2,p1i); put(p.data+ 4,p1d);
    put(p.data+ 6,p2p); put(p.data+ 8,p2i); put(p.data+10,p2d);
    put(p.data+12,p3p); put(p.data+14,p3i); put(p.data+16,p3d);
    atkpSendPacket(&p);
}

/* ── sendCheck: 对应原版 sendCheck ────────────────────────── */
static uint8_t atkpCheckSum(const atkp_t* pk) {
    uint8_t s = DOWN_BYTE1+DOWN_BYTE2+pk->msgID+pk->dataLen;
    for (int i=0; i<pk->dataLen; i++) s += pk->data[i];
    return s;
}
static void sendCheck(uint8_t head, uint8_t cs) {
    atkp_t p; p.msgID = UP_CHECK; p.dataLen = 2;
    p.data[0] = head; p.data[1] = cs;
    atkpSendPacket(&p);
}

/* ── sendVersion: 对应原版 D_ACK_READ_VERSION → UP_VERSION ── */
static void sendVersion(void) {
    atkp_t p; p.msgID = UP_VERSION; p.dataLen = 9;
    p.data[0]=4;
    uint16_t hw=130, sw=130, prot=400, boot=0;
    p.data[1]=hw>>8;   p.data[2]=hw&0xFF;
    p.data[3]=sw>>8;   p.data[4]=sw&0xFF;
    p.data[5]=prot>>8; p.data[6]=prot&0xFF;
    p.data[7]=boot>>8; p.data[8]=boot&0xFF;
    atkpSendPacket(&p);
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】atkpReceiveAnl — 所有"下行指令"的总分拣台
 *   这段做了什么: 按 msgID 分五路 —
 *   DOWN_COMMAND: 解锁/上锁 + 五种校准(加速度/陀螺/气压/罗盘), V22.18 起
 *                 每条都回 UP_CHECK 回执(原厂这里是空的, 上位机点了"没反应")
 *                 【D22】0xF1 运行时失控模式切换将来加在这里的新 case
 *   DOWN_ACK:     地面站"读取"请求 → 回 6 组 PID / 版本号
 *   DOWN_RCDATA:  PC 摇杆数据 → 存 s_rcdata(消费者待查, 见 D25)
 *   DOWN_REMOTER: 遥控器指令帧 → 转交 remoter_ctrl 翻译
 *   DOWN_PID1-6:  地面站写 PID(×10定点还原) → 写入运行参数, PID6=存Flash
 * ══════════════════════════════════════════════════════════════ */
static bool s_flyable = false;   /* 对应原版 flyable 标志 */

static void atkpReceiveAnl(const atkp_t* pk) {
    const uint8_t* p = pk->data;
    uint8_t dl = pk->dataLen;

    if (pk->msgID == DOWN_COMMAND) {
        if (dl < 1) return;
        if      (p[0] == D_COMMAND_FLIGHT_ULOCK) {
            /* V23.37 D39: PC解锁前必须过IMU自检门 — 遥控器路径靠 getIsCalibrated 挡,
             * 但PC路径(s_flyable)原本无门, 无IMU时也会显示"已解锁"(误导), 且将来PC控制链
             * 接通后会变成"无IMU也能武装"的真隐患。现在: 无IMU(sensorsTest=false)拒绝解锁,
             * s_flyable保持false, 上位机据回执得知失败。双机PC演示的安全前提。 */
            if (sensorsTest()) s_flyable = true;
            else               s_flyable = false;   /* 无IMU: 拒绝解锁 */
        }
        else if (p[0] == D_COMMAND_FLIGHT_LOCK)  s_flyable = false;
        /* V22.16/18: 地面站传感器校准 (放平静止时点击) */
        else if (p[0] == D_COMMAND_ACC_CALIB)    sensfusionStartLevelCal();   /* 加速度/6面校准 → 采集静止姿态零偏, 消除 PIT/ROL 固定偏差 */
        else if (p[0] == D_COMMAND_GYRO_CALIB)  { sensorsRecalibrateGyro(); sensfusionZeroYaw(); }  /* 陀螺仪校准 → 重采零偏 + V22.30: yaw 归零 */
        else if (p[0] == D_COMMAND_BARO_CALIB)   estRstHeight();              /* V22.18: 气压计校准 → 以当前气压高度为 0 参考 */
        else if (p[0] == D_COMMAND_MAG_CALIB)    { sensorsStartMagCal(); sensfusionZeroYaw(); }      /* V22.24/30: 罗盘校准 → 采min/max + yaw 归零 */
        /* D_COMMAND_MAG_CALIB: V22.24 起做硬/软磁标定(USE_MAG_YAW 时用于9轴偏航融合,
         * 给 yaw 绝对航向参考)。校准时水平转圈采 min/max。 */

        /* V22.18: 回 UP_CHECK ACK —— 上位机据此显示"命令已收到/校准成功"。
         * (原版 DOWN_COMMAND 各 case 为空且不回 ACK, 所以原版点校准也"没反应";
         *  这里补上 ACK + 实际效果, 让陀螺/气压/罗盘校准在上位机有响应。) */
        sendCheck(pk->msgID, atkpCheckSum(pk));

    } else if (pk->msgID == DOWN_ACK) {
        if (dl < 1) return;
        if (p[0] == D_ACK_READ_PID) {   /* 0x01 读取飞控 PID */
            sendPid(1, configParam.pidRate.roll.kp,  configParam.pidRate.roll.ki,  configParam.pidRate.roll.kd,
                       configParam.pidRate.pitch.kp, configParam.pidRate.pitch.ki, configParam.pidRate.pitch.kd,
                       configParam.pidRate.yaw.kp,   configParam.pidRate.yaw.ki,   configParam.pidRate.yaw.kd);
            vTaskDelay(pdMS_TO_TICKS(5));
            sendPid(2, configParam.pidAngle.roll.kp,  configParam.pidAngle.roll.ki,  configParam.pidAngle.roll.kd,
                       configParam.pidAngle.pitch.kp, configParam.pidAngle.pitch.ki, configParam.pidAngle.pitch.kd,
                       configParam.pidAngle.yaw.kp,   configParam.pidAngle.yaw.ki,   configParam.pidAngle.yaw.kd);
            vTaskDelay(pdMS_TO_TICKS(5));
            sendPid(3, configParam.pidPos.vz.kp, configParam.pidPos.vz.ki, configParam.pidPos.vz.kd,
                       configParam.pidPos.z.kp,  configParam.pidPos.z.ki,  configParam.pidPos.z.kd,
                       configParam.pidPos.vx.kp, configParam.pidPos.vx.ki, configParam.pidPos.vx.kd);
            vTaskDelay(pdMS_TO_TICKS(5));
            sendPid(4, 0,0,0, 0,0,0, 0,0,0);
            vTaskDelay(pdMS_TO_TICKS(5));
            sendPid(5, 0,0,0, 0,0,0, 0,0,0);
            vTaskDelay(pdMS_TO_TICKS(5));
            sendPid(6, 0,0,0, 0,0,0, 0,0,0);
        } else if (p[0] == D_ACK_READ_VERSION) {  /* 0xA0 */
            sendVersion();
        }

    } else if (pk->msgID == DOWN_RCDATA) {
        if (dl >= (int)sizeof(s_rcdata))
            memcpy(&s_rcdata, p, sizeof(s_rcdata));

    } else if (pk->msgID == DOWN_REMOTER) {
        remoterCtrlProcess((atkp_t*)pk);

    } else if (pk->msgID == DOWN_BCAST_MULTI) {
        bcastMultiProcess((atkp_t*)pk);   /* V23.39: 打包广播, 取自己ID那段 */

    } else if (pk->msgID == DOWN_PID1 || pk->msgID == DOWN_PID2 ||
               pk->msgID == DOWN_PID3 || pk->msgID == DOWN_PID4 ||
               pk->msgID == DOWN_PID5 || pk->msgID == DOWN_PID6) {
        /* 对应原版: kp = 0.1*(s16)(data[0]<<8|data[1]) */
        auto g16 = [&](int i) -> float {
            if (dl < 2*(i+1)) return 0.0f;
            return (float)(int16_t)((p[2*i]<<8)|p[2*i+1]) / 10.0f;
        };
        switch ((downmsgID_e)pk->msgID) {
        case DOWN_PID1:
            pidSetKp(&pidRateRoll,g16(0)); pidSetKi(&pidRateRoll,g16(1)); pidSetKd(&pidRateRoll,g16(2));
            pidSetKp(&pidRatePitch,g16(3)); pidSetKi(&pidRatePitch,g16(4)); pidSetKd(&pidRatePitch,g16(5));
            pidSetKp(&pidRateYaw,g16(6)); pidSetKi(&pidRateYaw,g16(7)); pidSetKd(&pidRateYaw,g16(8));
            break;
        case DOWN_PID2:
            pidSetKp(&pidAngleRoll,g16(0)); pidSetKi(&pidAngleRoll,g16(1)); pidSetKd(&pidAngleRoll,g16(2));
            pidSetKp(&pidAnglePitch,g16(3)); pidSetKi(&pidAnglePitch,g16(4)); pidSetKd(&pidAnglePitch,g16(5));
            pidSetKp(&pidAngleYaw,g16(6)); pidSetKi(&pidAngleYaw,g16(7)); pidSetKd(&pidAngleYaw,g16(8));
            break;
        case DOWN_PID3:
            pidSetKp(&pidVZ,g16(0)); pidSetKi(&pidVZ,g16(1)); pidSetKd(&pidVZ,g16(2));
            pidSetKp(&pidZ,g16(3));  pidSetKi(&pidZ,g16(4));  pidSetKd(&pidZ,g16(5));
            pidSetKp(&pidVX,g16(6)); pidSetKi(&pidVX,g16(7)); pidSetKd(&pidVX,g16(8));
            pidVY = pidVX;
            break;
        case DOWN_PID4:
            pidSetKp(&pidX,g16(0)); pidSetKi(&pidX,g16(1)); pidSetKd(&pidX,g16(2));
            pidY = pidX;
            break;
        case DOWN_PID6:
            attitudePIDwriteToConfigParam();
            positionPIDwriteToConfigParam();
            saveConfigAndNotify();
            break;
        default: break;
        }
        sendCheck(pk->msgID, atkpCheckSum(pk));
    }
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】atkpSendPeriod — 遥测"四条流水线"(1ms 心跳分频)
 *   这段做了什么: 用 count_ms 取模, 按四种周期打包上报 —
 *   UP_STATUS 30ms: 姿态×100 + 相对高度(V22.47: 绝对海拔→相对, 修"八楼96.9m")
 *                   + 飞行模式/解锁状态(V22.16: 遥控器解锁也算)
 *   UP_SENSER 10ms: 加速度/陀螺/磁力计原始值(定点系数与原厂一致)
 *   UP_MOTOR  40ms: 四电机油门‰化
 *   UP_POWER 100ms: 电压(V22.15 夹取防乱值)
 *   每包经 atkpSendPacket 双路: 无线(搭ACK) + USB(不看DTR, V17)
 * ══════════════════════════════════════════════════════════════ */
/* ── atkpSendPeriod: 对应原版 atkpSendPeriod ───────────────────
 * 1ms 循环 + count_ms 计数, 对应原版完全一致
 * STATUS 30ms, SENSER 10ms, MOTOR 40ms, POWER 100ms           */
static void atkpSendPeriod(void) {
    static uint16_t count_ms = 1;

    /* UP_STATUS 30ms */
    if (!(count_ms % 30)) {
        attitude_t att; getAttitudeData(&att);
        /* V22.1 修复:
         *  1) 高度: getBaroData() 已是 cm (sensors.cpp 里 *100 过), 原版
         *     UP_STATUS 直接传 cm, 旧版又 *100 → 上位机/遥控器高度被放大100倍
         *  2) pitch/yaw: getAttitudeData() 已含负号(pitch=-state, yaw=-state),
         *     旧版再取一次负 → 上报姿态 pitch/yaw 反向。这里改回与原版一致 */
        /* V22.47: 上报【相对高度】getFusedHeight() 而非绝对海拔 getBaroData()。
         *  原来发绝对ASL → 八楼显示96.9m(=台中地面海拔+楼高), 且气压校准(estRstHeight归零相对基准)
         *  对绝对值无效 → 上位机点校准"没反应"。改发相对高度: 开机/校准后≈0, 上下移动跟随, 校准即时归零。
         *  单位仍是 cm(s_fusedHLpf = asl-baseline, 都是cm), 与原 UP_STATUS 一致。*/
        int32_t alt = (int32_t)getFusedHeight();         /* 相对高度 cm */
        int16_t roll  = (int16_t)(att.roll  * 100.0f);
        int16_t pitch = (int16_t)(att.pitch * 100.0f);   /* 不再额外取负 */
        int16_t yaw   = (int16_t)(att.yaw   * 100.0f);   /* 不再额外取负 */
        atkp_t p; p.msgID=UP_STATUS; p.dataLen=12;
        p.data[0]=roll>>8;  p.data[1]=roll&0xFF;
        p.data[2]=pitch>>8; p.data[3]=pitch&0xFF;
        p.data[4]=yaw>>8;   p.data[5]=yaw&0xFF;
        p.data[6]=(alt>>24)&0xFF; p.data[7]=(alt>>16)&0xFF;
        p.data[8]=(alt>>8)&0xFF;  p.data[9]=alt&0xFF;
        /* V22.16:
         *  byte10 = 飞行模式 = 实际控制模式 (之前硬编码0 → 上位机一直"未知")
         *  byte11 = 锁定状态 = 真实解锁状态 (之前只认地面站解锁s_flyable,
         *           遥控器解锁不反映 → 一直显示"锁定")。
         *           1=解锁(armed), 0=锁定。遥控器解锁(!isRCLocked) 或 地面站解锁(s_flyable) 都算解锁。*/
        p.data[10]=getCommanderCtrlMode();
        p.data[11]=(uint8_t)((s_flyable || !commanderGetIsRCLocked()) ? 1 : 0);
        atkpSendPacket(&p);
    }

    /* UP_SENSER 10ms (对应原版 getSensorRawData) */
    if (!(count_ms % 10)) {
        sensorData_t sd; getSensorData(&sd);
        auto p16=[](uint8_t* d,int16_t v){d[0]=v>>8;d[1]=v&0xFF;};
        atkp_t ps; ps.msgID=UP_SENSER; ps.dataLen=18;
        p16(ps.data+ 0,(int16_t)(sd.acc.x /0.00048828f));
        p16(ps.data+ 2,(int16_t)(sd.acc.y /0.00048828f));
        p16(ps.data+ 4,(int16_t)(sd.acc.z /0.00048828f));
        p16(ps.data+ 6,(int16_t)(sd.gyro.x/0.06103516f));
        p16(ps.data+ 8,(int16_t)(sd.gyro.y/0.06103516f));
        p16(ps.data+10,(int16_t)(sd.gyro.z/0.06103516f));
        p16(ps.data+12,(int16_t)(sd.mag.x *666.7f));
        p16(ps.data+14,(int16_t)(sd.mag.y *666.7f));
        p16(ps.data+16,(int16_t)(sd.mag.z *666.7f));
        atkpSendPacket(&ps);
    }

    /* UP_MOTOR 40ms */
    if (!(count_ms % 40)) {
        motorPWM_t m; getMotorPWM(&m);
        atkp_t pm; pm.msgID=UP_MOTOR; pm.dataLen=16;
        auto putm=[&](uint8_t* d,uint32_t v){
            uint16_t r=(uint16_t)((float)v*1000.0f/65535.0f);
            d[0]=r>>8; d[1]=r&0xFF;};
        putm(pm.data+0,m.m1); putm(pm.data+2,m.m2);
        putm(pm.data+4,m.m3); putm(pm.data+6,m.m4);
        for(int i=8;i<16;i++) pm.data[i]=0;
        atkpSendPacket(&pm);
    }

    /* UP_POWER 100ms */
    if (!(count_ms % 100)) {
        atkp_t p; p.msgID=UP_POWER; p.dataLen=4;
        /* V22.15: 上报前夹到合理区间, 防止偶发乱值让遥控器"不显示" */
        float vf = pmGetBatteryVoltage();
        if (vf < BAT_REPORT_MIN) vf = BAT_REPORT_MIN;
        if (vf > BAT_REPORT_MAX) vf = BAT_REPORT_MAX;
        uint16_t v=(uint16_t)(vf*100.0f);
        uint16_t c=500;
        p.data[0]=v>>8; p.data[1]=v&0xFF;
        p.data[2]=c>>8; p.data[3]=c&0xFF;
        atkpSendPacket(&p);
    }

    if (++count_ms >= 65535) count_ms = 1;
}

/* ════════════════════════════════════════════════════════════
 * atkpTxTask: 对应原版 atkpTxTask
 *   sendMsgACK() → 启动时发送给遥控器 (USB场景无效但无害)
 *   atkpSendPeriod() + vTaskDelay(1) → 1ms循环
 * ════════════════════════════════════════════════════════════ */
void atkpTxTask(void* param) {
    (void)param;
    sendMsgACK();   /* 对应原版: 启动时发一次 UP_REMOTER 给遥控器 */
    while (1) {
        atkpSendPeriod();
        vTaskDelay(pdMS_TO_TICKS(1));
    }
}

/* ════════════════════════════════════════════════════════════
 * atkpRxAnlTask: 对应原版 atkpRxAnlTask
 *   xQueueReceive(rxQueue) → atkpReceiveAnl
 *   USB DOWN 包由 usblinkRxTask 解析后推入 atkpRxQueue
 * ════════════════════════════════════════════════════════════ */
void atkpRxAnlTask(void* param) {
    (void)param;
    atkp_t pk;
    while (1) {
        if (xQueueReceive(atkpRxQueue, &pk, portMAX_DELAY) == pdTRUE)
            atkpReceiveAnl(&pk);
    }
}

/* ════════════════════════════════════════════════════════════
 * atkpInit: 创建队列 (对应原版 atkpInit)
 * ════════════════════════════════════════════════════════════ */
void atkpInit(void) {
    static bool isInit = false;
    if (isInit) return;
    atkpRxQueue      = xQueueCreate(10, sizeof(atkp_t));
    radiolinkTxQueue = xQueueCreate(30, sizeof(atkp_t));
    configASSERT(atkpRxQueue && radiolinkTxQueue);
    isInit = true;
}

bool atkpReceivePacketBlocking(atkp_t* p) {
    return atkpRxQueue &&
           xQueueSend(atkpRxQueue, p, portMAX_DELAY) == pdTRUE;
}
