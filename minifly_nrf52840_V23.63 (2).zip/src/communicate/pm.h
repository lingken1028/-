/**
 * @file    pm.h
 * @brief   电源管理
 *          原文件: COMMUNICATE/interface/pm.h (逐字对照)
 *
 * 原始: 电池电压由 nRF51822 通过 syslink 上报 (pmSyslinkUpdate)
 * 移植: nRF52840 D4 ADC 直接测量 (12-bit, 分压比 BAT_DIV_RATIO)
 */
#pragma once
#include <stdbool.h>
#include "atkp.h"

/* 与原始固件完全一致的状态枚举 */
typedef enum { battery, charging, charged, lowPower, shutDown } PMStates;

void  pmInit(void);
bool  pmTest(void);
void  pmTask(void* param);
void  pmSyslinkUpdate(atkp_t* slp);   /* 兼容接口，移植版改用 ADC */
float pmGetBatteryVoltage(void);
int   pmGetRawADC(void);          /* V22.18: 原始 ADC 值 (心跳诊断电池读数) */
bool  getIsLowpower(void);