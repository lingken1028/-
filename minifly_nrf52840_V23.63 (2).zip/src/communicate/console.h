/**
 * @file    console.h
 * @brief   调试打印通道
 *          对应: COMMUNICATE/interface/console.h (逐字对照)
 *
 * consolePutchar: 字符→ messageToPrint 缓冲 → 换行或满30字节时
 *                 通过 radiolinkSendPacket + usblinkSendPacket 发 UP_PRINTF 帧
 */
#pragma once
#include <stdbool.h>
void consoleInit(void);
bool consoleTest(void);
int  consolePutchar(int ch);
int  consolePutcharFromISR(int ch);
int  consolePuts(char* str);