/**
 * @file    remoter_ctrl.h
 * @brief   遥控器控制接口
 *          对应: COMMUNICATE/interface/remoter_ctrl.h (逐字对照 + V9 清理)
 *
 * V9: 明确标注本平台不支持的硬件命令
 *   CMD_FLIP       — 无空翻模式硬件触发 (setFlipDir 保留但 CMD 忽略)
 *   CMD_POWER_MODULE / CMD_LEDRING / CMD_POWER_VL53LXX
 *                  — 无扩展模块 (光流板/LED环/激光), 接收后直接忽略
 */
#pragma once
#include "atkp.h"
#include "../flight/stabilizer_types.h"
#include <stdbool.h>

/* 遥控数据类别 */
typedef enum { REMOTER_CMD=0, REMOTER_DATA=1 } remoterType_e;

/* 下行命令 (V9: 标注本平台支持性) */
#define CMD_GET_MSG        0x01   /* ✓ 支持: 获取飞控状态 */
#define CMD_GET_CANFLY     0x02   /* ✓ 支持: 是否可飞 */
#define CMD_FLIGHT_LAND    0x03   /* ✓ 支持: 起飞/降落 */
#define CMD_EMER_STOP      0x04   /* ✓ 支持: 紧急停机 */
#define CMD_FLIP           0x05   /* ✗ 忽略: 无遥控器空翻触发 */
#define CMD_POWER_MODULE   0x06   /* ✗ 忽略: 无扩展模块 */
#define CMD_LEDRING_EFFECT 0x07   /* ✗ 忽略: 无LED环 */
#define CMD_POWER_VL53LXX  0x08   /* ✗ 忽略: 无激光测距 */

/* 上行报告 */
#define ACK_MSG  0x01

/* 遥控数据结构 */
typedef struct __attribute__((packed)) {
    float roll, pitch, yaw, thrust;
    float trimPitch, trimRoll;
    uint8_t ctrlMode;
    bool    flightMode;
    bool    RCLock;
} remoterData_t;

/* 飞控状态消息 (对应原始 MiniFlyMsg_t)
 * ⚠ V22.1 关键修复: 原版 moduleID 是 `enum expModuleID`,
 *   在 Keil/GCC ARM 下 enum = 4 字节! 旧版写成 uint8_t(1字节) →
 *   整个结构体 14 字节(原版 17 字节), 遥控器按 17 字节解析这条 ACK 时
 *   moduleID/trim 字段全部错位 → 遥控器拿到的飞控状态是错的, 表现为
 *   屏幕状态文字乱跳、迟迟不进入可控状态。这里改回 4 字节并填 0(无模块)。 */
typedef struct __attribute__((packed)) {
    uint8_t  version;
    bool     mpu_selfTest;  /* GY-91 或 LSM6DS3 */
    bool     baro_slfTest;  /* BMP280 — GY-91缺失时 false */
    bool     isCanFly;
    bool     isLowpower;
    uint32_t moduleID;      /* =enum expModuleID, 4字节! 0=NO_MODULE */
    float    trimRoll;
    float    trimPitch;
} MiniFlyMsg_t;

/* ══ 多机广播(打包)相关定义 ══ */
#define DRONE_ID_SELF        1        /* 本机身份: A机=1(nRF52840). B机(ATK)固件里设为2 */
#define DOWN_BCAST_MULTI     0x60     /* 打包广播 msgID (0x0A与DOWN_FLYMODE撞车, 改0x60) */
#define CMD_FLAG_HOLD        0x01     /* 悬停待命标志 */
#define CMD_FLAG_RCLOCK_V    0x02
#define CMD_FLAG_FLIGHTMD_V  0x04
#define ALTHOLD_MODE_VAL     1        /* 定高模式的 ctrlMode 值(bit0=1, 见 anomal_detec) */

void bcastMultiProcess(atkp_t* pk);   /* V23.39: 打包广播解析 */
void remoterCtrlProcess(atkp_t* pk);
void sendMsgACK(void);