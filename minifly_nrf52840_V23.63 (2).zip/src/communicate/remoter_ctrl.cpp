/**
 * @file    remoter_ctrl.cpp
 * @brief   遥控器控制实现
 *          对应: COMMUNICATE/src/remoter_ctrl.c (逐字对照)
 *
 * sendMsgACK():
 *   打包 MiniFlyMsg_t (version, mpu_selfTest, baro_slfTest, isCanFly,
 *                       isLowpower, moduleID=0, trimRoll, trimPitch)
 *   → UP_REMOTER → radiolinkSendPacketBlocking
 *   isCanFly==true 时发送微调值 reSendTimes=3 次
 *
 * remoterCtrlProcess(pk):
 *   REMOTER_CMD:
 *     CMD_GET_MSG    → sendMsgACK()
 *     CMD_FLIGHT_LAND→ 切换 keyFlight/keyLand
 *     CMD_EMER_STOP  → 停机
 *     CMD_FLIP       → 忽略 (无空翻模块)
 *     CMD_POWER_*    → 忽略 (无扩展模块)
 *   REMOTER_DATA:
 *     thrust * 655.35f → 映射 0~100 到 0~65535
 *     → flightCtrldataCache(ATK_REMOTER, remoterCtrl)
 */
#include "remoter_ctrl.h"
#include "radiolink.h"
#include "commander.h"
#include "../config.h"
#include "../flight/sensors.h"
#include "../flight/sensfusion6.h"
#include "pm.h"
#include "../config_param.h"
#include <string.h>
#include <FreeRTOS.h>
#include <task.h>

static ctrlVal_t  s_remoterCtrl;
static MiniFlyMsg_t s_msg;
static uint8_t    s_reSendTimes = 3;   /* 微调重发次数 (对应原始 reSendTimes=3) */

/**
 * @brief  sendMsgACK — 对应原始 sendMsgACK()
 */
void sendMsgACK(void) {
    s_msg.version      = configParam.version;
    s_msg.mpu_selfTest = getIsMPU9250Present();
    /* V22.2: 没气压计时也上报 true, 否则原遥控器卡在 "BARO CHECK [FAIL]"
     * (=你看到的 "back check fall") 永远不放行。详见 config.h 说明。 */
#if ALLOW_FLIGHT_WITHOUT_BARO
    s_msg.baro_slfTest = true;
#else
    s_msg.baro_slfTest = getIsBaroPresent();
#endif
#if FORCE_CANFLY
    s_msg.isCanFly     = true;   /* V22.10: 调试用, 跳过重力校准门 (见 config.h) */
#else
    s_msg.isCanFly     = getIsCalibrated();
#endif
    s_msg.isLowpower   = getIsLowpower();
    s_msg.moduleID     = 0u;   /* NO_MODULE (4字节, 见 remoter_ctrl.h 修复说明) */

    /* V22.81: 不再把固件 trim 回传给遥控器 —— 修"trimR≤~-4.05时遥控器显示溢出(5.00+乱码)、
     * 且回传损坏值污染 s_rcTrim → 无人机倾斜更严重"。固件 trim 现在只在本机 state_control 直接生效,
     * 不经遥控器往返。遥控器物理微调(若用)仍照常经 s_rcTrim 传入。真实 trim 看心跳 trim=。 */
    if (s_msg.isCanFly && s_reSendTimes > 0) {
        s_reSendTimes--;
        s_msg.trimPitch = 0.0f;
        s_msg.trimRoll  = 0.0f;
    } else if (!s_msg.isCanFly) {
        s_msg.trimPitch = 0;
        s_msg.trimRoll  = 0;
    }

    atkp_t p;
    p.msgID   = UP_REMOTER;
    p.dataLen = sizeof(s_msg) + 1;          /* =18 (与原版一致) */
    p.data[0] = ACK_MSG;
    memcpy(p.data + 1, &s_msg, sizeof(s_msg));
    radiolinkSendPacketBlocking(&p);  /* V22.1: 改阻塞(对照原版), 确保遥控器拿到状态 */
}

/**
 * @brief  remoterCtrlProcess — 对应原始 remoterCtrlProcess()
 */
void remoterCtrlProcess(atkp_t* pk) {
    /* ══【CMD 分支】这段做了什么: 遥控器按键类指令 —
     * 一键起降键 = keyFlight/keyLand 翻转(在地→起飞, 在飞→降落);
     * 急停键 = 进 V23.26 缓判(真上锁≤20ms确认切电, 关机毛刺被忽略);
     * GET_MSG = 回状态包(配对/自检握手)。空翻等无硬件指令忽略。 */
    if (pk->data[0] == REMOTER_CMD) {
        if (pk->dataLen < 2) return;   /* V23.62: data[1] 前先确认长度 */
        switch (pk->data[1]) {
        case CMD_FLIGHT_LAND:
            if (!getCommanderKeyFlight()) {
                setCommanderKeyFlight(true);
                setCommanderKeyland(false);
            } else {
                setCommanderKeyFlight(false);
                setCommanderKeyland(true);
            }
            break;
        case CMD_EMER_STOP:
            setCommanderEmerStopFromRemote();   /* V23.26: 缓判 — 真上锁≤20ms内确认切电; 关机毛刺被忽略(keyFlight清零同步移入裁决, 防毛刺误清) */
            break;
        case CMD_GET_MSG:
            sendMsgACK();
            break;
        /* CMD_FLIP / CMD_POWER_MODULE / CMD_LEDRING_EFFECT / CMD_POWER_VL53LXX
         * → 无对应硬件, 忽略 */
        default: break;
        }
    /* ══【DATA 分支】这段做了什么: 遥控器摇杆帧 —
     * 四通道原值 + thrust 0~100 → ×655.35 映射到 0~65535;
     * 同步控制模式/飞行模式; 最后 flightCtrldataCache(ATK_REMOTER) 入缓存,
     * commander 每 10ms 从缓存取用(链路时间戳也在此刷新=失联判定的源头)。 */
    } else if (pk->data[0] == REMOTER_DATA) {
        /* ★V23.62 边界检查(原实现在检查前就先 memcpy 27 字节 — 真实的越界读):
         * 私有模式下遥控器同样用 DOWN_REMOTOR 发心跳与命令帧, 那些包的 dataLen
         * 只有 2~3 字节。原码无条件从 data+1 复制 sizeof(remoterData_t)=27 字节,
         * 读到的是包外残留内存, 再被当成 roll/pitch/yaw/thrust 应用 →
         * 推油门瞬间姿态指令被垃圾值覆盖 → 侧翻。因残留内容不定, 故为间歇性。 */
        if (pk->dataLen < (uint8_t)(1 + sizeof(remoterData_t))) return;

        remoterData_t rd;
        memcpy(&rd, pk->data + 1, sizeof(rd));

        /* ══ 广播选台(V23.40) ══
         * 广播摇杆包在 remoterData_t 之后追加1个目标字节:
         *   dataLen == 1(REMOTOR_DATA) + sizeof(rd)      → 私有帧, 无目标字节, 照常应用
         *   dataLen >  1 + sizeof(rd)                    → 广播帧, data[1+sizeof(rd)]=目标ID
         *     目标=0 → 全体; 否则须==本机DRONE_ID_SELF才应用, 不匹配则悬停待命。
         * 悬停时照常刷新链路时间戳(不进失控倒数)。 */
        if (pk->dataLen > (uint8_t)(1 + sizeof(rd))) {
            uint8_t tgt = pk->data[1 + sizeof(rd)];
            if (tgt != 0 && tgt != DRONE_ID_SELF) {
                s_remoterCtrl.roll = s_remoterCtrl.pitch = s_remoterCtrl.yaw = 0.0f;
                s_remoterCtrl.thrust = 32767.0f;   /* 悬停点(定高杆中位)! thrust=0会以60cm/s下降 */
                s_remoterCtrl.trimPitch = s_remoterCtrl.trimRoll = 0.0f;
                setCommanderCtrlMode(ALTHOLD_MODE_VAL);            /* 悬停待命 */
                flightCtrldataCache(ATK_REMOTER, s_remoterCtrl);   /* 仍刷新链路 */
                return;
            }
        }

        s_remoterCtrl.roll      = rd.roll;
        s_remoterCtrl.pitch     = rd.pitch;
        s_remoterCtrl.yaw       = rd.yaw;
        s_remoterCtrl.thrust    = rd.thrust * 655.35f;   /* 0~100 → 0~65535 */
        s_remoterCtrl.trimPitch = rd.trimPitch;
        s_remoterCtrl.trimRoll  = rd.trimRoll;

        setCommanderCtrlMode(rd.ctrlMode);
        setCommanderFlightmode(rd.flightMode);
        flightCtrldataCache(ATK_REMOTER, s_remoterCtrl);
    }
}

/* ══ V23.39: 打包广播解析(多机架构) ══
 * 遥控器广播一包含全部机指令 [msgID=DOWN_BCAST_MULTI][dataLen][N][droneCmd×N]。
 * 本机扫描找到自己 DRONE_ID 的那段 → 解压定点值 → 走同一出口 flightCtrldataCache。
 * HOLD 标志(未被选中的待命机): roll/pitch/yaw=0 + 保持定高 → 悬停待命,
 *   且照常刷新链路时间戳(不进失控倒数) —— 这是"打包悬停"替代"点名心跳"的关键。
 * 找不到自己 ID: 本包不含本机指令(分组多包场景), 忽略但不清链路。 */
void bcastMultiProcess(atkp_t* pk) {
    const uint8_t* seg = pk->data + 1;     /* 各机段起点 */
    const uint8_t CMD_SZ = 8;              /* droneCmd_t 大小, 与遥控器一致 */
    /* ★边界检查(原实现完全没有 — 真实的越界读):
     * n 直接取自包内一字节, 而 data[] 只有 ATKP_MAX_DATA_SIZE(30) 字节。
     * 若收到任何 msgID 恰为 0x60 的包(噪声/解析错位), n 可能是 200, 循环会扫过
     * 上千字节 RAM, 撞到任意等于 DRONE_ID_SELF 的字节就把后面7字节当指令用上 ——
     * roll/4.0f 最大可产生 ±31.75 度的姿态偏移。 */
    if (pk->dataLen < 1) return;
    uint8_t n = pk->data[0];
    if (n == 0 || n > 3) return;                          /* 载荷上限只放得下3台 */
    if ((uint16_t)1 + (uint16_t)n * CMD_SZ > pk->dataLen) return;  /* 台数与长度不符 */
    for (uint8_t i = 0; i < n; i++) {
        const uint8_t* c = seg + i * CMD_SZ;
        if (c[0] != DRONE_ID_SELF) continue;   /* 不是自己那段, 跳过 */

        uint8_t flags = c[1];
        uint16_t thr  = (uint16_t)(c[2] | (c[3] << 8));
        int8_t  roll  = (int8_t)c[4];
        int8_t  pitch = (int8_t)c[5];
        int8_t  yaw   = (int8_t)c[6];

        uint8_t ctrlMode = (flags >> 3) & 0x03;

        if (flags & CMD_FLAG_HOLD) {
            /* 悬停待命: 姿态归中, 保持定高模式让飞控自己稳住高度 */
            s_remoterCtrl.roll   = 0.0f;
            s_remoterCtrl.pitch  = 0.0f;
            s_remoterCtrl.yaw    = 0.0f;
            s_remoterCtrl.thrust = 32767.0f;  /* 悬停点! 定高模式 climb=(thrust-32767)/32767,
                                               * 原写 0 等于以60cm/s全速下降(旧注释是错的) */
            setCommanderCtrlMode(ALTHOLD_MODE_VAL);   /* 强制定高, 确保能自稳 */
        } else {
            /* 被选中: 解压摇杆值(与遥控器打包比例对应) */
            s_remoterCtrl.roll   = roll  / 4.0f;      /* ±120 → ±30度 */
            s_remoterCtrl.pitch  = pitch / 4.0f;
            s_remoterCtrl.yaw    = yaw   / 0.6f;      /* ±120 → ±200度/秒 */
            s_remoterCtrl.thrust = (thr / 100.0f) * 655.35f;  /* ×100还原%, 再→0~65535 */
            setCommanderCtrlMode(ctrlMode);
        }
        s_remoterCtrl.trimPitch = 0.0f;
        s_remoterCtrl.trimRoll  = 0.0f;
        setCommanderFlightmode((flags & CMD_FLAG_FLIGHTMD_V) ? true : false);
        flightCtrldataCache(ATK_REMOTER, s_remoterCtrl);   /* 同一出口, 刷新链路时间戳 */
        return;
    }
    /* 没找到自己 ID: 忽略(分组多包时本包不含本机), 不做任何事 */
}