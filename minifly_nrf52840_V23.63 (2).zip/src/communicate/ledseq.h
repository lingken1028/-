/**
 * @file    ledseq.h
 * @brief   LED 序列控制
 *          对应: COMMUNICATE/interface/ledseq.h (逐字对照)
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "../hardware/led.h"

#define LEDSEQ_WAITMS(X)  ((int)(X))
#define LEDSEQ_STOP  (-1)
#define LEDSEQ_LOOP  (-2)

/* SEQ_NUM 必须与 ledseq.cpp 中 sequences[] 元素数量一致 */
#define SEQ_NUM 6

typedef struct {
    bool value;    /* LED 状态 */
    int  action;   /* 等待时间(ms) / LEDSEQ_STOP / LEDSEQ_LOOP */
} ledseq_t;

/* 全部序列声明 (对应原始 ledseq.c) */
extern const ledseq_t seq_lowbat[];
extern const ledseq_t seq_calibrated[];
extern const ledseq_t seq_alive[];
extern const ledseq_t seq_linkup[];
extern const ledseq_t seq_charged[];
extern const ledseq_t seq_charging[];

void ledseqInit(void);
bool ledseqTest(void);
void ledseqEnable(bool enable);
void ledseqRun(led_e led, const ledseq_t* sequence);
void ledseqStop(led_e led, const ledseq_t* sequence);