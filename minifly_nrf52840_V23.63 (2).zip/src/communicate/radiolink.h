/**
 * @file    radiolink.h
 * @brief   无线通信接口
 *          对应: COMMUNICATE/interface/radiolink.h (逐字对照)
 *
 * 新增 radiolinkGetFreeTxQueuePackets() (对应原始实现)
 */
#pragma once
#include <stdbool.h>
#include "atkp.h"

void radiolinkInit(void);
void radiolinkTask(void* param);
bool radiolinkSendPacket(const atkp_t* p);
bool radiolinkSendPacketBlocking(const atkp_t* p);
int  radiolinkGetFreeTxQueuePackets(void);
bool radiolinkIsConnected(void);   /* V22: 遥控器链路是否在线 (心跳诊断用) */
#if RADIO_BCAST_EN
uint32_t radiolinkBcastRxCnt(void);   /* V23.38: 广播包接收数 */
uint32_t radiolinkRxTotCnt(void);     /* V23.38b: CRC通过总收包数 */
uint8_t  radiolinkLastRxMatch(void);  /* V23.38b: 最后RXMATCH (0=私有 1=广播) */
#endif
uint32_t radiolinkGetCrcErrCount(void);   /* V23.35 D20: 飞机端CRC错包累计 */