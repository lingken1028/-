/**
 * @file    comm.cpp
 * @brief   通信初始化实现
 *          对应: COMMUNICATE/src/comm.c (逐字对照)
 *
 * commInit() = radiolinkInit() + usblinkInit()
 * commTest() = isInit && consoleTest()
 */
#include "comm.h"
#include "radiolink.h"
#include "usblink.h"
#include "console.h"

static bool s_isInit = false;

void commInit(void) {
    if (s_isInit) return;
    radiolinkInit();
    usblinkInit();
    s_isInit = true;
}

bool commTest(void) {
    bool pass = s_isInit;
    pass &= consoleTest();
    return pass;
}