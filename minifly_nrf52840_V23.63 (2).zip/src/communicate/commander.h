/**
 * @file    commander.h
 * @brief   遥控数据缓存与目标设置
 *          原文件: COMMUNICATE/interface/commander.h (逐字对照)
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "../flight/stabilizer_types.h"

#define COMMANDER_WDT_TIMEOUT_STABILIZE  500   /* ms */
#define COMMANDER_WDT_TIMEOUT_SHUTDOWN  1000   /* ms */

/* 与原始固件完全一致的控制数据结构 */
typedef struct __attribute__((packed)) {
    float roll, pitch, yaw;
    float trimPitch, trimRoll;
    uint16_t thrust;
} ctrlVal_t;

typedef struct {
    ctrlVal_t tarVal[2];
    bool      activeSide;
    uint32_t  timestamp;
} ctrlValCache_t;

typedef enum { ATK_REMOTER=0, WIFI=1 } ctrlSrc_e;
typedef enum { XMODE=0, CAREFREE=1 } YawModeType;

void commanderInit(void);
void flightCtrldataCache(ctrlSrc_e src, ctrlVal_t pk);
void commanderGetSetpoint(setpoint_t* setpoint, state_t* state);
void flyerAutoLand(setpoint_t* setpoint, const state_t* state);

void setCommanderCtrlMode(uint8_t set);
uint8_t getCommanderCtrlMode(void);
void setCommanderFlightmode(bool set);
bool getCommanderFlightmode(void);   /* V22.31: 无头模式状态(心跳 hd=) */
void setCommanderKeyFlight(bool set);
bool getCommanderKeyFlight(void);
void setCommanderKeyland(bool set);
bool getCommanderKeyland(void);
void setCommanderEmerStop(bool set);   /* V22.22: 强制停机(所有模式) */
bool getCommanderEmerStop(void);
bool     commanderGetIsRCLocked(void);   /* V22.3: false=正在收遥控数据 */
uint16_t commanderGetThrust(void);       /* V22.3: 当前油门 0~65535 */
float commanderGetRcTrimR(void);         /* V22.75: 遥控器实时横滚trim(度) */
float commanderGetRcTrimP(void);         /* V22.75: 遥控器实时俯仰trim(度) */
uint8_t commanderGetStateBits(void);
char  commanderGetFailsafeChar(void);    /* V23.05: N无/R失联/B气压/E急停 (心跳fs=) */
void  setCommanderEmerStopFromRemote(void);
float commanderGetTargetZ(void);         /* V23.08: 定高目标(心跳zt=) */
void setCommanderEmerStop(bool set);