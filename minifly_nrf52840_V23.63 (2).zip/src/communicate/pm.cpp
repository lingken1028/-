/**
 * @file    pm.cpp
 * @brief   电源管理实现
 *          原文件: COMMUNICATE/src/pm.c
 *
 * 移植变化:
 *   batteryVoltage 来源: syslink (nRF51822→STM32 UART)
 *                → nRF52840 D4 ADC 直接测量
 *   pmUpdateState: 简化为仅 battery / lowPower 两状态
 *                  (无充电检测硬件)
 *
 * pmTask (P2, 100ms 周期) 与原始固件逻辑完全对应:
 *   → 读取 ADC → pmSetBatteryVoltage → pmUpdateState
 *   → 状态变化时更新 LED 序列
 */
#include "pm.h"
#include "ledseq.h"
#include "commander.h"
#include "../flight/sensfusion6.h"
#include "../config.h"
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <nrf.h>

/* V22.40: PlatformIO 某些 XIAO 变体未定义 PIN_VBAT → 兜底 (P0.31=AIN7 电池 ADC) */
#ifndef PIN_VBAT
  #define PIN_VBAT     (35)   /* XIAO nRF52840: P0.31 = VBAT_ADC (官方引脚图标号 35) */
#endif

static float   s_batV     = 3.7f;
static float   s_batVMin  = 6.0f;
static float   s_batVMax  = 0.0f;
static bool    s_isInit   = false;
static bool    s_isLow    = false;
static PMStates s_state   = battery;
static uint32_t s_lowTS   = 0;

/* 移动平均滤波 (32点, V22.15: 16→32 进一步压抑跳动, 让显示更稳) */
#define ADC_FILTER_LEN 32
static float s_adcBuf[ADC_FILTER_LEN] = {};
static int   s_adcIdx = 0;
static bool  s_adcFull = false;

static float adcFilter(float v) {
    s_adcBuf[s_adcIdx++] = v;
    if (s_adcIdx >= ADC_FILTER_LEN) { s_adcIdx=0; s_adcFull=true; }
    int n = s_adcFull ? ADC_FILTER_LEN : s_adcIdx;
    float sum = 0; for (int i=0; i<n; i++) sum+=s_adcBuf[i];
    return sum/n;
}

static int s_lastRaw = 0;   /* V22.18: 暴露原始 ADC 值供心跳诊断 */

#if BAT_USE_INTERNAL
/* V22.41: 直接用 SAADC 读 AIN7(P0.31), 绕开 Arduino analogRead 的 PIN_VBAT 映射。
 * PlatformIO 的 XIAO 变体里 P0.31 不是常规模拟脚 → analogRead 读不到(之前恒定 2.30)。
 * 增益 1/5 + 内部 0.6V 参考 → 满量程 3.0V, 12bit; TACQ=40us 适配分压器高内阻(~337k)。*/
static uint16_t saadcReadVBat(void) {
    volatile int16_t result = 0;
    NRF_SAADC->RESOLUTION = SAADC_RESOLUTION_VAL_12bit;
    NRF_SAADC->CH[0].CONFIG =
        (SAADC_CH_CONFIG_RESP_Bypass     << SAADC_CH_CONFIG_RESP_Pos)   |
        (SAADC_CH_CONFIG_RESN_Bypass     << SAADC_CH_CONFIG_RESN_Pos)   |
        (SAADC_CH_CONFIG_GAIN_Gain1_5    << SAADC_CH_CONFIG_GAIN_Pos)   |
        (SAADC_CH_CONFIG_REFSEL_Internal << SAADC_CH_CONFIG_REFSEL_Pos) |
        (SAADC_CH_CONFIG_TACQ_40us       << SAADC_CH_CONFIG_TACQ_Pos)   |
        (SAADC_CH_CONFIG_MODE_SE         << SAADC_CH_CONFIG_MODE_Pos)   |
        (SAADC_CH_CONFIG_BURST_Enabled   << SAADC_CH_CONFIG_BURST_Pos); /* V22.42: 突发, 配合过采样 */
    /* V22.42: 16次突发过采样 — 内置分压器内阻高(~337k), 单次采样充电不足会读偏低;
     * BURST+OVERSAMPLE 让一次触发内部连采16次累加平均, 给采样电容足够充电时间, 同时降噪。*/
    NRF_SAADC->OVERSAMPLE = SAADC_OVERSAMPLE_OVERSAMPLE_Over16x;
    NRF_SAADC->CH[0].PSELP = SAADC_CH_PSELP_PSELP_AnalogInput7;   /* P0.31 = AIN7 */
    NRF_SAADC->CH[0].PSELN = SAADC_CH_PSELN_PSELN_NC;
    NRF_SAADC->RESULT.PTR    = (uint32_t)&result;
    NRF_SAADC->RESULT.MAXCNT = 1;
    NRF_SAADC->ENABLE = (SAADC_ENABLE_ENABLE_Enabled << SAADC_ENABLE_ENABLE_Pos);
    NRF_SAADC->EVENTS_STARTED = 0; NRF_SAADC->TASKS_START  = 1;
    while (!NRF_SAADC->EVENTS_STARTED) {}
    NRF_SAADC->EVENTS_END     = 0; NRF_SAADC->TASKS_SAMPLE = 1;
    while (!NRF_SAADC->EVENTS_END) {}
    NRF_SAADC->EVENTS_STOPPED = 0; NRF_SAADC->TASKS_STOP   = 1;
    while (!NRF_SAADC->EVENTS_STOPPED) {}
    NRF_SAADC->ENABLE = (SAADC_ENABLE_ENABLE_Disabled << SAADC_ENABLE_ENABLE_Pos);
    if (result < 0) result = 0;
    return (uint16_t)result;
}
#endif

static float readBatVoltage(void) {
#if BAT_USE_INTERNAL
    int raw = saadcReadVBat();          /* P0.31 直读, 不经 analogRead */
#else
    int raw = analogRead(BAT_ADC_PIN);  /* 外部分压器, 普通模拟脚 */
#endif
    s_lastRaw = raw;
    /* V22.15: 末尾乘 BAT_CALIB 一键标定 (见 config.h) */
    float v  = (float)raw / BAT_ADC_RES * BAT_ADC_VREF * BAT_DIV_RATIO * BAT_CALIB;
    return adcFilter(v);
}

int pmGetRawADC(void) { return s_lastRaw; }   /* V22.18: 心跳诊断用原始 ADC */

static void pmSetBatteryVoltage(float v) {
    s_batV = v;
    if (v > s_batVMax) s_batVMax = v;
    if (v < s_batVMin) s_batVMin = v;
}

void pmInit(void) {
    if (s_isInit) return;
#if BAT_USE_INTERNAL
    /* V22.40: 内置测量 — 把 P0.14(VBAT_ENABLE)拉低使能内部分压(1M+510k → P0.31)。
     * 直接配 P0.14 寄存器(与 imuPowerOn 同款, 不依赖 VBAT_ENABLE 宏/PlatformIO 变体)。
     * ★一直保持 LOW: 置 HIGH 时 P0.31 可能升到 3.6V 上限有烧脚风险(充电时尤甚)。
     * P0.14 LOW 时 P0.31 = Vbat×510/1510 ≈ 4.2×0.338=1.42V < 3.0V 参考, 量程够。 */
    NRF_P0->PIN_CNF[14] =
        (GPIO_PIN_CNF_DIR_Output       << GPIO_PIN_CNF_DIR_Pos)   |
        (GPIO_PIN_CNF_INPUT_Disconnect << GPIO_PIN_CNF_INPUT_Pos) |
        (GPIO_PIN_CNF_PULL_Disabled    << GPIO_PIN_CNF_PULL_Pos)  |
        (GPIO_PIN_CNF_DRIVE_H0H1       << GPIO_PIN_CNF_DRIVE_Pos) |
        (GPIO_PIN_CNF_SENSE_Disabled   << GPIO_PIN_CNF_SENSE_Pos);
    NRF_P0->OUTCLR = (1UL << 14);   /* P0.14 = LOW → 使能内部分压 */
#endif
    /* V22.18: 显式锁定内部参考 AR_INTERNAL_3_0 (0.6V 带隙×5 = 3.0V 满量程)。
     * 内部带隙参考与 VDD 无关 → 接不接 GY-91 读数都稳定。 */
    analogReference(AR_INTERNAL_3_0);
    analogReadResolution(12);
    pinMode(BAT_ADC_PIN, INPUT);
    /* 预热 ADC */
    for (int i=0; i<ADC_FILTER_LEN; i++) {
        s_adcBuf[i] = readBatVoltage();
        delay(5);
    }
    s_adcFull = true;
    pmSetBatteryVoltage(readBatVoltage());
    s_isInit = true;
}

bool  pmTest(void)            { return s_isInit; }
uint16_t powerGetLastThrust(void);   /* V23.03: 真实电机油门(定高档摇杆中位≠负载) */
float pmGetBatteryVoltage(void){ return s_batV; }
#if DISABLE_VOLTAGE_PROTECTION
bool  getIsLowpower(void)     { return false; }   /* V22.18: 取消电压保护 → 恒不低压 */
#else
bool  getIsLowpower(void)     { return s_isLow; }
#endif

/* 兼容原始接口 (不再使用 syslink，改用 ADC) */
void pmSyslinkUpdate(atkp_t* slp) { (void)slp; }

/* pmTask (P2) — 对应原始 pmTask，100ms 周期 */
/* ══【段落】pmTask — 电池哨兵(100ms): 读ADC(SAADC直读+16x过采样+32点均值)
 * → 低压判定用【下垂补偿后的静息电压】vRest=v+K×(油门/65535)(V22.96: 修
 * "给油门电压猛掉→假低压"); 低于阈值持续超时才判低压 → LED切换+上报。
 * 注意 DISABLE_VOLTAGE_PROTECTION 编译开关可整体关闭(演示前核对!)。 ══ */
void pmTask(void* param) {
    PMStates stateOld = battery;
    s_lowTS = millis();
    vTaskDelay(pdMS_TO_TICKS(500));

    while (1) {
        vTaskDelay(pdMS_TO_TICKS(100));

        /* 读取电池电压 (ADC 替代 syslink) */
        float v = readBatVoltage();
        pmSetBatteryVoltage(v);

        /* V22.96: 低压判定用【下垂补偿后的静息电压】— 高油门时压降不再触发假低压。
         * 显示/VBAT_COMP 仍用实测v(见config.h VBAT_SAG_COMP_K 注释)。 */
        float vRest = v + VBAT_SAG_COMP_K * ((float)powerGetLastThrust() / 65535.0f);
        if (vRest > PM_BAT_LOW_VOLTAGE) s_lowTS = millis();

        /* 状态判断 (简化: 无充电检测) */
        uint32_t lowTime = millis() - s_lowTS;
        PMStates st = (lowTime > PM_BAT_LOW_TIMEOUT_MS) ? lowPower : battery;
#if DISABLE_VOLTAGE_PROTECTION
        st = battery;            /* V22.18: 取消电压保护 → 永不进低压, 不点低压LED, 不上报低压 */
        s_isLow = false;
#endif
        s_state = st;

        if (st != stateOld) {
            if (st == lowPower) {
                s_isLow = true;
                ledseqStop(SYS_LED, seq_alive);
                ledseqStop(SYS_LED, seq_calibrated);
                ledseqRun(LOWBAT_LED, seq_lowbat);
            } else {
                s_isLow = false;
                ledseqStop(LOWBAT_LED, seq_lowbat);
                if (getIsCalibrated())
                    ledseqRun(SYS_LED, seq_calibrated);
                else
                    ledseqRun(SYS_LED, seq_alive);
            }
            stateOld = st;
        }
    }
}