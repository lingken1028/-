/**
 * @file    usblink.h
 * @brief   USB CDC 通讯接口
 *          对应: COMMUNICATE/interface/usblink.h (逐字对照)
 */
#pragma once
#include <stdbool.h>
#include "atkp.h"

void usblinkInit(void);
void usblinkSetActive(bool v);  /* set by atkpRxAnlTask */
bool usblinkIsActive(void);
bool usblinkSendPacket(const atkp_t* p);
int  usblinkGetFreeTxQueuePackets(void);
void usblinkRxTask(void* param);
void usblinkTxTask(void* param);

uint32_t usblinkGetTxDrops(void);   /* V23.12: 上行丢包计数(心跳txd=) */
