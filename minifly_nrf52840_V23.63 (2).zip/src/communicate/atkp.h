/**
 * @file    atkp.h
 * @brief   ATKP 通讯协议
 *          对应: COMMUNICATE/interface/atkp.h (逐字对照, V1.3)
 *
 * 上行帧 (飞控→上位机): [AA][AA][msgID][dataLen][data...][cksum]
 * 下行帧 (上位机→飞控): [AA][AF][msgID][dataLen][data...][cksum]
 *
 * V1.3 新增: UP_USER_DATA1~10 (用户数据上传)
 */
#pragma once
#include <stdint.h>
#include <stdbool.h>
#include <FreeRTOS.h>
#include <queue.h>

/* 帧头 */
#define UP_BYTE1    0xAA
#define UP_BYTE2    0xAA
#define DOWN_BYTE1  0xAA
#define DOWN_BYTE2  0xAF

#define ATKP_MAX_DATA_SIZE 30

typedef struct {
    uint8_t msgID;
    uint8_t dataLen;
    uint8_t data[ATKP_MAX_DATA_SIZE];
} atkp_t;

/* 上行 ID (对应 upmsgID_e 完整枚举) */
typedef enum {
    UP_VERSION    = 0x00,
    UP_STATUS     = 0x01,
    UP_SENSER     = 0x02,
    UP_RCDATA     = 0x03,
    UP_GPSDATA    = 0x04,
    UP_POWER      = 0x05,
    UP_MOTOR      = 0x06,
    UP_SENSER2    = 0x07,
    UP_FLYMODE    = 0x0A,
    UP_SPEED      = 0x0B,
    UP_PID1       = 0x10,
    UP_PID2       = 0x11,
    UP_PID3       = 0x12,
    UP_PID4       = 0x13,
    UP_PID5       = 0x14,
    UP_PID6       = 0x15,
    UP_RADIO      = 0x40,
    UP_MSG        = 0xEE,
    UP_CHECK      = 0xEF,
    UP_REMOTER    = 0x50,
    UP_PRINTF     = 0x51,
    UP_USER_DATA1 = 0xF1,
    UP_USER_DATA2 = 0xF2,
    UP_USER_DATA3 = 0xF3,
    UP_USER_DATA4 = 0xF4,
    UP_USER_DATA5 = 0xF5,
    UP_USER_DATA6 = 0xF6,
    UP_USER_DATA7 = 0xF7,
    UP_USER_DATA8 = 0xF8,
    UP_USER_DATA9 = 0xF9,
    UP_USER_DATA10= 0xFA,
} upmsgID_e;

/* 下行指令 (对应 D_COMMAND_* 宏) */
#define D_COMMAND_ACC_CALIB       0x01
#define D_COMMAND_GYRO_CALIB      0x02
#define D_COMMAND_MAG_CALIB       0x04
#define D_COMMAND_BARO_CALIB      0x05
#define D_COMMAND_FLIGHT_LOCK     0xA0
#define D_COMMAND_FLIGHT_ULOCK    0xA1
#define D_ACK_READ_PID            0x01   /* DOWN_ACK: 读取PID */
#define D_ACK_READ_VERSION        0xA0   /* DOWN_ACK: 读取版本 → sendUPVersion() */
#define D_ACK_RESET_PARAM         0xA1   /* DOWN_ACK: 恢复出厂 */

/* 下行 ID (对应 downmsgID_e 完整枚举) */
typedef enum {
    DOWN_COMMAND  = 0x01,
    DOWN_ACK      = 0x02,
    DOWN_RCDATA   = 0x03,
    DOWN_POWER    = 0x05,
    DOWN_FLYMODE  = 0x0A,
    DOWN_PID1     = 0x10,
    DOWN_PID2     = 0x11,
    DOWN_PID3     = 0x12,
    DOWN_PID4     = 0x13,
    DOWN_PID5     = 0x14,
    DOWN_PID6     = 0x15,
    DOWN_RADIO    = 0x40,
    DOWN_REMOTER  = 0x50,
} downmsgID_e;

/* 字节提取宏 (对应原始 atkp.c BYTE0~BYTE3) */
#define BYTE0(x) ((uint8_t)((x) & 0xFF))
#define BYTE1(x) ((uint8_t)(((x) >>  8) & 0xFF))
#define BYTE2(x) ((uint8_t)(((x) >> 16) & 0xFF))
#define BYTE3(x) ((uint8_t)(((x) >> 24) & 0xFF))

/* 全局 RX/TX 队列句柄 (供 usblink/radiolink 使用) */
extern QueueHandle_t atkpRxQueue;
extern QueueHandle_t radiolinkTxQueue;

void atkpInit(void);
void atkpTxTask(void* param);
void atkpRxAnlTask(void* param);
bool atkpReceivePacketBlocking(atkp_t* p);