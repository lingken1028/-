/**
 * @file    commander.cpp
 * @brief   遥控数据缓存与目标设置
 *          对应: COMMUNICATE/src/commander.c (逐字对照)
 *
 * V9 修正: 定高逻辑加入 getIsBaroPresent() 保护
 *   - GY-91 有 BMP280 → mode.z = modeVelocity (定高使能)
 *   - 仅 LSM6DS3 (无气压计) → mode.z 强制 modeDisable (纯姿态)
 *
 * 核心逻辑:
 *   ctrlMode bit0=1 → 定高模式 (需要气压计)
 *   ctrlMode bit1=1 → 定点模式 (需要光流, 本平台不支持)
 *   keyFlight=1 → 起飞, keyLand=1 → 降落
 *   flightMode=1 → 遥控器控高开关
 *   WDT: 超时 → levelRPY → dropToGround → isRCLocked=true
 *   无头模式 (carefree): Yaw 旋转补偿
 */
#include "commander.h"
#include "pm.h"
#include "../flight/sensfusion6.h"
#include "../flight/position_pid.h"
#include "../flight/state_estimator.h"
#include "../flight/sensors.h"          /* getIsBaroPresent() — V9 */
#include "../flight/flip.h"             /* V22.28: isExitFlip — 加速度触地检测 */
#include "../flight/stabilizer.h"        /* V22.17: setFastAdjustPosParam (定高一键起飞到80cm) */
#include "../config.h"
#include "../config_param.h"
#include <math.h>
#include <Arduino.h>

#define MIN_THRUST   5000.0f
#define MAX_THRUST  60000.0f
#define MAX_CLIMB_UP   100.0f   /* V22.17: 定高最大爬升速度 cm/s (原版) */
#define MAX_CLIMB_DOWN  60.0f   /* V22.17: 定高最大下降速度 cm/s (原版) */

static bool isRCLocked        = true;
static ctrlValCache_t remoteCache = {};
static ctrlValCache_t wifiCache   = {};
static ctrlValCache_t* nowCache   = &remoteCache;
static ctrlVal_t  ctrlValLpf      = {};
/* V22.75: 遥控器实时 trim 独立存放, 不再覆盖 configParam.trimR/trimP(那是持久trim)。
 * 实际叠加 = configParam.trimR/trimP(持久, 可存/地面站PID13) + s_rcTrim(遥控器实时)。 */
static float      s_rcTrimR = 0.0f, s_rcTrimP = 0.0f;

static bool  s_thrArmed        = false;  /* V22.89: 起转安全锁 — 油门曾压到底才允许起转(防中位杆降级手动冲桨) */
/* ── V22.94: 断信号失控保护 状态 ── */
static bool    s_rcLossActive = false;   /* 失联>1s 进入 */
/* V23.25 修: s_graceStart/s_inGrace 移出 #if RC_LOSS_ACTION!=0 — 它们被 ACTION==0 分支
 * (commanderDropToGround)、以及无条件区域(commanderInGrace/ctrlDataUpdate)使用。
 * 原先声明在 #if!=0 里, 当 ACTION=0 时声明被预处理器剔除→"not declared in this scope"编译错。
 * 宽限机制本就是为 ACTION=0 服务, 声明必须无条件存在。 */
static uint32_t s_graceStart  = 0;       /* V23.24: ACTION=0 短暂失联宽限计时起点 */
static bool    s_inGrace      = false;
static bool    s_graceLockPending=false;   /* V23.24: 当前是否在失联宽限中(维持定高续飞) */
#if RC_LOSS_ACTION != 0
static uint8_t s_rcLossPhase  = 0;       /* 0=悬停等待(动作1) 1=缓降 */
static float   s_rcLossT      = 0.0f;    /* 失联计时 s (本文件@100Hz累加) */
#endif
/* ── V22.95: 气压计飞行中失效保护 状态 ── */
uint16_t powerGetLastThrust(void);       /* V23.06: 真实电机油门 — "在飞"判定唯一可靠依据(与高度基线无关) */
#if RC_LOSS_ACTION != 0
#endif
static uint16_t s_climbStuckCnt = 0;
static float    s_climbStuckZ0  = 0.0f;  /* V23.08: 看门窗口起点高度 */
static float    s_dbgTargetZ    = -999;  /* V23.08: 最终定高目标(心跳zt=) */
static uint32_t s_remoteEmerMs   = 0;     /* V23.15: 遥控急停时刻 — 用"之后链路死没死"区分【上锁】vs【关机】 */
static bool     s_emerWasAirborne = false; /* 急停瞬间是否在飞(真实油门>MIN) */
/* V23.26: 急停缓判 — 修"模式1/2关遥控器立即掉落"。根因: 关机毛刺急停帧 t=0 瞬间切电,
 * 而失联救援(V23.15)要等失联判定 t=1000ms 才启动 — 1s 自由落体≈4.9m, 室内飞高<1.5m,
 * 救援到来前已砸地。修: 急停帧先 pending 不切电; ≤250ms 内又收到摇杆帧(链路活)=飞手
 * 真上锁→立即切(延迟仅一帧10~20ms); 250ms 无新帧(链路死)=关机毛刺→忽略, 高度零损失
 * 转失联保护(模式0宽限/1悬停/2缓降照常)。翻倒保护走裸 setCommanderEmerStop 不受影响。 */
static bool     s_emerPending     = false;
static uint32_t s_emerPendingMs   = 0;
static uint32_t s_emerPendCacheTs = 0;    /* pending 时刻的摇杆帧时间戳快照 */
static bool     s_emerPendKeyClr  = false; /* 真上锁确认时才清 keyFlight/keyLand */
static bool     s_rcLossRescue   = false;  /* 关机救援: 切电后失联接管, 重启电机进缓降 */
static bool    s_baroLossActive = false; /* 定高中气压冻结>500ms 进入 */
static float   s_baroLossThr    = 0.0f;  /* 开环缓收的油门 */   /* V22.97: 移至此(下方函数要用, 原声明在其后→编译错) */
static float      lpfVal          = 0.2f;

typedef struct {
    uint8_t ctrlMode  : 2;
    uint8_t keyFlight : 1;
    uint8_t keyLand   : 1;
    uint8_t emerStop  : 1;
    uint8_t flightMode: 1;
    uint8_t reserved  : 2;
} commanderBits_t;
static commanderBits_t commander = {};
static YawModeType yawMode = XMODE;

void commanderInit(void) { remoteCache.timestamp = wifiCache.timestamp = 0; }

void flightCtrldataCache(ctrlSrc_e src, ctrlVal_t pk) {
    ctrlValCache_t* c = (src == ATK_REMOTER) ? &remoteCache : &wifiCache;
    c->tarVal[!c->activeSide] = pk;
    c->activeSide = !c->activeSide;
    c->timestamp  = millis();
}

static void commanderLevelRPY(void) {
    ctrlValLpf.roll = ctrlValLpf.pitch = ctrlValLpf.yaw = 0;
}
/* ══════════════════════════════════════════════════════════════
 * 【段落】commanderDropToGround — 彻底失联后"每拍"被调用的动作器
 *   这段做了什么: 先把 RPY 桿位归零(调平);然后按编译的失控模式分歧 —
 *   模式0: 管理 2 秒宽限(首拍置锁高旗 → 定高分支锁定当前高度续飞;
 *          超时 → keyLand=1 触发一键降落, s_rcLossActive 保持 isRCLocked 放行);
 *   模式1/2: 首拍置 s_rcLossActive + phase(1=悬停等待,2=立即降),
 *          并做 V23.15 关机救援检查(急停后1.5s内链路死=关机 → 撤急停进救援)。
 *   注意: 本函数拿不到 sp/state, 需要它们的动作都放在 GetSetpoint 末尾注入段。
 * ══════════════════════════════════════════════════════════════ */
static void commanderDropToGround(void) {
    commanderLevelRPY(); ctrlValLpf.thrust = 32767.0f;
#if RC_LOSS_ACTION == 0
    /* V23.24: 短暂失联宽限 — 你的需求"定高断线→连线后同模式同位置继续遥控"。
     * 原来彻底失联立即 keyFlight→keyLand+切油门, 导致即使马上连回来也已退出定高、在降落。
     * 现在: 定高在飞时先【保持当前高度】等待 RC_LOSS_GRACE_S 秒(姿态已调平, 高度锁定不动),
     * 期间信号回来 → ctrlDataUpdate 上层分支 isRCLocked=false 直接交还, 无缝续飞同高度;
     * 超过宽限仍无信号 → 才真正 keyLand+切(原安全行为)。地面/手动模式不受影响(立即切)。 */
    {
        bool airborne = (powerGetLastThrust() > (uint16_t)MIN_THRUST);
        if (airborne && commander.keyFlight && (commander.ctrlMode & 0x01)) {
            /* 定高在飞 → 进宽限: 保持高度, 不清keyFlight, 不切油门 */
            if (s_graceStart == 0){ s_graceStart=millis(); s_graceLockPending=true; }
            if ((millis() - s_graceStart) < (uint32_t)(RC_LOSS_GRACE_S * 1000.0f)) {
                s_inGrace = true;
                ctrlValLpf.thrust = 32767.0f;   /* V23.28 */    /* 宽限内: 维持定高(isRCLocked保持false), 等信号回来续飞 */
            } else {
                /* 宽限超时 → V23.27: 触发【一键降落】(受控缓降, 不再切油门自由落体)。
                 * s_rcLossActive=true 令 isRCLocked 保持放行, flyerAutoLand 真正执行;
                 * keyLand=1 恰好绕开 position_pid 的双零门(见 ctrlDataUpdate 注释)。 */
                s_inGrace = false;
                commander.keyLand = 1; commander.keyFlight = 0;
                s_rcLossActive = true;
            }
        } else {
            /* 非定高/未起飞 → 原立即切行为 */
            s_graceStart = 0; s_inGrace = false;
            ctrlValLpf.thrust = 0;
            if (commander.keyFlight) { commander.keyLand = 1; commander.keyFlight = 0; }
        }
    }
#else
    /* V22.94: 不再直接切油门(那=手动模式空中自由落体) — 进入失控保护(悬停/缓降),
     * 具体动作在 commanderGetSetpoint 末尾执行(那里有 state/hasBaro)。 */
    if (!s_rcLossActive) {
        s_rcLossActive = true;
        s_rcLossPhase  = (RC_LOSS_ACTION == 1) ? 0 : 1;
        s_rcLossT      = 0.0f;
        /* V23.15: 关机救援 — 遥控急停(已切电)后1.5s内链路死 = 这是【关机】不是【上锁】:
         * 撤销急停, 重启电机, 按所选模式悬停/缓降。 */
        if (commander.emerStop && s_emerWasAirborne &&
            (millis() - s_remoteEmerMs) < 1500u) {
            commander.emerStop = 0;
            s_rcLossRescue    = true;
        }
    }
#endif
}

static bool commanderInGrace(void) { return s_inGrace; }   /* V23.24 */

/* ══════════════════════════════════════════════════════════════
 * 【段落】ctrlDataUpdate — 失联判定的"三层时间线"总控(每10ms)
 *   这段做了什么:
 *   ① 急停缓判裁决(V23.26): pending 中若又见摇杆帧=真上锁立即切电;
 *      250ms 链路死透=关机毛刺, 忽略急停
 *   ② 距最后一帧 <500ms  → 正常/恢复分支: 清全部失联状态, 用缓存飞
 *      (分时轮空 <100ms 停留在这一层, 连调平都不触发 — 方法二的根基)
 *   ③ 500~1000ms → 过渡: 姿态调平 + 油门桿强制中位(防断链残桿)
 *   ④ >1000ms   → 彻底失联: 每拍调 DropToGround + isRCLocked 裁决
 *      (保护活动期保持 false, 让降落/悬停代码能进 if(!isRCLocked) 门)
 *   ⑤ 失联保护期跳过桿量 lpf 拉取 → 强制中位/调平(V23.30: 防坏帧被冻结放大)
 * ══════════════════════════════════════════════════════════════ */
static void ctrlDataUpdate(void) {
    uint32_t now = millis();
    /* V23.26: 急停缓判裁决(设计见 s_emerPending 声明处) */
    if (s_emerPending) {
        if (remoteCache.timestamp != s_emerPendCacheTs) {          /* 新摇杆帧=链路活=真上锁 */
            s_emerPending = false;
            s_remoteEmerMs    = millis();                          /* V23.15 救援变量照旧记录 */
            s_emerWasAirborne = (powerGetLastThrust() > (uint16_t)MIN_THRUST);
            commander.emerStop = 1;
            if (s_emerPendKeyClr) { commander.keyFlight = 0; commander.keyLand = 0; s_emerPendKeyClr = false; }
        } else if ((now - s_emerPendingMs) > 250u) {               /* 链路死=关机毛刺→忽略急停 */
            s_emerPending = false; s_emerPendKeyClr = false;       /* 不置emerStop, 失联保护自然接管 */
        }
    }
    if      ((now - remoteCache.timestamp) < COMMANDER_WDT_TIMEOUT_STABILIZE)
        { isRCLocked=false; nowCache=&remoteCache; s_rcLossActive=false; s_rcLossRescue=false; s_graceStart=0; s_inGrace=false; }   /* V22.94/23.15: 信号恢复→退出+清救援 */
    else if ((now - wifiCache.timestamp)   < COMMANDER_WDT_TIMEOUT_STABILIZE)
        { isRCLocked=false; nowCache=&wifiCache; s_rcLossActive=false; s_rcLossRescue=false; s_graceStart=0; s_inGrace=false; }   /* V23.20: 补清rescue(与remote分支对称, 防wifi恢复残留救援旗) */
    else if ((now - remoteCache.timestamp) < COMMANDER_WDT_TIMEOUT_SHUTDOWN)
        { nowCache=&remoteCache; commanderLevelRPY(); }
    else if ((now - wifiCache.timestamp)   < COMMANDER_WDT_TIMEOUT_SHUTDOWN)
        { nowCache=&wifiCache; commanderLevelRPY(); }
    else {
        /* V23.24: 彻底失联。ACTION=0且定高在飞→先进宽限(见commanderDropToGround), 宽限内保持
         * isRCLocked=false 以【继续维持定高高度】(否则 if(!isRCLocked) 定高保持被跳过=失稳)。
         * 宽限超时或非定高→isRCLocked=true 正常锁定。commanderInGrace() 返回是否在宽限中。 */
        nowCache=&remoteCache;
        commanderDropToGround();
        /* V23.27: 失控保护活动期间(宽限/悬停/降落)保持 isRCLocked=false — 根因: 一键降落
         * flyerAutoLand 和定高 keyFlight 分支都在 if(!isRCLocked) 块内, 且 position_pid.cpp
         * 在 keyFlight=0&&keyLand=0 时把位置环输出 thrust 强制清 0(双零门)。旧代码失联即锁
         * → 降落/悬停代码被锁在门外 → 只剩 thrust=0 = 自由落体(模式0超时掉/模式1/2立即掉
         * 的机械死因)。现在: 保护期放行, 失联动作全部改走已验证的 keyFlight/keyLand 通道。 */
        isRCLocked = !(commanderInGrace() || s_rcLossActive);
    }

    if (!isRCLocked) {
        ctrlVal_t cv = nowCache->tarVal[nowCache->activeSide];
        if (s_inGrace || s_rcLossActive){ ctrlValLpf.thrust=32767.0f; ctrlValLpf.pitch=0; ctrlValLpf.roll=0; ctrlValLpf.yaw=0; } else {
        ctrlValLpf.thrust += (cv.thrust - ctrlValLpf.thrust) * lpfVal;
        ctrlValLpf.pitch  += (cv.pitch  - ctrlValLpf.pitch)  * lpfVal;
        ctrlValLpf.roll   += (cv.roll   - ctrlValLpf.roll)   * lpfVal;
        ctrlValLpf.yaw    += (cv.yaw    - ctrlValLpf.yaw)    * lpfVal;
        }
#if USE_REMOTE_TRIM
        /* V22.86: 遥控器物理微调(配合 V22.81 出站发0 避免溢出/加倍)。入口钳位<5°: 拒绝越界/损坏值,
         * 防污染飞控致严重倾斜。应用 = 固件 configParam.trim + 此遥控器按钮量(state_control 里相加)。 */
        /* V22.91: 钳位上限 5°→15° —— 修"遥控器微调到-5.00就往前飞"(原<5°把合法的-5°微调也拒了→trim归0→前飘)。
         * 那个+5.00溢出早被V22.81"出站发0"根治(遥控器收到0不溢出), 故不必再卡5°; 15°仅拦NaN/明显损坏值。 */
        s_rcTrimP = (isfinite(cv.trimPitch) && fabsf(cv.trimPitch) < 15.0f) ? cv.trimPitch : 0.0f;
        s_rcTrimR = (isfinite(cv.trimRoll)  && fabsf(cv.trimRoll)  < 15.0f) ? cv.trimRoll  : 0.0f;
#else
        s_rcTrimP = 0.0f;
        s_rcTrimR = 0.0f;
#endif
        if (ctrlValLpf.thrust < MIN_THRUST) ctrlValLpf.thrust = 0;
        if (ctrlValLpf.thrust > MAX_THRUST) ctrlValLpf.thrust = MAX_THRUST;
    }
}

static void applyCarefree(setpoint_t* sp, state_t* state) {
    /* 无头模式: 把期望 pitch/roll 旋转到绝对坐标系 */
    if (yawMode == CAREFREE) {
        float yawRad = state->attitude.yaw * DEG2RAD;
        float cy = cosf(yawRad), sy = sinf(yawRad);
        float r = sp->attitude.roll, p = sp->attitude.pitch;
        sp->attitude.roll  =  r * cy + p * sy;
        sp->attitude.pitch = -r * sy + p * cy;
    }
}

/* ── V22.17: 定高一键起飞/降落 状态 (对应原版 commander.c) ── */
static bool  s_initHigh        = false;  /* 起飞高度是否已设定 */
/* (V22.97: 起转锁/失控保护状态变量已移至文件顶部 — 修声明顺序编译错误) */
static bool  s_isAdjustingPosZ = false;  /* 是否在调整Z位置 */
static float s_errorPosZ       = 0.0f;   /* Z位移误差 cm */
/* V22.28: 加速度触地检测(对照原版 commander.c minAccZ/maxAccZ)。
 * 着陆冲击会让地球系垂直加速度 state->acc.z 出现 负-正 大摆动 → 据此判停。
 * 在 setCommanderKeyFlight(true)(一键起飞)清零。 */
static float s_minAccZ = 0.0f;
static float s_maxAccZ = 0.0f;
#if ALTHOLD_TD_VEL_ENABLE
static bool    s_landWasDescending = false;  /* V22.30: 速度触地 — 是否已经在下降过 */
static uint8_t s_landStuckCnt       = 0;      /* V22.30: 下降中速度归零的持续计数 */
#endif

static inline float cmdConstrainf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}

/* 简化版一键降落 (对应原版 flyerAutoLand, 去掉空翻/加速度触地检测):
 * V22.26: 以恒定速度匀速下降; 用【快速油门LPF】判停(原来用 α=0.003 太慢, 落地不停),
 *   且阈值相对 thrustBase(原来固定 20000, thrustBase 高时永不触发)。
 *   触地特征: 飞机落地后无法继续下降 → 控制器猛压油门 → 快速油门跌破 (base - ALTHOLD_LAND_THR_DROP)。 */
/* ══════════════════════════════════════════════════════════════
 * 【段落】flyerAutoLand — 一键降落执行器(手动按键与失联保护共用)
 *   这段做了什么: ① 间隔>0.5s 视为新一轮 → 重置触地判据的继承状态
 *   (V23.29: 修"继承上次落地冲击极值→首拍误判触地→双零门瞬掉");
 *   ② mode.z=modeVelocity 以 LAND_SPEED 匀速下压(带自适应项);
 *   ③ 触地三判据任一满足即清 keyLand 停机:
 *      判据① 瞬时电机油门 < thrustBase−THR_DROP(V23.34: 弃3.3s慢LPF);
 *      判据② 垂直加速度负骤跌+正尖峰双越(落地冲击特征);
 *      判据③ 曾下降(vz<-25)后速度归零持续 CNT 拍(轻落地兜底)。
 * ══════════════════════════════════════════════════════════════ */
void flyerAutoLand(setpoint_t* sp, const state_t* state) {
    static uint8_t lowThrustCnt = 0;
    static float   stateVelLpf  = -30.0f;
    static uint32_t s_lc=0; uint32_t nw=millis();
    if(nw-s_lc>500u){ s_minAccZ=0; s_maxAccZ=0;
#if ALTHOLD_TD_VEL_ENABLE
        s_landWasDescending=false; s_landStuckCnt=0;
#endif
    } s_lc=nw;   /* V23.29F2窄: 清继承极值(D4) */

    /* 下降速度: V23.20 修 — 原写死 -70cm/s, 完全无视 config 的 ALTHOLD_LAND_SPEED(=30) →
     * 你调那个宏根本不生效, 这才是"一键降落太快"的真凶(之前误改了失联降落的 RC_LOSS_LAND_SPEED)。
     * 现接上宏: 目标下降速度 = -ALTHOLD_LAND_SPEED; 保留自适应减速项(接近地面 stateVelLpf 让它更柔)。 */
    sp->mode.z      = modeVelocity;
    stateVelLpf    += (state->velocity.z - stateVelLpf) * 0.1f;
    sp->velocity.z  = -(float)ALTHOLD_LAND_SPEED - stateVelLpf * 0.5f;

    bool touchdown = false;

    /* 判停①: 定高油门持续很低(对照原版 < 20000, 持续 >10 次) */
    if (powerGetLastThrust() < (uint16_t)(configParam.thrustBase - (uint32_t)ALTHOLD_LAND_THR_DROP)) {   /* V23.34: 判停①信号源改【真实电机油门瞬时值】 — getAltholdThrust 是 α=0.003 超慢LPF(时间常数≈3.3s), 触地后要拖2-3秒才跟下来=不灵敏的天生根因; 瞬时值+原有0.1s连续计数=快且稳 */   /* V23.27b: 接上config宏 — V22.26注释声称已改"base-DROP", 代码却仍硬编码20000(thrustBase=38000/悬停48000+慢LPF → 跌破20000需10s+ = 落地不停机/判停失灵的元凶, 存在于历代版本) */
        if (++lowThrustCnt > 10) { lowThrustCnt = 0; touchdown = true; }
    } else {
        lowThrustCnt = 0;
    }

    /* 判停②(加速度冲击): 追踪垂直加速度最小/最大, 着陆冲击 → 负骤跌+正尖峰 → 触地。
     * 阈值可在 config.h 调(ALTHOLD_TD_ACC_*)。轻落地冲击不够时靠③。 */
    if (isExitFlip) {
        float accZ = state->acc.z;
        if (s_minAccZ > accZ) s_minAccZ = accZ;
        if (s_maxAccZ < accZ) s_maxAccZ = accZ;
    }
    if (s_minAccZ < ALTHOLD_TD_ACC_MIN && s_maxAccZ > ALTHOLD_TD_ACC_MAX) touchdown = true;

    /* 判停③(速度归零, V22.30 — 对轻落地最灵敏): 命令在强下降, 但飞机已经下降过
     * 之后速度又回到≈0(落地降不下去) → 持续一小段 → 判定触地。 */
#if ALTHOLD_TD_VEL_ENABLE
    if (state->velocity.z < -25.0f) s_landWasDescending = true;   /* 确实下降过 */
    if (s_landWasDescending && state->velocity.z > -ALTHOLD_TD_VEL_STOP) {
        if (++s_landStuckCnt > ALTHOLD_TD_VEL_CNT) touchdown = true;
    } else {
        s_landStuckCnt = 0;
    }
#endif

    if (touchdown) {
        commander.keyLand   = false;
        commander.keyFlight = false;
        estRstAll();
#if ALTHOLD_TD_VEL_ENABLE
        s_landWasDescending = false;
        s_landStuckCnt      = 0;
#endif
    }
}

/**
 * commanderGetSetpoint — 对应原始 commanderGetSetpoint
 *
 * V9 核心修正: 定高/定点只在传感器可用时启用
 *   - mode.z = modeVelocity 需要 getIsBaroPresent()
 *   - mode.x/y = modeAbs   需要光流 (本平台不支持, 永远 modeDisable)
 */
/* ══════════════════════════════════════════════════════════════
 * 【段落】commanderGetSetpoint — 每10ms产出"最终设定点"的总装线
 *   这段做了什么(顺序即优先级, 后面的可覆盖前面的):
 *   ① ctrlDataUpdate(失联判定/缓判/桿量整备) → ② 武装判定 s_thrArmed
 *   ③ if(!isRCLocked) 门内: 定高分支(keyFlight飞行/keyLand→flyerAutoLand/
 *      空中丢keyFlight保持) 或 手动分支 — position_pid 只认 keyFlight/keyLand
 *   ④ 失联注入段(模式1/2): 悬停(keyFlight通道)→超时→keyLand 降落;
 *      手动失联强制进定高; baroLoss 优先时让位(V23.29)
 *   ⑤ 气压失效保护(开环缓收) → ⑥ modeAbs 目标钳位(V23.18 防目标飞天)
 *   ⑦ 急停块(最高优先): thrust=0 + 清一切飞行/失联状态
 * ══════════════════════════════════════════════════════════════ */
void commanderGetSetpoint(setpoint_t* sp, state_t* state) {
    ctrlDataUpdate();

    const bool hasBaro = getIsBaroPresent();   /* V9: BMP280 存在性检查 */
    if (!hasBaro) { commander.keyFlight = 0; commander.keyLand = 0; }  /* V22.97: 无气压计→一键起飞/降落直接清(无意义且危险) */

    /* V22.97: 起转安全锁【中央化】— 修"无GY-91定高模式一解锁电机自动转"。
     * 根因: 下一行原本【无条件】把摇杆油门给sp(定高摇杆中位=中等值), 无气压计时后面没有
     * 分支覆盖它 → 解锁即转。V22.89的锁只盖了降级手动分支, 没盖这条主路。现在放源头:
     * 锁定期间复位 → 每次解锁必须【油门压到底一次】才放行(所有FC标准武装行为);
     * 有气压计且已在空中(z>20cm)视为已武装(防定高飞行中切换被误切)。
     * ⚠边界: 无气压计空中失联>1s恢复且杆未在底 → 需点一下底恢复油门(失联期本就在缓降)。 */
    if (isRCLocked) s_thrArmed = false;
    if (ctrlValLpf.thrust < (float)MIN_THRUST ||
        powerGetLastThrust() > (uint16_t)MIN_THRUST) s_thrArmed = true;   /* V23.06: 在飞判据改真实油门 */
    sp->thrust        = s_thrArmed ? ctrlValLpf.thrust : 0.0f;   /* V23.01: 中位参考映射已按你要求去除 → 杆量直通(定高档+无baro回中=50%会转, 见config说明) */
    /* V22.96: 摇杆死区 — 中位小量置0(yaw防航向目标爬行; RP默认关) */
    #define _DB(v,d) ((fabsf(v) < (d)) ? 0.0f : (v))
    sp->attitude.roll = _DB(ctrlValLpf.roll,  RC_DEADBAND_RP);
    sp->attitude.pitch= _DB(ctrlValLpf.pitch, RC_DEADBAND_RP);
#if REMOTE_YAW_INVERT
    sp->attitude.yaw  = -_DB(ctrlValLpf.yaw, RC_DEADBAND_YAW);   /* V22.23: 对齐原版(摇杆方向和yaw方向相反) */
#else
    sp->attitude.yaw  = _DB(ctrlValLpf.yaw, RC_DEADBAND_YAW);
#endif

    /* 默认: 纯姿态模式 */
    sp->mode.x = modeDisable; sp->mode.y = modeDisable;
    sp->mode.z = modeDisable;
    sp->mode.roll  = modeDisable; sp->mode.pitch = modeDisable;

    state->isRCLocked = isRCLocked;

    if (!isRCLocked) {
        sp->mode.x = modeDisable; sp->mode.y = modeDisable;   /* 本平台无光流, XY 永远纯姿态 */

        if ((commander.ctrlMode & 0x01) && hasBaro) {
            /* ════ 定高模式 (有气压计) ── 对应原版 commanderGetSetpoint ════ */
            if (commander.keyLand) {
                flyerAutoLand(sp, state);                 /* 一键降落 */
            } else if (commander.keyFlight) {
                /* 一键起飞: 自动升到 80cm; 油门杆(中位附近)调爬升/下降速度 */
                sp->thrust = 0;
                sp->mode.z = modeAbs;
                if (!s_initHigh) {
                    s_initHigh = true;
                    s_isAdjustingPosZ = false;
                    s_errorPosZ = 0.0f;
                    setFastAdjustPosParam(0, 1, ALTHOLD_TAKEOFF_HEIGHT);   /* 起飞高度(config.h) */
                }
                if (s_graceLockPending){ s_graceLockPending=false; s_isAdjustingPosZ=false; sp->position.z=state->position.z; s_errorPosZ=0.0f; }   /* V23.29锁高 */
                float climb = (ctrlValLpf.thrust - 32767.0f) / 32767.0f;
                climb *= (climb > 0.0f) ? MAX_CLIMB_UP : MAX_CLIMB_DOWN;
                if (fabsf(climb) > 5.0f) {                /* 推/拉杆 → 爬升/下降 */
                    s_isAdjustingPosZ = true;
                    sp->mode.z = modeVelocity;
                    sp->velocity.z = climb;
                    /* V22.28: 油门杆下拉过大 + 着陆冲击 → 触地停机(对照原版)。
                     * 用独立静态变量(与一键降落的 min/max 互不干扰)。 */
                    static float s_stickMaxAccZ = 0.0f;
                    if (climb < -(MAX_CLIMB_UP / 5.0f)) { /* 下降指令 > 20cm/s */
                        if (isExitFlip) {
                            if (s_stickMaxAccZ < state->acc.z) s_stickMaxAccZ = state->acc.z;
                            if (s_stickMaxAccZ > ALTHOLD_TD_STICK_ACC) {   /* 触地冲击 */
                                s_stickMaxAccZ = 0.0f;
                                commander.keyFlight = false;
                                estRstAll();
                            }
                        }
                    } else {
                        s_stickMaxAccZ = 0.0f;
                    }
                } else if (s_isAdjustingPosZ) {           /* 回中 → 锁定当前高度 */
                    s_isAdjustingPosZ = false;
                    sp->mode.z = modeAbs;
                    sp->position.z = state->position.z + s_errorPosZ;
                } else {                                  /* 保持: 记录位移误差 */
                    s_errorPosZ = cmdConstrainf(sp->position.z - state->position.z, -10.0f, 10.0f);
                }
            } else if (powerGetLastThrust() > (uint16_t)MIN_THRUST) {   /* V23.06: 空中(电机在推)丢keyFlight→保持 */
                /* V23.04: 【空中丢失 keyFlight】→ 保持当前高度, 绝不切电!
                 * 原代码此处 modeDisable+thrust=0 → 任何让 keyFlight 空中变0的路径
                 * (触地误判V22.28杆猛拉+颠簸冲击 / 遥控器关机瞬间发上锁清标志 / 其它)
                 * 都=瞬时断电掉机 —— 正是"遥控器一关定高直接掉"的机制。
                 * 现改保持: 悬在原地等后续(失联>1s会转缓降; 飞手可重按起飞/降落接管)。 */
                sp->mode.z = modeAbs;
                sp->position.z = state->position.z;
                sp->velocity.z = 0;
                s_initHigh = false;
                s_isAdjustingPosZ = false;
            } else {
                /* V23.04: 地面且未按一键起飞 → 不进入高度保持! 否则解锁瞬间位置环按 thrustBase(38000,
                 * 高于你实际悬停~34k)顶电机 → 自动起飞失控(你实测"有时一解锁就自动起飞")。
                 * 定高起飞只走一键起飞; 空中(z>20)切进定高照常保持不掉。 */
                sp->mode.z = modeDisable;
                sp->thrust = 0;
            }
        } else {
            /* ════ 手动模式, 或 定高但无气压计 ════ */
            sp->mode.z = modeDisable;
            s_initHigh = false;          /* V22.22: 切到手动时复位定高起飞状态(避免再切回定高时不重设80cm) */
            s_isAdjustingPosZ = false;
            /* V22.51: 无气压计时一律【手动油门直通】(即使选了定高)。
             * 原逻辑"选定高+无baro+未按起飞→thrust=0"会在【空中从手动切到定高】时
             * 直接切电机坠落, 且油门杆失效(你说的"不能停止下降")。无 baro 本就没有定高,
             * 直通手动最安全。⚠ 地面中位油门会转桨(同手动模式)→ 起飞前请把油门杆压到底。 */
            sp->thrust = s_thrArmed ? ctrlValLpf.thrust : 0.0f;   /* V23.01: 直通(映射已去除) */
        }

        if (commander.flightMode) {        /* 无头模式 (对照原版: 先置 yawMode 再旋转) */
            yawMode = CAREFREE;
            applyCarefree(sp, state);
        } else {
            yawMode = XMODE;
        }
    }

    /* ── 紧急停机 / 翻倒保护 强制切电机 (V22.22) ──
     * 原版 emerStop 和翻倒检测只清 keyFlight/keyLand, 手动模式油门直通不受影响
     * → 手动飞时急停和翻倒保护都失效(只在定高模式有效)。这里改为: emerStop 一旦置位,
     *   不论手动/定高都强制 thrust=0、电机关。由 CMD_EMER_STOP 和 detecTumbled 置位。
     * 解除: 油门杆回到接近 0 (< MIN_THRUST) 自动解除, 可重新推油门起飞。
     * ⚠ 若要做手动特技(故意翻越60°), 请把 config.h 的 ENABLE_TUMBLE_DISARM 设 0,
     *   否则翻越会被当成翻倒而切机。 */
    /* ── V22.95: 气压计飞行中失效保护 ──
     * 隐患: 定高飞行中 BMP280 死掉/数据冻结 → 高度估计冻结 → 一键起飞位置误差恒在
     * → VZ积分windup → 油门顶满飞天(和"越起越高油门没反应"同型灾难, 但根因是气压硬件)。
     * 保护: 定高模式(ctrlMode定高位)且在飞, 有效气压>500ms没更新 → 关掉吃冻结高度的Z控制器,
     * 从【当前实际油门】(getAltholdThrustFast)起开环缓收≈10%/s → 温柔下来。
     * 气压恢复→自动交还定高; 切手动模式=飞手逃生口(本保护只管定高位)。 */
    if (hasBaro && (commander.ctrlMode & 0x01) && !commander.emerStop) {
        bool baroStale = (sensorsBaroAgeMs() > 800u);
        /* V23.08: 撤销"值冻结>3s"独立条款 — 地面静止空气气压本来就3s不动 → 一按起飞、电机一转
         * 满足在飞判据 → 立即误判"气压失效"→缓收 = 你实测【离地一下就掉】的主凶(与RC_LOSS_ACTION无关,
         * ACTION=0时失联块整段编译剔除)。传感器真冻结的场景由下面窗口位移看门覆盖(commanded爬升无进展)。 */   /* V23.07: 值冻结>3s同算失效(你日志bpa钉1007.1十几秒=此盲区) */
#if CLIMB_STUCK_WATCHDOG
        /* V23.23【文献重构】爬升失控保护 — 监控【油门饱和】而非高度估计。
         * 旧法(V23.07-08)用"气压高度窗口内没涨"判卡死, 但气压高度【本身就是被监控量】=逻辑自指:
         * 桨洗噪声/正常慢爬都会误判(两次误伤起飞的根因)。PX4/ArduPilot 的位置失效保护只在有独立航向源
         * (GPS/光流)时才触发, 从不用被监控量监控自己。
         * 正确判据(不碰高度量): 定高模式下油门持续顶在【接近满】(>MAX_THRUST_LIMIT-2000)超过 CLIMB_STUCK_SAT_S 秒
         * = 控制器已饱和仍够不着目标 = 真失控(不管是估计卡死还是目标错误)→ 转缓降交人。
         * 注意: V23.18 已修绝对目标bug(冲天主因), 此为第二道防线, 且饱和判据对桨洗噪声免疫(油门饱和是持续态)。 */
        {
            static uint16_t s_satCnt = 0;
            uint16_t satLimit = (uint16_t)(CLIMB_STUCK_SAT_S * (float)POSITION_PID_RATE);
            /* 油门饱和阈: position_pid 的油门上限硬编码 60000, 取 58000(=上限-2000)为"接近满" */
            if (sp->mode.z == modeAbs && !s_baroLossActive &&
                powerGetLastThrust() > 58000u && !(s_inGrace||s_rcLossActive)) {
                if (s_satCnt < 60000u) s_satCnt++;
            } else s_satCnt = 0;
            if (s_satCnt >= satLimit) { baroStale = true; s_satCnt = 0; }   /* 饱和超时 → 触发缓降保护 */
        }
        (void)s_climbStuckZ0; (void)s_climbStuckCnt;   /* 旧窗口位移法变量保留避免-Wunused, 逻辑已废弃 */
#else
        (void)s_climbStuckZ0; (void)s_climbStuckCnt;   /* V23.10: 看门默认关 */
#endif
        bool airborneB = (powerGetLastThrust() > (uint16_t)MIN_THRUST);   /* V23.06: 真实油门判在飞(基线免疫) */   /* V23.00: 只认实际离地 — keyFlight在地面按下瞬间=1,
                                                          * 偶发stale会当场吃掉一键起飞("定高没反应/失效")。 */
        if (baroStale && airborneB && !s_baroLossActive) {
            s_baroLossActive = true;
            s_baroLossThr = getAltholdThrustFast();
            if (s_baroLossThr < (float)MIN_THRUST) s_baroLossThr = (float)configParam.thrustBase;
        }
        if (s_baroLossActive) {
            if (!baroStale) {
                s_baroLossActive = false;            /* 气压恢复 → 交还定高 */
            } else {
                commander.keyFlight = 0; commander.keyLand = 0;
                sp->mode.z = modeDisable;            /* 停用吃冻结高度的Z控制器 */
                s_baroLossThr *= 0.999f;             /* 开环缓收 ≈10%/s (本函数100Hz) */
                if (s_baroLossThr < (float)MIN_THRUST) s_baroLossThr = 0;
                sp->thrust = s_baroLossThr;          /* roll/pitch杆仍归飞手(可自己飞下来) */
            }
        }
    }

    /* (V23.15: 原"空中转缓降"块已删 — 上锁=立即切; 关机由失联救援接管, 见 DropToGround) */

#if RC_LOSS_ACTION != 0

    /* ── V22.94: 断信号失控保护执行(悬停等待/缓慢降落) ──
     * 放在所有模式分支之后=最终覆盖Z通道; roll/pitch已被LevelRPY置0(trim仍生效), yaw目标冻结。 */
    if (s_rcLossActive && !commander.emerStop) {
        bool airborne = (powerGetLastThrust() > (uint16_t)MIN_THRUST) || s_rcLossRescue;   /* V23.15: 救援时油门已被切0, 用旗强制走空中分支重启电机 */
        /* V23.14: 修"一锁后旋转掉下"(模式1/2同现) — 根因: isRCLocked 后, if(!isRCLocked) 里的
         * "杆量→sp->attitude" 赋值整段被跳过, sp 冻结在断链前最后一帧; 遥控器关机的最后1-2帧若带
         * 非零yaw(关机毛刺, 与急停同族), 该 yaw【速率】被永久重放 → 匀速自转; roll/pitch残留同理漂移。
         * 修: 失联期间每周期强制姿态归零(yaw=0即锁定当前航向; trim在state_control仍叠加, 水平不受影响)。 */
        if (airborne) {
            sp->attitude.roll = 0.0f; sp->attitude.pitch = 0.0f; sp->attitude.yaw = 0.0f;
        }
        /* V23.06: "在飞"=【真实电机油门>MIN】, 彻底摆脱 z>20 — 你的日志证明基线会被空中切电投毒
         * (alt=-119全程) → z判定全废 → 失联被当"地面"直接切电。真实油门与基线无关: 电机在推=在飞。 */
        if (!airborne) {                             /* 地面失联: 直接停, 绝不自己起飞 */
            ctrlValLpf.thrust = 0; sp->thrust = 0;
            sp->mode.z = modeDisable;                /* V23.04: 关Z控制器(否则位置环带电机跑="关遥控器还在起飞") */
            commander.keyFlight = 0; commander.keyLand = 0;
        } else if (hasBaro) {
            /* ═ V23.27 重写: 弃自造 HoldZ 缓降(被 position_pid 双零门锁死, 从未真正工作过),
             *   全部改走【已验证】的 keyFlight/keyLand 通道(飞手日常路径, 位置环唯一认的开关):
             *   ACTION=1: keyFlight 保持 → 定高分支杆中位=原地悬停; 超时转 keyLand 一键降落。
             *   ACTION=2: 立即 keyLand 一键降落(触地判停由 flyerAutoLand 自带, 删三判据补丁)。 */
            s_rcLossT += 0.01f;                      /* 本函数100Hz */
            ctrlValLpf.thrust = 32767.0f;            /* 杆强制中位: 悬停期 climb=0, 防断链残杆干扰 */
            commander.ctrlMode |= 0x01;              /* V23.27: 手动模式失联也强制进定高分支(有baro才到这) — 否则 keyFlight 通道进不了定高, 手动半油门乱飞 */
            if (s_rcLossPhase == 0) {                /* ACTION=1: 悬停等待(反应窗口) */
                if (!commander.keyFlight) commander.keyFlight = 1;   /* 防断链毛刺恰好清过 */
                commander.keyLand = 0;
                if (s_rcLossT > RC_LOSS_HOVER_MAX_S) s_rcLossPhase = 1;
            }
            if (s_rcLossPhase == 1) {                /* 降落: 复用一键降落 */
                commander.keyFlight = 0; commander.keyLand = 1;
            }
        } else {   /* 无气压计(6DOF): 无高度依据 → 无论ACTION=1还是2, 都只能开环缓收(悬停无法实现)。约10%/s */
            s_rcLossT += 0.01f;                      /* V23.09: 此分支原来不累加计时 → 30s兜底/诊断计时全废 */
            ctrlValLpf.thrust *= 0.999f;             /* 衰减原始杆值 */
            if (ctrlValLpf.thrust < (float)MIN_THRUST) ctrlValLpf.thrust = 0;
            sp->thrust = ctrlValLpf.thrust;
            sp->mode.z = modeDisable;
        }
    }
#endif

    /* V23.18 双保险: 定高绝对目标钳位在 [当前高度-150, 当前高度+150] cm — 任何路径设出的离谱目标
     * (基线漂移/时序竞态)都不会让位置环顶满。正常起飞+80在范围内, 不受影响。 */
    if (sp->mode.z == modeAbs) {
        float lo = state->position.z - 150.0f, hi = state->position.z + 150.0f;
        if (sp->position.z < lo) sp->position.z = lo;
        if (sp->position.z > hi) sp->position.z = hi;
    }
    s_dbgTargetZ = (sp->mode.z == modeAbs) ? sp->position.z : -999.0f;   /* V23.08: 心跳zt= */

    if (commander.emerStop) {
        sp->thrust     = 0.0f;
        sp->mode.z     = modeDisable;
        sp->velocity.z = 0.0f;
        commander.keyFlight = 0;
        commander.keyLand   = 0;
        s_initHigh        = false;
        s_isAdjustingPosZ = false;
        s_thrArmed        = false;   /* V22.89: 急停/翻倒后需重新把油门压到底才允许起转 */
        s_rcLossActive    = false;   /* V22.94: 急停清失控保护状态 */
        s_baroLossActive  = false;   /* V22.95: 急停清气压失效保护 */
        s_rcLossRescue    = false;
        if (ctrlValLpf.thrust < MIN_THRUST) commander.emerStop = 0;   /* 油门归零 → 解除 */
    }
}

/* ── 控制接口 ── */
void setCommanderCtrlMode(uint8_t mode) {
#if FORCE_MANUAL_MODE
    commander.ctrlMode = (uint8_t)(mode & ~0x03u);  /* V22.6: 清掉定高/定点位 → 始终手动 */
#else
    commander.ctrlMode = mode;
#endif
}
uint8_t getCommanderCtrlMode(void)         { return commander.ctrlMode;  }
void setCommanderFlightmode(bool s)        { commander.flightMode = s;   }
bool getCommanderFlightmode(void)          { return commander.flightMode; }  /* V22.31: 心跳显示无头模式 */
void setCommanderKeyFlight(bool s)         { commander.keyFlight  = s;
                                             if (s) { s_minAccZ = 0.0f; s_maxAccZ = 0.0f;
#if ALTHOLD_TD_VEL_ENABLE
                                                      s_landWasDescending = false; s_landStuckCnt = 0;
#endif
                                             } }  /* V22.28/30: 一键起飞清零触地检测 */
void setCommanderKeyland(bool s)           { commander.keyLand    = s;   }
void setCommanderEmerStop(bool s)          { commander.emerStop   = s;   }
void setCommanderEmerStopFromRemote(void) {
    /* V23.26: 不再立即置 emerStop — 先 pending, 由 ctrlDataUpdate 依链路存活裁决(见声明处)。
     * V23.15 的"事后救援"保留作第二道防线(pending 误判真上锁+随即关机的极端场景)。 */
    s_emerPending     = true;
    s_emerPendingMs   = millis();
    s_emerPendCacheTs = remoteCache.timestamp;
    s_emerPendKeyClr  = true;
}  /* V22.22/V23.26 */
bool getCommanderEmerStop(void)            { return commander.emerStop;  }  /* V22.22 */
bool getCommanderKeyFlight(void)           { return commander.keyFlight; }
bool getCommanderKeyland(void)             { return commander.keyLand;   }

/* V22.3: 诊断用 —— 让 main.cpp 心跳能显示控制状态 */
bool     commanderGetIsRCLocked(void) { return isRCLocked; }            /* false=正在收遥控数据 */
uint16_t commanderGetThrust(void)     { return (uint16_t)ctrlValLpf.thrust; } /* 当前油门0~65535 */
float commanderGetRcTrimR(void)       { return s_rcTrimR; }   /* V22.75: 遥控器实时横滚trim */
float commanderGetRcTrimP(void)       { return s_rcTrimP; }   /* V22.75: 遥控器实时俯仰trim */
float commanderGetTargetZ(void)       { return s_dbgTargetZ; }   /* V23.10: 定高目标(心跳zt=); 原误插到文件第1行→编译错 */
uint8_t commanderGetStateBits(void) {   /* V23.27a 诊断: bit0=kF 1=kL 2=lock 3=grace 4=active 5=emer 6=定高 */
    return (uint8_t)((commander.keyFlight?1:0)|(commander.keyLand?2:0)|(isRCLocked?4:0)|
           (s_inGrace?8:0)|(s_rcLossActive?16:0)|(commander.emerStop?32:0)|((commander.ctrlMode&0x01)?64:0));
}
char  commanderGetFailsafeChar(void)  { return commander.emerStop ? 'E' : (s_baroLossActive ? 'B' : (s_rcLossActive ? 'R' : 'N')); } /* V23.00: 心跳fs= N无/R失联/B气压 */