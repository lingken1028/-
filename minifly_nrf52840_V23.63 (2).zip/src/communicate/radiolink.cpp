/**
 * @file    radiolink.cpp
 * @brief   nRF52840 裸机 ESB PRX — V19
 *
 * ══ V19 关键修复: 无线中断优先级打死 FreeRTOS 内核 ══
 *
 *   V18 用 NVIC 优先级 3 并在 ISR 内调用 xQueueSendFromISR 等 API。
 *   FreeRTOS 规定: 调用 FromISR 的中断, 其优先级数值必须 ≥
 *   configMAX_SYSCALL_INTERRUPT_PRIORITY (本 BSP 为 4)。
 *   优先级 3 数值过小(过高优先) → 中断可打断内核临界区 →
 *   静默破坏内核数据结构 (configASSERT 在发布版被关闭, 不会报错)。
 *
 *   症状链 (与实测完全吻合):
 *     遥控器一开机发包 → RADIO ISR 高频触发 → 内核被打坏
 *     → 所有任务死亡:
 *        · stabilizer 死  → 摇杆对飞机"无反应"
 *        · usbd 任务死    → XCOM/匿名地面站打开串口永远转圈
 *     → 但 RADIO 硬件 + ISR 本身仍在自动回 ACK
 *        → 遥控器误显示"已连接" (链路灯还在闪)
 *
 *   修复:
 *     1. NVIC_SetPriority(RADIO_IRQn, 6) — 在任何 BSP 配置
 *        (max_syscall=2/4/5) 下都合法, 且低于内核优先级 7
 *     2. ISR 内 millis() 换成 xTaskGetTickCountFromISR()
 *        (millis 不是 ISR 安全 API)
 *     3. 清 EVENTS_END 后回读, 防 nRF52 写缓冲导致的伪重入
 *
 * ── ESB 配置(已实测可与遥控器@1Mbps连接, 与51822原厂逐字一致) ──
 *   载荷: LFLEN=6 S0=0 S1=3 (动态长度+PID+NOACK)
 *   地址: 0x123456789A 逐字节位反转; 频道 2; CRC16 0x11021/0xFFFF
 *   DMA: [0]=LENGTH [1]=S1 [2..]=ATKP(msgID,dataLen,data)
 *   PRX ACK: 插队包(radiolinkTxQueue) > 默认RSSI包
 */
#include "radiolink.h"
#include "atkp.h"
#include "ledseq.h"
#include "../config.h"
#include <nrf.h>
#include <Arduino.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>
#include <string.h>

/* atkp.cpp 创建的全局队列 */
extern QueueHandle_t atkpRxQueue;       /* ISR → atkpRxAnlTask */
extern QueueHandle_t radiolinkTxQueue;  /* 插队ACK (原版语义)  */

#define RADIOLINK_TX_QUEUE_SIZE 30      /* 对应 atkp.cpp 创建深度 */
#define DMA_BUF 34                      /* 1(LEN)+1(S1)+32(MAXLEN) */

static uint8_t s_rxDma[DMA_BUF]     __attribute__((aligned(4)));
static uint8_t s_txDma[DMA_BUF]     __attribute__((aligned(4)));
static uint8_t s_defAck[2][DMA_BUF] __attribute__((aligned(4)));
static volatile uint32_t   s_crcErrCnt   = 0;   /* V23.35 D20 */
static volatile uint32_t   s_bcastRxCnt  = 0;   /* V23.38: 广播包接收计数(验证用) */
static volatile uint32_t   s_rxTotCnt    = 0;   /* V23.38b: CRC通过的总收包数(诊断) */
static volatile uint8_t    s_lastRxMatch = 0xFF;/* V23.38b: 最后一次RXMATCH值(诊断: 0=私有 1=广播) */
static volatile bool       s_inTx        = false;
static volatile bool       s_connected   = false;
static volatile TickType_t s_lastRecvTick= 0;   /* V19: tick 取代 ms */
static volatile uint8_t    s_rssi        = 0;
static bool                s_isInit      = false;

/* ── NRF24L01+(MSB先发) ↔ nRF52840(LSB先发) 地址位反转 ── */
static uint32_t swapBits(uint32_t v) {
    v &= 0xFF; uint32_t r = 0;
    for (int i = 0; i < 8; i++) r |= ((v >> i) & 1) << (7-i);
    return r;
}
static uint32_t bytewiseSwap(uint32_t v) {
    return (swapBits(v    )<<24)|(swapBits(v>> 8)<<16)
          |(swapBits(v>>16)<< 8)|(swapBits(v>>24)    );
}

/* ── 默认 RSSI ACK (心跳应答, 对应51822 U_RADIO_RSSI) ── */
static void buildRssiAck(uint8_t idx) {
    s_defAck[idx][0] = 4;            /* LENGTH */
    s_defAck[idx][1] = 0;            /* S1 */
    s_defAck[idx][2] = UP_RADIO;     /* 0x40 */
    s_defAck[idx][3] = 2;
    s_defAck[idx][4] = 0x01;         /* U_RADIO_RSSI */
    s_defAck[idx][5] = s_rssi;
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】radioHwInit — 把 nRF52840 的 RADIO 配置成"能听懂原厂遥控器"的样子
 *   这段做了什么(按顺序):
 *   ① 复位外设并等待 Disabled(干净起点)
 *   ② 中断优先级设 6 + 使能(V19 教训: 优先级过高会打死 FreeRTOS 内核)
 *   ③ 发射功率 +4dBm、速率 1Mbps、频道号(2400+ch MHz)
 *   ④ PCNF0/PCNF1: 空中包格式 = 6bit长度域 + 3bit S1(PID+NOACK),
 *      4字节BASE+1字节PREFIX 地址, 最大载荷 32, 大端, 不白化 — 与51822逐字一致
 *   ⑤ 地址写入: 每字节先【位反转】再进暂存器(两颗芯片空中位序相反的补偿)
 *   ⑥ CRC16-CCITT(0x11021/初值0xFFFF) — 与遥控器约定一致
 *   ⑦ SHORTS 硬件级联: READY→START(自动开始)/ADDRESS→RSSI采样/DISABLED→RXEN
 *   ⑧ 只开 END 中断(收/发完成各触发一次)
 * ══════════════════════════════════════════════════════════════ */
static void radioHwInit(uint8_t ch, uint8_t rate, const uint8_t* addr5) {
    NRF_RADIO->TASKS_DISABLE = 1;
    { uint32_t t = 100000;
      while (((NRF_RADIO->STATE) & RADIO_STATE_STATE_Msk)
                 != RADIO_STATE_STATE_Disabled && --t) {} }
    NRF_RADIO->POWER = 0; delayMicroseconds(20); NRF_RADIO->POWER = 1;

    /* ★ V19: 优先级 6 — FromISR 在任何 BSP 配置下均合法 ★ */
    NVIC_SetPriority(RADIO_IRQn, 6);
    NVIC_ClearPendingIRQ(RADIO_IRQn);
    NVIC_EnableIRQ(RADIO_IRQn);

    NRF_RADIO->TXPOWER = RADIO_TXPOWER_TXPOWER_Pos8dBm << RADIO_TXPOWER_TXPOWER_Pos;   /* V23.35 D17 */

    /* nRF52840 仅支持 1M/2M NRF模式 (遥控器须改 1Mbps, 已实测连接) */
    if (rate == 2)
        NRF_RADIO->MODE = RADIO_MODE_MODE_Nrf_2Mbit << RADIO_MODE_MODE_Pos;
    else
        NRF_RADIO->MODE = RADIO_MODE_MODE_Nrf_1Mbit << RADIO_MODE_MODE_Pos;
    NRF_RADIO->FREQUENCY = ch & 0x7F;

    /* ESB 动态载荷: LFLEN=6bit长度域, S1=3bit(PID2+NOACK1) */
    NRF_RADIO->PCNF0 = (6UL << RADIO_PCNF0_LFLEN_Pos)
                     | (0UL << RADIO_PCNF0_S0LEN_Pos)
                     | (3UL << RADIO_PCNF0_S1LEN_Pos);

    NRF_RADIO->PCNF1 = (RADIO_PCNF1_WHITEEN_Disabled << RADIO_PCNF1_WHITEEN_Pos)
                     | (RADIO_PCNF1_ENDIAN_Big       << RADIO_PCNF1_ENDIAN_Pos)
                     | (4UL  << RADIO_PCNF1_BALEN_Pos)
                     | (32UL << RADIO_PCNF1_MAXLEN_Pos);

    /* 5字节地址: addr5[0]=LSB ... addr5[4]=空中MSB, 逐字节位反转 */
    uint64_t addr = ((uint64_t)addr5[4]<<32)|((uint32_t)addr5[3]<<24)
                  | ((uint32_t)addr5[2]<<16)|((uint32_t)addr5[1]<< 8)
                  | (uint32_t)addr5[0];
    NRF_RADIO->PREFIX0 = 0xC4C30000UL
                       | ((swapBits((uint32_t)RADIO_BCAST_ADDR) & 0xFF) << 8)  /* V23.38: AP1=广播地址低字节 */
                       | (swapBits((uint32_t)addr) & 0xFF);                     /* AP0=私有地址低字节 */
    NRF_RADIO->PREFIX1 = 0xC5C6C7C8UL;
    NRF_RADIO->BASE0   = bytewiseSwap((uint32_t)(addr >> 8));
    NRF_RADIO->BASE1   = bytewiseSwap((uint32_t)(RADIO_BCAST_ADDR >> 8));  /* V23.38: 逻辑地址1=广播(原占位0x00C2C2C2) */
    NRF_RADIO->TXADDRESS   = 0;   /* ACK 只从私有地址发出 */
#if RADIO_BCAST_EN
    NRF_RADIO->RXADDRESSES = 0x03;   /* V23.38: pipe0(私有)+pipe1(广播) */
#else
    NRF_RADIO->RXADDRESSES = 0x01;   /* pipe 0 */
#endif

    NRF_RADIO->CRCCNF  = RADIO_CRCCNF_LEN_Two << RADIO_CRCCNF_LEN_Pos;
    NRF_RADIO->CRCINIT = 0xFFFFUL;
    NRF_RADIO->CRCPOLY = 0x11021UL;

    /* SHORTS: READY→START, ADDRESS→RSSISTART, DISABLED→RXEN */
    NRF_RADIO->SHORTS = RADIO_SHORTS_READY_START_Msk
                      | RADIO_SHORTS_ADDRESS_RSSISTART_Msk
                      | RADIO_SHORTS_DISABLED_RXEN_Msk;

    NRF_RADIO->INTENCLR = 0xFFFFFFFF;
    NRF_RADIO->INTENSET = RADIO_INTENSET_END_Msk;

    s_inTx = false;
    NRF_RADIO->PACKETPTR = (uint32_t)s_rxDma;
}

static void startRx(void) {
    NRF_RADIO->EVENTS_READY = 0;
    NRF_RADIO->TASKS_RXEN   = 1;   /* READY→START SHORT 自动开始接收 */
}

/* ════════════════════════════════════════════════════════════
 * V22.2: 启动外部高频晶振 HFXO —— 修"拔USB即断线"
 *
 * nRF52840 的 RADIO 必须用 HFXO(外部晶振)才能可靠收发; 内部 RC(HFINT)
 * 频率误差太大, 射频基本不工作。插着 USB 时, USBD 外设需要 HFXO,
 * 于是顺带把 HFXO 打开了 → 无线能用; 一拔 USB, HFXO 请求消失, 时钟回落
 * 到 RC → 无线瞬间死。这里显式启动 HFXO 并在任务里持续保持, 使无线
 * 在纯电池(无USB)下也能工作。
 * 幂等: 已从晶振运行则直接返回; 安全可重复调用。
 * ════════════════════════════════════════════════════════════ */
static void hfclkStartXTAL(void) {
    /* 已经在用外部晶振 → 无需再启动 */
    if ( (NRF_CLOCK->HFCLKSTAT &
          (CLOCK_HFCLKSTAT_SRC_Msk | CLOCK_HFCLKSTAT_STATE_Msk))
         == ((CLOCK_HFCLKSTAT_SRC_Xtal   << CLOCK_HFCLKSTAT_SRC_Pos) |
             (CLOCK_HFCLKSTAT_STATE_Running << CLOCK_HFCLKSTAT_STATE_Pos)) ) {
        return;
    }
    NRF_CLOCK->EVENTS_HFCLKSTARTED = 0;
    NRF_CLOCK->TASKS_HFCLKSTART    = 1;
    uint32_t t = 500000;
    while (!NRF_CLOCK->EVENTS_HFCLKSTARTED && --t) { /* 等晶振起振(典型<1ms) */ }
    NRF_CLOCK->EVENTS_HFCLKSTARTED = 0;
}

static void radioStart(void) {
    hfclkStartXTAL();                  /* V22.2: 先确保 HFXO 运行 */
    uint8_t addr[5];
    addr[0] = (uint8_t)((ESB_ADDR_LOW  >>  0) & 0xFF);
    addr[1] = (uint8_t)((ESB_ADDR_LOW  >>  8) & 0xFF);
    addr[2] = (uint8_t)((ESB_ADDR_LOW  >> 16) & 0xFF);
    addr[3] = (uint8_t)((ESB_ADDR_LOW  >> 24) & 0xFF);
    addr[4] = (uint8_t)((ESB_ADDR_HIGH >>  0) & 0xFF);
    buildRssiAck(0); buildRssiAck(1);
    radioHwInit(ESB_DEFAULT_CHANNEL, 1 /*1Mbps*/, addr);
    startRx();
}

void radiolinkInit(void) { s_isInit = true; }

/* 对应原版 radiolinkSendPacket — 入插队ACK队列 (下次RX时回传) */
bool radiolinkSendPacket(const atkp_t* p) {
    if (!p || !radiolinkTxQueue) return false;
    return xQueueSend(radiolinkTxQueue, p, 0) == pdTRUE;
}
bool radiolinkSendPacketBlocking(const atkp_t* p) {
    if (!p || !radiolinkTxQueue) return false;
    return xQueueSend(radiolinkTxQueue, p, pdMS_TO_TICKS(10)) == pdTRUE;
}
int radiolinkGetFreeTxQueuePackets(void) {
    if (!radiolinkTxQueue) return RADIOLINK_TX_QUEUE_SIZE;
    return (int)(RADIOLINK_TX_QUEUE_SIZE - uxQueueMessagesWaiting(radiolinkTxQueue));
}

/* V22: 供 main.cpp 心跳诊断 */
bool radiolinkIsConnected(void) { return s_connected; }
#if RADIO_BCAST_EN
uint32_t radiolinkBcastRxCnt(void) { return s_bcastRxCnt; }  /* V23.38: 广播接收计数(日志验证) */
uint32_t radiolinkRxTotCnt(void)   { return s_rxTotCnt; }    /* V23.38b: 总收包数 */
uint8_t  radiolinkLastRxMatch(void){ return s_lastRxMatch; } /* V23.38b: 最后RXMATCH */
#endif

/* ── RADIO 中断: RX END→解析→ACK→TX; TX END→回RX ──
 * V19: 优先级6合法调用 FromISR; tick 用 ISR 安全 API           */
extern "C" void RADIO_IRQHandler(void) {
    if (!NRF_RADIO->EVENTS_END) return;
    NRF_RADIO->EVENTS_END = 0;
    (void)NRF_RADIO->EVENTS_END;     /* V19: 回读防写缓冲伪重入 */

    if (!s_inTx) {
        /* ══【RX 完成分支】这段做了什么: ══
         * ① CRC 错 → 直接重开接收(坏包丢弃, 见 D20: 暂未计数)
         * ② CRC 对 → 记 RSSI + 刷新"最后收包时刻" + 置已连线
         * ③ 把空中包 [LEN][S1][msgID][dataLen][data..] 组装成 atkp_t 塞进
         *    atkpRxQueue 交上层解析(dataLen 钳位防畸形包外溢, V22.25)
         * ④ 挑 ACK 载荷: 有下行包排队(遥测/回执)就"搭 ACK 顺风车"插队发出,
         *    没有就发默认 RSSI 心跳包 — 这就是 ESB PRX 的下行带宽复用
         * ⑤ 改 SHORTS 让硬件自动 DISABLE→TXEN→发送 ACK */
        if (!NRF_RADIO->CRCSTATUS) {
            s_crcErrCnt++;
            NRF_RADIO->TASKS_START = 1;   /* CRC错, 继续收 */
            return;
        }
        s_rssi         = (uint8_t)NRF_RADIO->RSSISAMPLE;
        s_lastRecvTick = xTaskGetTickCountFromISR();  /* V19 */
        s_connected    = true;
#if RADIO_BCAST_EN
        uint8_t rxmatch = (uint8_t)NRF_RADIO->RXMATCH;  /* V23.38: 0=私有pipe0, 1=广播pipe1 (ADDRESS事件锁存, END读取有效) */
        s_rxTotCnt++;                 /* V23.38b诊断: 每个CRC通过的包都计 */
        s_lastRxMatch = rxmatch;      /* V23.38b诊断: 记录实际匹配的逻辑地址 */
#endif

        if (s_rxDma[0] >= 2) {
            atkp_t pkt;
            pkt.msgID   = s_rxDma[2];
            uint8_t dl  = s_rxDma[3] < ATKP_MAX_DATA_SIZE
                        ? s_rxDma[3] : ATKP_MAX_DATA_SIZE;
            pkt.dataLen = dl;   /* V22.25: 钳位与实拷贝量一致, 畸形包 dataLen 不外溢给下游解析器 */
            memcpy(pkt.data, s_rxDma + 4, dl);

            BaseType_t woken = pdFALSE;
            if (atkpRxQueue)
                xQueueSendFromISR(atkpRxQueue, &pkt, &woken);

#if RADIO_BCAST_EN
            /* ══ V23.38: 广播包分流 ══
             * 广播(pipe1)【绝不回ACK】— N 机同时应答必在空中碰撞。
             * 指令已进队、链路活跃已刷新(上方), 直接继续监听下一包。
             * 私有(pipe0)走原有"搭ACK顺风车"流程不变。 */
            if (rxmatch != 0) {
                s_bcastRxCnt++;
                NRF_RADIO->TASKS_START = 1;   /* 继续收, 不进TX */
                portYIELD_FROM_ISR(woken);
                return;
            }
#endif

            /* 选ACK: 插队包优先, 否则默认RSSI包 */
            atkp_t txPkt;
            if (radiolinkTxQueue &&
                xQueueReceiveFromISR(radiolinkTxQueue, &txPkt, &woken) == pdTRUE) {
                uint8_t dl2 = txPkt.dataLen < ATKP_MAX_DATA_SIZE ? txPkt.dataLen : ATKP_MAX_DATA_SIZE;
                s_txDma[0] = (uint8_t)(2 + dl2);
                s_txDma[1] = 0;
                s_txDma[2] = txPkt.msgID;
                s_txDma[3] = dl2;   /* V23.21: header长度用钳位值(原用未钳位txPkt.dataLen → 若>30, 接收方按声明长度会读到s_txDma未初始化尾部); 魔数30→宏 */
                memcpy(s_txDma + 4, txPkt.data, dl2);
                NRF_RADIO->PACKETPTR = (uint32_t)s_txDma;
            } else {
                s_defAck[0][5] = s_rssi;
                NRF_RADIO->PACKETPTR = (uint32_t)s_defAck[0];
            }

            NRF_RADIO->SHORTS = RADIO_SHORTS_READY_START_Msk
                              | RADIO_SHORTS_DISABLED_TXEN_Msk;
            s_inTx = true;
            NRF_RADIO->TASKS_DISABLE = 1;   /* → TXEN → READY → START */

            portYIELD_FROM_ISR(woken);
        } else {
            NRF_RADIO->TASKS_START = 1;
        }
    } else {
        /* ══【TX 完成分支】这段做了什么: ══
         * ACK 已发出 → 把 DMA 指针换回接收缓冲、SHORTS 换回"发完自动回收模式",
         * 硬件自动 DISABLE→RXEN→继续监听下一包。一收一答的乒乓循环闭合。 */
        s_inTx = false;
        NRF_RADIO->PACKETPTR = (uint32_t)s_rxDma;
        NRF_RADIO->SHORTS = RADIO_SHORTS_READY_START_Msk
                          | RADIO_SHORTS_ADDRESS_RSSISTART_Msk
                          | RADIO_SHORTS_DISABLED_RXEN_Msk;
        NRF_RADIO->TASKS_DISABLE = 1;       /* → RXEN → READY → START */
    }
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】radiolinkTask — 无线的"后勤任务"(优先级P5, 5ms一轮)
 *   这段做了什么: ①启动无线; ②每轮确保 HFXO 外部晶振还活着
 *   (拔USB时USB栈可能释放它, 无线会瞬死 — V22.2教训); ③收包就闪LED;
 *   ④超过 RADIOLINK_TIMEOUT_MS 没包 → 只清"已连线"旗(给LED/心跳诊断用,
 *   真正的失控保护判定在 commander 的 1000ms, 两者分工见 D19)。
 *   【方法一落点 D21】时槽寄生信标的 BLE 窗口将插在此循环中。
 * ══════════════════════════════════════════════════════════════ */
void radiolinkTask(void* param) {
    (void)param;
    radioStart();

    TickType_t prevRecv = 0;
    while (1) {
        /* V22.2: 每轮确保 HFXO 仍在运行。USB 拔出时 USB 栈可能释放 HFXO,
         * 这里幂等地把它重新拉起来(已在运行则是一次寄存器读, 无副作用),
         * 使无线在纯电池下不会因时钟回落到内部RC而掉线。 */
        hfclkStartXTAL();

        TickType_t lr = s_lastRecvTick;
        if (lr != prevRecv) {
            prevRecv = lr;
            ledseqRun(DATA_RX_LED, seq_linkup);   /* 有遥控数据 */
        } else if (s_connected &&
                   (xTaskGetTickCount() - lr) > pdMS_TO_TICKS(RADIOLINK_TIMEOUT_MS)) {
            s_connected = false;                  /* 断线 */
        }
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}

uint32_t radiolinkGetCrcErrCount(void) { return s_crcErrCnt; }
