/**
 * @file    ledseq.cpp
 * @brief   LED 序列控制完整实现
 *          对应: COMMUNICATE/src/ledseq.c (逐字对照)
 *
 * 原始 ledseq.c 关键设计:
 *   sequences[] 按优先级排列 (优先级0=最高):
 *     [0] seq_lowbat     低电量    (1秒常亮循环)
 *     [1] seq_charged    充电完成  (1秒常亮循环)
 *     [2] seq_charging   充电中    (200ms亮/800ms灭循环)
 *     [3] seq_calibrated 校准完成  (50ms亮/450ms灭循环)
 *     [4] seq_alive      开机心跳  (50ms亮/1950ms灭循环)
 *     [5] seq_linkup     通信闪烁  (1ms亮/0ms灭, STOP)
 *
 *   state[LED_NUM][SEQ_NUM]: 每个LED每个序列的当前步骤
 *   activeSeq[LED_NUM]: 每个LED当前激活的最高优先级序列
 *   timer[LED_NUM]: 每个LED一个 FreeRTOS xTimerHandle
 *
 *   ledseqRun():  设置 state[led][prio]=0, 更新 activeSeq, 启动定时器
 *   ledseqStop(): 设置 state[led][prio]=LEDSEQ_STOP, 更新 activeSeq
 *   runLedseq():  定时器回调, 执行当前步骤, 设置LED, 启动下一步定时
 *   updateActive():找当前LED state非STOP的最高优先级序列
 *
 * 移植: xTimerCreate/xTimerChangePeriod 完全保留
 *       单颗LED (D6) → 只有 SYS_LED/LOWBAT/DATA 映射到物理GPIO
 */
#include "ledseq.h"
#include "../hardware/led.h"
#include <Arduino.h>
#include <FreeRTOS.h>
#include <timers.h>
#include <semphr.h>

/* ── 序列定义 (对应 ledseq.c 逐字对照) ── */
const ledseq_t seq_lowbat[] = {
    { true,  LEDSEQ_WAITMS(1000) },
    { false, LEDSEQ_LOOP },
};
const ledseq_t seq_calibrated[] = {
    { true,  LEDSEQ_WAITMS(50)  },
    { false, LEDSEQ_WAITMS(450) },
    { false, LEDSEQ_LOOP },
};
const ledseq_t seq_alive[] = {
    { true,  LEDSEQ_WAITMS(50)   },
    { false, LEDSEQ_WAITMS(1950) },
    { false, LEDSEQ_LOOP },
};
const ledseq_t seq_linkup[] = {
    { true,  LEDSEQ_WAITMS(1) },
    { false, LEDSEQ_WAITMS(0) },
    { false, LEDSEQ_STOP },
};
const ledseq_t seq_charged[] = {
    { true,  LEDSEQ_WAITMS(1000) },
    { false, LEDSEQ_LOOP },
};
const ledseq_t seq_charging[] = {
    { true,  LEDSEQ_WAITMS(200) },
    { false, LEDSEQ_WAITMS(800) },
    { false, LEDSEQ_LOOP },
};

/* sequences[] 数组按优先级排列 (对应原始 ledseq.c sequences[]) */
static const ledseq_t* sequences[SEQ_NUM] = {
    seq_lowbat,     /* prio 0 最高 */
    seq_charged,
    seq_charging,
    seq_calibrated,
    seq_alive,
    seq_linkup,     /* prio 5 最低 */
};

static bool            s_isInit = false;
static bool            s_en     = true;
static int             s_activeSeq[LED_NUM];
static int             s_state[LED_NUM][SEQ_NUM];
static TimerHandle_t   s_timer[LED_NUM];
static SemaphoreHandle_t s_sem  = NULL;

/* 前向声明 */
static void updateActive(led_e led);
static int  getPrio(const ledseq_t* seq);
static void runLedseq(TimerHandle_t xTimer);

/*─────────────────────────────────────────────────────
  ledseqInit — 对应原始 ledseqInit()
─────────────────────────────────────────────────────*/
void ledseqInit(void) {
    if (s_isInit) return;
    ledInit();
    /* 初始化所有序列状态 */
    for (int i=0; i<LED_NUM; i++) {
        s_activeSeq[i] = LEDSEQ_STOP;
        for (int j=0; j<SEQ_NUM; j++)
            s_state[i][j] = LEDSEQ_STOP;
    }
    /* 每个LED创建一个软件定时器 */
    for (int i=0; i<LED_NUM; i++) {
        s_timer[i] = xTimerCreate("ledseqTimer", pdMS_TO_TICKS(1000),
                                   pdFALSE, (void*)(intptr_t)i, runLedseq);
    }
    s_sem = xSemaphoreCreateBinary();
    xSemaphoreGive(s_sem);
    s_isInit = true;
}

bool ledseqTest(void) {
    bool ok = s_isInit && ledTest();
    ledseqEnable(true);
    return ok;
}

void ledseqEnable(bool enable) { s_en = enable; }

/*─────────────────────────────────────────────────────
  ledseqRun — 对应原始 ledseqRun()
  启动 led 的 sequence 序列
─────────────────────────────────────────────────────*/
void ledseqRun(led_e led, const ledseq_t* sequence) {
    int prio = getPrio(sequence);
    if (prio < 0) return;
    xSemaphoreTake(s_sem, portMAX_DELAY);
    s_state[led][prio] = 0;
    updateActive(led);
    xSemaphoreGive(s_sem);
    if (s_activeSeq[led] == prio)
        runLedseq(s_timer[led]);
}

/*─────────────────────────────────────────────────────
  ledseqStop — 对应原始 ledseqStop()
─────────────────────────────────────────────────────*/
void ledseqStop(led_e led, const ledseq_t* sequence) {
    int prio = getPrio(sequence);
    if (prio < 0) return;
    xSemaphoreTake(s_sem, portMAX_DELAY);
    s_state[led][prio] = LEDSEQ_STOP;
    updateActive(led);
    xSemaphoreGive(s_sem);
    runLedseq(s_timer[led]);
}

/*─────────────────────────────────────────────────────
  runLedseq — 对应原始 runLedseq(xTimerHandle)
  FreeRTOS 定时器回调, 驱动序列步骤机
─────────────────────────────────────────────────────*/
static void runLedseq(TimerHandle_t xTimer) {
    bool leave = false;
    led_e led  = (led_e)(intptr_t)pvTimerGetTimerID(xTimer);

    if (!s_en) return;

    while (!leave) {
        int prio = s_activeSeq[led];
        if (prio == LEDSEQ_STOP) return;

        const ledseq_t* step = &sequences[prio][s_state[led][prio]];
        s_state[led][prio]++;

        xSemaphoreTake(s_sem, portMAX_DELAY);
        switch (step->action) {
        case LEDSEQ_LOOP:
            s_state[led][prio] = 0;
            break;
        case LEDSEQ_STOP:
            s_state[led][prio] = LEDSEQ_STOP;
            updateActive(led);
            break;
        default:   /* 定时动作: 设置LED, 启动定时器 */
            ledSet(led, step->value);
            if (step->action == 0) break;   /* 0ms → 立即进入下一步 */
            xTimerChangePeriod(xTimer, pdMS_TO_TICKS(step->action), 0);
            xTimerStart(xTimer, 0);
            leave = true;
            break;
        }
        xSemaphoreGive(s_sem);
    }
}

/*─────────────────────────────────────────────────────
  getPrio — 对应原始 getPrio()
─────────────────────────────────────────────────────*/
static int getPrio(const ledseq_t* seq) {
    for (int p=0; p<SEQ_NUM; p++)
        if (sequences[p] == seq) return p;
    return -1;
}

/*─────────────────────────────────────────────────────
  updateActive — 对应原始 updateActive()
  找 led 当前非 STOP 的最高优先级序列
─────────────────────────────────────────────────────*/
static void updateActive(led_e led) {
    ledSet(led, false);
    s_activeSeq[led] = LEDSEQ_STOP;
    for (int p=0; p<SEQ_NUM; p++) {
        if (s_state[led][p] != LEDSEQ_STOP) {
            s_activeSeq[led] = p;
            break;
        }
    }
}