/**
 * @file    usblink.cpp — V21
 *
 * V21 修正: 去掉开机"清残留"——它会把地面站在启动窗口内发来的
 *   读取指令整帧吃掉 (实测: 启动期连接+读取下位机信息无反应)。
 *   状态机本身可正确跳过任何垃圾字节, 无需清空。
 *
 * V20 特性保留:
 *   TX 用 tud_cdc_write 直写FIFO (不依赖DTR, XCOM不勾DTR也能收)
 *   RX 用 Serial.read (主机→设备方向与DTR无关)
 *   静默闸门 s_usbActive: 收到首个有效DOWN帧才开始上行
 */
#include "usblink.h"
#include "atkp.h"
#include <Arduino.h>
#include <Adafruit_TinyUSB.h>
#include <FreeRTOS.h>
#include <task.h>
#include <queue.h>

#define USBLINK_TX_QUEUE_SIZE 30

static bool                  s_isInit    = false;
static QueueHandle_t         s_txQueue   = NULL;
static volatile bool         s_usbActive = false;
static volatile uint32_t     s_txDrops   = 0;      /* V23.12: 上行丢包计数(队列满+FIFO满), 心跳txd= 定位"上位机卡顿"在设备侧还是主机侧 */  /* 收到首个有效DOWN帧后激活 */

void usblinkInit(void) {
    if (s_isInit) return;
    s_txQueue = xQueueCreate(USBLINK_TX_QUEUE_SIZE, sizeof(atkp_t));
    configASSERT(s_txQueue);
    s_isInit = true;
}

bool usblinkSendPacket(const atkp_t* p) {
    if (!p || !s_isInit || !s_txQueue) return false;
    if (xQueueSend(s_txQueue, p, 0) == pdTRUE) return true;
    s_txDrops++;                                    /* V23.12: 队列满丢包 */
    return false;
}

int usblinkGetFreeTxQueuePackets(void) {
    if (!s_txQueue) return USBLINK_TX_QUEUE_SIZE;
    return (int)(USBLINK_TX_QUEUE_SIZE - uxQueueMessagesWaiting(s_txQueue));
}

void usblinkSetActive(bool v) { s_usbActive = v; }
bool usblinkIsActive(void)    { return s_isInit && s_usbActive; }

/* ══════════════════════════════════════════════════════════════
 * 【段落】usblinkTxTask — 上行打包发往 PC
 *   这段做了什么: 从 txQueue 取 atkp_t → 组线格式
 *   [AA][AA][msgID][LEN][DATA...][SUM] → 静默闸门未开则丢弃(裸串口不刷屏)
 *   → FIFO 有空位就 tud_cdc_write 直写(V20: 不看DTR), 满了计 txDrops(V23.12)
 * ══════════════════════════════════════════════════════════════ */
void usblinkTxTask(void* param) {
    (void)param;
    atkp_t pkt;
    while (1) {
        if (!s_txQueue ||
            xQueueReceive(s_txQueue, &pkt, pdMS_TO_TICKS(10)) != pdTRUE)
            continue;

        if (!s_usbActive) continue;          /* 静默: 丢弃 */

        uint8_t buf[2+1+1+ATKP_MAX_DATA_SIZE+1];
        buf[0] = UP_BYTE1;  buf[1] = UP_BYTE2;
        buf[2] = pkt.msgID; buf[3] = pkt.dataLen;
        for (uint8_t i = 0; i < pkt.dataLen; i++) buf[4+i] = pkt.data[i];
        uint8_t total = 4 + pkt.dataLen;
        uint8_t ck = 0;
        for (uint8_t i = 0; i < total; i++) ck += buf[i];
        buf[total] = ck;

        if (tud_cdc_write_available() >= (uint32_t)(total + 1)) {
            tud_cdc_write(buf, total + 1);
            tud_cdc_write_flush();
        } else {
            s_txDrops++;                            /* V23.12: FIFO满丢包(总线没在排空=噪声/掉压/主机没读) */
        }
    }
}

/* ══════════════════════════════════════════════════════════════
 * 【段落】usblinkRxTask — 逐字节解析 PC 下行帧
 *   这段做了什么: 六态状态机 S1→S2→ID→LEN→DATA→CHK 逐字节吃流,
 *   任何位置的垃圾字节都会让状态机自然回 S1(所以 V21 删掉了开机清残留);
 *   LEN>32 直接弃帧; 校验和通过 → ①激活上行静默闸门 ②整包入 atkpRxQueue。
 * ══════════════════════════════════════════════════════════════ */
void usblinkRxTask(void* param) {
    (void)param;
    uint8_t dataIndex = 0, cksum = 0;
    atkp_t rxPkt;
    enum { S1, S2, ID, LEN, DATA, CHK } state = S1;

    while (1) {
        if (!Serial.available()) { vTaskDelay(pdMS_TO_TICKS(1)); continue; }
        int ci = Serial.read();
        if (ci < 0) continue;
        uint8_t c = (uint8_t)ci;

        switch (state) {
        case S1:
            if (c == DOWN_BYTE1) { state = S2; cksum = c; }
            break;
        case S2:
            if (c == DOWN_BYTE2) { state = ID; cksum += c; }
            else                 { state = S1; }
            break;
        case ID:
            rxPkt.msgID = c; cksum += c; state = LEN;
            break;
        case LEN:
            if (c > ATKP_MAX_DATA_SIZE) { state = S1; break; }
            rxPkt.dataLen = c; cksum += c; dataIndex = 0;
            state = (c == 0) ? CHK : DATA;
            break;
        case DATA:
            rxPkt.data[dataIndex++] = c; cksum += c;
            if (dataIndex >= rxPkt.dataLen) state = CHK;
            break;
        case CHK:
            if (c == cksum) {
                s_usbActive = true;            /* 激活上行 */
                if (atkpRxQueue) xQueueSend(atkpRxQueue, &rxPkt, 0);
            }
            state = S1;
            break;
        }
    }
}

uint32_t usblinkGetTxDrops(void) { return s_txDrops; }   /* V23.12 */
