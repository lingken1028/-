/**
 * @file    comm.h
 * @brief   通信初始化
 *          对应: COMMUNICATE/interface/comm.h
 */
#pragma once
#include <stdbool.h>
void commInit(void);
bool commTest(void);