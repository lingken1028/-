/**
 * @file    filter.h
 * @brief   滤波器接口
 *          对应: COMMON/interface/filter.h (逐字对照)
 *
 * lpf2pData: 二阶 Butterworth 低通滤波器 (Direct Form II)
 *   sensors.c 用于:
 *     gyroLpf[3]: 1000Hz 采样, 80Hz 截止
 *     accLpf[3]:  1000Hz 采样, 30Hz 截止
 *
 * iirLPFilterSingle: 简单 IIR (移位实现, IIR_SHIFT=8)
 */
#pragma once
#include <stdint.h>

#define IIR_SHIFT 8

int16_t iirLPFilterSingle(int32_t in, int32_t attenuation, int32_t* filt);

typedef struct {
    float a1, a2;
    float b0, b1, b2;
    float delay_element_1;
    float delay_element_2;
} lpf2pData;

void  lpf2pInit(lpf2pData* lpfData, float sample_freq, float cutoff_freq);
void  lpf2pSetCutoffFreq(lpf2pData* lpfData, float sample_freq, float cutoff_freq);
float lpf2pApply(lpf2pData* lpfData, float sample);
float lpf2pReset(lpf2pData* lpfData, float sample);

/* V22.27: 二阶陷波(notch)滤波器 — 挖掉某个频率峰(电机/桨叶振动)。
 * 复用 lpf2pData 结构与 lpf2pApply(同为 Direct Form II)。
 *   center_freq: 陷波中心频率 Hz;  Q: 品质因数(越大越窄, 典型 2~8)。
 * notchInit: 设系数并清零延迟(初始化用)。
 * notchSetFreq: 只更新系数、不动延迟(动态变频每周期调用, 不破坏滤波状态)。*/
void  notchInit(lpf2pData* d, float sample_freq, float center_freq, float Q);
void  notchSetFreq(lpf2pData* d, float sample_freq, float center_freq, float Q);