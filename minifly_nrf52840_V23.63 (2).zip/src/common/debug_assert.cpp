/**
 * @file    debug_assert.cpp
 * @brief   断言和崩溃处理实现
 *          对应: COMMON/src/debug_assert.c (逐字对照)
 *
 * 原始固件用 .nzds 节存储崩溃快照以跨复位保留信息，
 * nRF52840 Arduino 框架无此机制，改用全局静态变量替代。
 *
 * assertFail 行为 (完全对应原始):
 *   portDISABLE_INTERRUPTS()
 *   storeAssertSnapshotData(file, line)
 *   Serial.printf → 电机全停 → ledClearAll + ERR_LED 亮 → while(1)
 *
 * MAGIC_ASSERT_INDICATOR = 0x2f8a001f (对应原始)
 */
#include "debug_assert.h"
#include "../hardware/led.h"
#include "../hardware/motors.h"
#include <Arduino.h>
#include <FreeRTOS.h>

#define MAGIC_ASSERT_INDICATOR 0x2f8a001fu

/* 崩溃快照 (对应原始 SNAPSHOT_DATA, 去除 .nzds 段) */
typedef struct {
    uint32_t    magicNumber;
    const char* fileName;
    int         line;
} SNAPSHOT_DATA;

static SNAPSHOT_DATA snapshot = { 0, "", 0 };

/**
 * assertFail — 对应原始 assertFail(char*, char*, int)
 * 停电机 → 亮错误灯 → 死循环
 */
void assertFail(const char* exp, const char* file, int line) {
    portDISABLE_INTERRUPTS();
    storeAssertSnapshotData(file, line);
    Serial.printf("Assert failed %s:%d\n", file, line);

    /* 停止所有电机 (对应原始 motorsSetRatio M1-M4 = 0) */
    motorsSetRatio(MOTOR_M1, 0);
    motorsSetRatio(MOTOR_M2, 0);
    motorsSetRatio(MOTOR_M3, 0);
    motorsSetRatio(MOTOR_M4, 0);

    /* 错误 LED (对应原始 ledClearAll + ERR_LED1/2) */
    ledClearAll();
    ledSet(ERR_LED1, true);
    ledSet(ERR_LED2, true);

    while (1) { /* 死循环, 等待看门狗复位 */ }
}

/**
 * storeAssertSnapshotData — 对应原始
 */
void storeAssertSnapshotData(const char* file, int line) {
    snapshot.magicNumber = MAGIC_ASSERT_INDICATOR;
    snapshot.fileName    = file;
    snapshot.line        = line;
}

/**
 * printAssertSnapshotData — 对应原始
 */
void printAssertSnapshotData(void) {
    if (snapshot.magicNumber == MAGIC_ASSERT_INDICATOR) {
        Serial.printf("Assert failed at %s:%d\n", snapshot.fileName, snapshot.line);
    } else {
        Serial.println("No assert information found");
    }
}