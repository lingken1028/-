/**
 * @file    freertos_hooks.cpp
 * @brief   FreeRTOS 钩子 — V12: 移除与 BSP 重复的实现
 *
 * V12 变更: vApplicationMallocFailedHook / vApplicationStackOverflowHook
 *   由 Adafruit nRF52 BSP rtos.cpp 提供, 此处不重复定义
 */
#include <stdint.h>   /* uint32_t — V12 fix: 补充缺失的类型头文件 */

/* vApplicationMallocFailedHook:  BSP rtos.cpp 提供 */
/* vApplicationStackOverflowHook: BSP rtos.cpp 提供 */

void debugSendTraceInfo(uint32_t taskNbr) { (void)taskNbr; }
void debugInitTrace(void) {}