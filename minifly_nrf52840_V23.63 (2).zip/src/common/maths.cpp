/**
 * @file    maths.cpp
 * @brief   数学工具库实现
 *          对应: COMMON/src/maths.c (Cleanflight, 逐字对照)
 *
 * 包含快速三角近似、统计、向量运算、中值滤波等
 * 在 nRF52840 Arduino 框架下与原始实现完全兼容
 */
#include "maths.h"
#include "axis.h"
#include <string.h>
#include <stdint.h>
#include <math.h>

/* ── 快速三角近似 (FAST_MATH, 9阶 Chebyshev) ─────────────────────
 * 对应原始 maths.c sin_approx/cos_approx/atan2_approx/acos_approx
 */
#if defined(FAST_MATH)

#define sinPolyCoef3 -1.666665710e-1f
#define sinPolyCoef5  8.333017292e-3f
#define sinPolyCoef7 -1.980661520e-4f
#define sinPolyCoef9  2.600054768e-6f

float sin_approx(float x) {
    int32_t xint = (int32_t)x;
    if (xint < -32 || xint > 32) return 0.0f;
    while (x >  M_PIf) x -= (2.0f * M_PIf);
    while (x < -M_PIf) x += (2.0f * M_PIf);
    if (x >  (0.5f * M_PIf)) x =  (0.5f * M_PIf) - (x - (0.5f * M_PIf));
    else if (x < -(0.5f * M_PIf)) x = -(0.5f * M_PIf) - ((0.5f * M_PIf) + x);
    float x2 = x * x;
    return x + x * x2 * (sinPolyCoef3 + x2 * (sinPolyCoef5 + x2 * (sinPolyCoef7 + x2 * sinPolyCoef9)));
}

float cos_approx(float x) { return sin_approx(x + (0.5f * M_PIf)); }

float atan2_approx(float y, float x) {
    #define atanPolyCoef1  3.14551665884836e-07f
    #define atanPolyCoef2  0.99997356613987f
    #define atanPolyCoef3  0.14744007058297684f
    #define atanPolyCoef4  0.3099814292351353f
    #define atanPolyCoef5  0.05030176425872175f
    #define atanPolyCoef6  0.1471039133652469f
    #define atanPolyCoef7  0.6444640676891548f
    float res, absX = fabsf(x), absY = fabsf(y);
    res = MAX(absX, absY);
    if (res) res = MIN(absX, absY) / res; else res = 0.0f;
    res = -((((atanPolyCoef5 * res - atanPolyCoef4) * res - atanPolyCoef3) * res - atanPolyCoef2) * res - atanPolyCoef1)
            / ((atanPolyCoef7 * res + atanPolyCoef6) * res + 1.0f);
    if (absY > absX) res = (M_PIf / 2.0f) - res;
    if (x < 0) res = M_PIf - res;
    if (y < 0) res = -res;
    return res;
}

float acos_approx(float x) {
    float xa = fabsf(x);
    float result = sqrtf(1.0f - xa) * (1.5707288f + xa * (-0.2121144f + xa * (0.0742610f + (-0.0187293f * xa))));
    return (x < 0.0f) ? M_PIf - result : result;
}
#endif  /* FAST_MATH */

/* ── 基本数学工具 ──────────────────────────────────────────────── */
int gcd(int num, int denom) { return denom == 0 ? num : gcd(denom, num % denom); }

int32_t wrap_18000(int32_t a) {
    if (a > 18000)  a -= 36000;
    if (a < -18000) a += 36000;
    return a;
}
int32_t wrap_36000(int32_t a) {
    if (a > 36000) a -= 36000;
    if (a < 0)     a += 36000;
    return a;
}

int32_t applyDeadband(int32_t v, int32_t db) {
    if (ABS(v) < db) return 0;
    return v > 0 ? v - db : v + db;
}

float applyDeadbandf(float v, float db) {
    if (ABS(v) < db) return 0.0f;
    return v > 0 ? v - db : v + db;
}

int constrain(int amt, int lo, int hi) {
    return amt < lo ? lo : amt > hi ? hi : amt;
}

float constrainf(float amt, float lo, float hi) {
    return amt < lo ? lo : amt > hi ? hi : amt;
}

/* ── 在线方差统计 (Welford 算法) ── */
void  devClear(stdev_t* d) { d->m_n = 0; }

void devPush(stdev_t* d, float x) {
    d->m_n++;
    if (d->m_n == 1) { d->m_oldM = d->m_newM = x; d->m_oldS = 0.0f; }
    else {
        d->m_newM = d->m_oldM + (x - d->m_oldM) / d->m_n;
        d->m_newS = d->m_oldS + (x - d->m_oldM) * (x - d->m_newM);
        d->m_oldM = d->m_newM; d->m_oldS = d->m_newS;
    }
}

float devVariance(stdev_t* d) { return d->m_n > 1 ? d->m_newS / (d->m_n - 1) : 0.0f; }
float devStandardDeviation(stdev_t* d) { return sqrtf(devVariance(d)); }
float degreesToRadians(int16_t deg) { return deg * RAD; }

int scaleRange(int x, int s0, int s1, int d0, int d1) {
    long a = ((long)d1 - d0) * ((long)x - s0);
    long b = (long)s1 - s0;
    return (int)(a / b + d0);
}

float scaleRangef(float x, float s0, float s1, float d0, float d1) {
    return (d1 - d0) * (x - s0) / (s1 - s0) + d0;
}

/* ── 向量归一化 ── */
void normalizeV(struct fp_vector* src, struct fp_vector* dest) {
    float len = sqrtf(src->X*src->X + src->Y*src->Y + src->Z*src->Z);
    if (len != 0) { dest->X=src->X/len; dest->Y=src->Y/len; dest->Z=src->Z/len; }
}

void buildRotationMatrix(fp_angles_t* delta, float matrix[3][3]) {
    float cx=cos_approx(delta->angles.roll),  sx=sin_approx(delta->angles.roll);
    float cy=cos_approx(delta->angles.pitch), sy=sin_approx(delta->angles.pitch);
    float cz=cos_approx(delta->angles.yaw),   sz=sin_approx(delta->angles.yaw);
    float czcx=cz*cx, szcx=sz*cx, czsx=sx*cz, szsx=sx*sz;
    matrix[0][X]=cz*cy;         matrix[0][Y]=-cy*sz;          matrix[0][Z]=sy;
    matrix[1][X]=szcx+czsx*sy;  matrix[1][Y]=czcx-szsx*sy;    matrix[1][Z]=-sx*cy;
    matrix[2][X]=szsx-czcx*sy;  matrix[2][Y]=czsx+szcx*sy;    matrix[2][Z]=cy*cx;
}

void rotateV(struct fp_vector* v, fp_angles_t* delta) {
    struct fp_vector vt = *v;
    float m[3][3]; buildRotationMatrix(delta, m);
    v->X = vt.X*m[0][X] + vt.Y*m[1][X] + vt.Z*m[2][X];
    v->Y = vt.X*m[0][Y] + vt.Y*m[1][Y] + vt.Z*m[2][Y];
    v->Z = vt.X*m[0][Z] + vt.Y*m[1][Z] + vt.Z*m[2][Z];
}

/* ── 中值滤波 ── */
#define QMF_SORT(T,a,b) { if((a)>(b)){T t=(a);(a)=(b);(b)=t;} }

int32_t quickMedianFilter3(int32_t* v) {
    int32_t p[3]; memcpy(p,v,sizeof(p));
    QMF_SORT(int32_t,p[0],p[1]); QMF_SORT(int32_t,p[1],p[2]); QMF_SORT(int32_t,p[0],p[1]);
    return p[1];
}
int16_t quickMedianFilter3_16(int16_t* v) {
    int16_t p[3]; memcpy(p,v,sizeof(p));
    QMF_SORT(int16_t,p[0],p[1]); QMF_SORT(int16_t,p[1],p[2]); QMF_SORT(int16_t,p[0],p[1]);
    return p[1];
}
int32_t quickMedianFilter5(int32_t* v) {
    int32_t p[5]; memcpy(p,v,sizeof(p));
    QMF_SORT(int32_t,p[0],p[1]); QMF_SORT(int32_t,p[3],p[4]); QMF_SORT(int32_t,p[0],p[3]);
    QMF_SORT(int32_t,p[1],p[4]); QMF_SORT(int32_t,p[1],p[2]); QMF_SORT(int32_t,p[2],p[3]);
    QMF_SORT(int32_t,p[1],p[2]); return p[2];
}
int16_t quickMedianFilter5_16(int16_t* v) {
    int16_t p[5]; memcpy(p,v,sizeof(p));
    QMF_SORT(int16_t,p[0],p[1]); QMF_SORT(int16_t,p[3],p[4]); QMF_SORT(int16_t,p[0],p[3]);
    QMF_SORT(int16_t,p[1],p[4]); QMF_SORT(int16_t,p[1],p[2]); QMF_SORT(int16_t,p[2],p[3]);
    QMF_SORT(int16_t,p[1],p[2]); return p[2];
}
int32_t quickMedianFilter7(int32_t* v) {
    int32_t p[7]; memcpy(p,v,sizeof(p));
    QMF_SORT(int32_t,p[0],p[5]); QMF_SORT(int32_t,p[0],p[3]); QMF_SORT(int32_t,p[1],p[6]);
    QMF_SORT(int32_t,p[2],p[4]); QMF_SORT(int32_t,p[0],p[1]); QMF_SORT(int32_t,p[3],p[5]);
    QMF_SORT(int32_t,p[2],p[6]); QMF_SORT(int32_t,p[2],p[3]); QMF_SORT(int32_t,p[3],p[6]);
    QMF_SORT(int32_t,p[4],p[5]); QMF_SORT(int32_t,p[1],p[4]); QMF_SORT(int32_t,p[1],p[3]);
    QMF_SORT(int32_t,p[3],p[4]); return p[3];
}
int32_t quickMedianFilter9(int32_t* v) {
    int32_t p[9]; memcpy(p,v,sizeof(p));
    QMF_SORT(int32_t,p[1],p[2]); QMF_SORT(int32_t,p[4],p[5]); QMF_SORT(int32_t,p[7],p[8]);
    QMF_SORT(int32_t,p[0],p[1]); QMF_SORT(int32_t,p[3],p[4]); QMF_SORT(int32_t,p[6],p[7]);
    QMF_SORT(int32_t,p[1],p[2]); QMF_SORT(int32_t,p[4],p[5]); QMF_SORT(int32_t,p[7],p[8]);
    QMF_SORT(int32_t,p[0],p[3]); QMF_SORT(int32_t,p[5],p[8]); QMF_SORT(int32_t,p[4],p[7]);
    QMF_SORT(int32_t,p[3],p[6]); QMF_SORT(int32_t,p[1],p[4]); QMF_SORT(int32_t,p[2],p[5]);
    QMF_SORT(int32_t,p[4],p[7]); QMF_SORT(int32_t,p[4],p[2]); QMF_SORT(int32_t,p[6],p[4]);
    QMF_SORT(int32_t,p[4],p[2]); return p[4];
}

void arraySubInt32(int32_t* d, int32_t* a1, int32_t* a2, int n) {
    for (int i=0;i<n;i++) d[i]=a1[i]-a2[i];
}

float bellCurve(const float x, const float cw) {
    return powf(M_Ef, -sq(x) / (2.0f * sq(cw)));
}

/* 传感器校准 (Freescale AN4246) */
void sensorCalibrationResetState(sensorCalibrationState_t* s) {
    for (int i=0;i<4;i++) { for (int j=0;j<4;j++) s->XtX[i][j]=0; s->XtY[i]=0; }
}

void sensorCalibrationPushSampleForOffsetCalculation(sensorCalibrationState_t* s, int32_t sample[3]) {
    for (int i=0;i<3;i++) {
        for (int j=0;j<3;j++) s->XtX[i][j]+=(float)sample[i]*sample[j];
        s->XtX[i][3]+=(float)sample[i]; s->XtX[3][i]+=(float)sample[i];
    }
    s->XtX[3][3]+=1;
    float ss=sq((float)sample[0])+sq((float)sample[1])+sq((float)sample[2]);
    for (int i=0;i<3;i++) s->XtY[i]+=sample[i]*ss;
    s->XtY[3]+=ss;
}

static void gaussLR(float m[4][4]) {
    for (int i=0;i<4;i++) {
        for (int j=i;j<4;j++) for (int k=0;k<i;k++) m[i][j]-=m[i][k]*m[k][j];
        for (int j=i+1;j<4;j++) { for (int k=0;k<i;k++) m[j][i]-=m[j][k]*m[k][i]; m[j][i]/=m[i][i]; }
    }
}
static void fwdSub(float LR[4][4], float y[4], float b[4]) {
    for (int i=0;i<4;i++) { y[i]=b[i]; for (int k=0;k<i;k++) y[i]-=LR[i][k]*y[k]; }
}
static void bwdSub(float LR[4][4], float x[4], float y[4]) {
    for (int i=3;i>=0;i--) { x[i]=y[i]; for (int k=i+1;k<4;k++) x[i]-=LR[i][k]*x[k]; x[i]/=LR[i][i]; }
}
static void solveLGS(float A[4][4], float x[4], float b[4]) {
    float y[4]={0};
    gaussLR(A); fwdSub(A,y,b); bwdSub(A,x,y);
}

void sensorCalibrationSolveForOffset(sensorCalibrationState_t* s, float result[3]) {
    float beta[4];
    solveLGS(s->XtX,beta,s->XtY);
    for (int i=0;i<3;i++) result[i]=beta[i]/2;
}