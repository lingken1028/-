/**
 * @file    debug_assert.h
 * @brief   断言宏定义
 *          对应: COMMON/interface/debug_assert.h (逐字对照)
 *
 * ASSERT(e):        条件为假时调用 assertFail → 停电机/亮错误灯/死循环
 * IF_DEBUG_ASSERT:  仅 DEBUG 模式下生效
 * ASSERT_FAILED():  无条件触发 assertFail
 *
 * assertFail 实现:
 *   1. portDISABLE_INTERRUPTS() — 关中断
 *   2. storeAssertSnapshotData(file, line) — 存崩溃信息
 *   3. Serial.printf("Assert failed %s:%d\n", file, line) — 打印
 *   4. 停止所有四个电机
 *   5. 清除所有 LED, 设置错误 LED
 *   6. while(1) 死循环
 */
#pragma once

/* 条件断言 (对应原始 ASSERT 宏) */
#define ASSERT(e)  do { if (!(e)) assertFail(#e, __FILE__, __LINE__); } while(0)

/* DEBUG 模式断言 (对应原始 IF_DEBUG_ASSERT) */
#ifdef DEBUG
  #define IF_DEBUG_ASSERT(e)  do { if (!(e)) assertFail(#e, __FILE__, __LINE__); } while(0)
#else
  #define IF_DEBUG_ASSERT(e)  do {} while(0)
#endif

/* 无条件断言失败 */
#define ASSERT_FAILED()  assertFail("", __FILE__, __LINE__)

void assertFail(const char* exp, const char* file, int line);
void printAssertSnapshotData(void);
void storeAssertSnapshotData(const char* file, int line);