/**
 * @file    axis.h
 * @brief   坐标轴和飞行动力学枚举
 *          对应: COMMON/interface/axis.h (逐字对照)
 *
 * 用途: state_estimator.c 使用 X/Y/Z 枚举索引数组
 *       maths.c 的 rotateV/buildRotationMatrix 使用
 */
#pragma once

typedef enum {
    X = 0,
    Y,
    Z
} axis_e;

#define XYZ_AXIS_COUNT 3

typedef enum {
    FD_ROLL = 0,
    FD_PITCH,
    FD_YAW
} flight_dynamics_index_t;

#define FLIGHT_DYNAMICS_INDEX_COUNT 3

typedef enum {
    AI_ROLL = 0,
    AI_PITCH,
} angle_index_t;

#define ANGLE_INDEX_COUNT 2