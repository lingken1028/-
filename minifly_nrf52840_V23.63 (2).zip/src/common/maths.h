/**
 * @file    maths.h
 * @brief   数学工具库
 *          对应: COMMON/interface/maths.h (来自 Cleanflight, 逐字对照)
 *
 * 包含:
 *   宏: sq, MIN, MAX, ABS
 *   快速三角近似: sin_approx, cos_approx, atan2_approx, acos_approx
 *   工具函数: constrainf, applyDeadbandf, gcd, scaleRangef
 *   统计: stdev_t (devPush/devVariance)
 *   向量: t_fp_vector, fp_angles_t
 *   传感器校准: sensorCalibrationState_t
 *   中值滤波: quickMedianFilter3/5/7/9
 *   角度: wrap_18000, wrap_36000
 *   旋转: rotateV, buildRotationMatrix
 *
 * 注意: constrainf 在原始 position_pid.c 和 state_estimator.c 中大量使用
 *       applyDeadbandf 在 state_estimator.c 中使用
 */
#pragma once
#include <stdint.h>
#include <math.h>

#ifndef sq
#define sq(x) ((x)*(x))
#endif

/* 快速数学近似 (对应原始 FAST_MATH) */
#define FAST_MATH

#define M_PIf  3.14159265358979323846f
#define M_LN2f 0.69314718055994530942f
#define M_Ef   2.71828182845904523536f
#define RAD    (M_PIf / 180.0f)

/* 角度转换宏 (对应原始, 逐字对照) */
#define DEGREES_TO_RADIANS(angle)       ((angle) * RAD)
#define RADIANS_TO_DEGREES(angle)       ((angle) / RAD)
#define DEGREES_TO_CENTIDEGREES(angle)  ((angle) * 100)
#define CENTIDEGREES_TO_DEGREES(angle)  ((angle) / 100)

#define MIN(a,b)  (((a)<(b))?(a):(b))
#define MAX(a,b)  (((a)>(b))?(a):(b))
#define ABS(x)    (((x)<0)?-(x):(x))

/* 统计结构体 (对应 stdev_t) */
typedef struct {
    float m_oldM, m_newM, m_oldS, m_newS;
    int   m_n;
} stdev_t;

/* 浮点三维向量 */
typedef struct fp_vector { float X, Y, Z; } t_fp_vector_def;
typedef union { float A[3]; t_fp_vector_def V; } t_fp_vector;

/* 浮点欧拉角 */
typedef struct fp_angles { float roll, pitch, yaw; } fp_angles_def;
typedef union { float raw[3]; fp_angles_def angles; } fp_angles_t;

/* 传感器校准状态 */
typedef struct {
    float XtY[4];
    float XtX[4][4];
} sensorCalibrationState_t;

/* 快速三角近似 (对应 FAST_MATH 条件) */
#if defined(FAST_MATH)
float sin_approx(float x);
float cos_approx(float x);
float atan2_approx(float y, float x);
float acos_approx(float x);
#define tan_approx(x) (sin_approx(x)/cos_approx(x))
#else
#define sin_approx(x)       sinf(x)
#define cos_approx(x)       cosf(x)
#define atan2_approx(y,x)   atan2f(y,x)
#define acos_approx(x)      acosf(x)
#define tan_approx(x)       tanf(x)
#endif

/* 函数声明 */
int     gcd(int num, int denom);
int32_t applyDeadband(int32_t value, int32_t deadband);
float   applyDeadbandf(float value, float deadband);
int     constrain(int amt, int low, int high);
float   constrainf(float amt, float low, float high);

void  devClear(stdev_t* dev);
void  devPush(stdev_t* dev, float x);
float devVariance(stdev_t* dev);
float devStandardDeviation(stdev_t* dev);
float degreesToRadians(int16_t degrees);

int   scaleRange(int x, int srcMin, int srcMax, int destMin, int destMax);
float scaleRangef(float x, float srcMin, float srcMax, float destMin, float destMax);

void  normalizeV(struct fp_vector* src, struct fp_vector* dest);
void  rotateV(struct fp_vector* v, fp_angles_t* delta);
void  buildRotationMatrix(fp_angles_t* delta, float matrix[3][3]);

int32_t wrap_18000(int32_t angle);
int32_t wrap_36000(int32_t angle);

int32_t quickMedianFilter3(int32_t* v);
int32_t quickMedianFilter5(int32_t* v);
int32_t quickMedianFilter7(int32_t* v);
int32_t quickMedianFilter9(int32_t* v);
int16_t quickMedianFilter3_16(int16_t* v);
int16_t quickMedianFilter5_16(int16_t* v);

void  arraySubInt32(int32_t* dest, int32_t* array1, int32_t* array2, int count);
float bellCurve(const float x, const float curveWidth);

void sensorCalibrationResetState(sensorCalibrationState_t* state);
void sensorCalibrationPushSampleForOffsetCalculation(sensorCalibrationState_t* state, int32_t sample[3]);
void sensorCalibrationSolveForOffset(sensorCalibrationState_t* state, float result[3]);