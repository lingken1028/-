/**
 * @file    filter.cpp
 * @brief   滤波器实现
 *          对应: COMMON/src/filter.c (逐字对照)
 *
 * lpf2pSetCutoffFreq 系数计算 (Butterworth, Direct Form II):
 *   fr  = sample_freq / cutoff_freq
 *   ohm = tan(π/fr)
 *   c   = 1 + 2*cos(π/4)*ohm + ohm²
 *   b0  = ohm²/c
 *   b1  = 2*b0
 *   b2  = b0
 *   a1  = 2*(ohm²-1)/c
 *   a2  = (1-2*cos(π/4)*ohm+ohm²)/c
 *
 * 用于 sensors.cpp sensorsDeviceInit():
 *   lpf2pInit(&gyroLpf[i], SENSOR9_UPDATE_RATE=500, GYRO_LPF_CUTOFF_FREQ=80)
 *   lpf2pInit(&accLpf[i],  SENSOR9_UPDATE_RATE=500, ACCEL_LPF_CUTOFF_FREQ=30)
 *
 * 在 sensorsAcquire 中: g.axis[i] = lpf2pApply(&gyroLpf[i], g.axis[i])
 */
#include "filter.h"
#include <math.h>
#include <stdint.h>

#define M_PI_F 3.14159265f

int16_t iirLPFilterSingle(int32_t in, int32_t attenuation, int32_t* filt) {
    if (attenuation > (1<<IIR_SHIFT)) attenuation = (1<<IIR_SHIFT);
    else if (attenuation < 1) attenuation = 1;
    int32_t inScaled = in << IIR_SHIFT;
    int32_t filttmp = *filt;
    filttmp = filttmp + (((inScaled - filttmp) >> IIR_SHIFT) * attenuation);
    int16_t out = (int16_t)((filttmp >> 8) + ((filttmp & (1 << (IIR_SHIFT-1))) >> (IIR_SHIFT-1)));
    *filt = filttmp;
    return out;
}

void lpf2pInit(lpf2pData* lpfData, float sample_freq, float cutoff_freq) {
    if (lpfData == NULL || cutoff_freq <= 0.0f) return;
    lpf2pSetCutoffFreq(lpfData, sample_freq, cutoff_freq);
}

void lpf2pSetCutoffFreq(lpf2pData* lpfData, float sample_freq, float cutoff_freq) {
    float fr  = sample_freq / cutoff_freq;
    float ohm = tanf(M_PI_F / fr);
    float c   = 1.0f + 2.0f * cosf(M_PI_F / 4.0f) * ohm + ohm * ohm;
    lpfData->b0 = ohm * ohm / c;
    lpfData->b1 = 2.0f * lpfData->b0;
    lpfData->b2 = lpfData->b0;
    lpfData->a1 = 2.0f * (ohm * ohm - 1.0f) / c;
    lpfData->a2 = (1.0f - 2.0f * cosf(M_PI_F / 4.0f) * ohm + ohm * ohm) / c;
    lpfData->delay_element_1 = 0.0f;
    lpfData->delay_element_2 = 0.0f;
}

float lpf2pApply(lpf2pData* lpfData, float sample) {
    float delay_element_0 = sample
        - lpfData->delay_element_1 * lpfData->a1
        - lpfData->delay_element_2 * lpfData->a2;
    if (!isfinite(delay_element_0)) delay_element_0 = sample;
    float output = delay_element_0 * lpfData->b0
        + lpfData->delay_element_1 * lpfData->b1
        + lpfData->delay_element_2 * lpfData->b2;
    lpfData->delay_element_2 = lpfData->delay_element_1;
    lpfData->delay_element_1 = delay_element_0;
    return output;
}

float lpf2pReset(lpf2pData* lpfData, float sample) {
    float dval = sample / (lpfData->b0 + lpfData->b1 + lpfData->b2);
    lpfData->delay_element_1 = dval;
    lpfData->delay_element_2 = dval;
    return lpf2pApply(lpfData, sample);
}
/* V22.27: 二阶陷波(notch)。标准 RBJ notch 双二阶, 归一化后存入 lpf2pData,
 * 用同一个 lpf2pApply(Direct Form II, 递归项为 -d1*a1 -d2*a2)。 */
void notchSetFreq(lpf2pData* d, float sample_freq, float center_freq, float Q) {
    if (center_freq <= 0.0f || center_freq >= sample_freq * 0.5f || Q <= 0.0f) {
        /* 非法参数 → 退化为直通 */
        d->b0 = 1.0f; d->b1 = 0.0f; d->b2 = 0.0f;
        d->a1 = 0.0f; d->a2 = 0.0f;
        return;
    }
    float w0    = 2.0f * M_PI_F * center_freq / sample_freq;
    float cosw0 = cosf(w0);
    float alpha = sinf(w0) / (2.0f * Q);
    float a0    = 1.0f + alpha;
    d->b0 = 1.0f / a0;
    d->b1 = -2.0f * cosw0 / a0;
    d->b2 = 1.0f / a0;
    d->a1 = -2.0f * cosw0 / a0;
    d->a2 = (1.0f - alpha) / a0;
}

void notchInit(lpf2pData* d, float sample_freq, float center_freq, float Q) {
    d->delay_element_1 = d->delay_element_2 = 0.0f;
    notchSetFreq(d, sample_freq, center_freq, Q);
}
